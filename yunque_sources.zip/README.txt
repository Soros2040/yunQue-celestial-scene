进入 source/scene 后执行 blender -b -t 8 --python rebuild_scene.py -- --build-only
配乐复现见 source/music/COMPOSITION_NOTES.txt
