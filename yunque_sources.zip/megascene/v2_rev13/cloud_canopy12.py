"""Two connected multiscale volumetric cloud banks, replacing REV11 local crowns.
Apply to study12c; no world, camera, lights, old cloud groups or renders changed.
"""
import bpy,random,math
from mathutils import Vector,noise


def _material():
 name='REV12 CANOPY | dense ivory scattering and blue cavities'
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
 out=n.new('ShaderNodeOutputMaterial');vol=n.new('ShaderNodeVolumePrincipled');vol.inputs['Color'].default_value=(.985,.993,1,1);vol.inputs['Anisotropy'].default_value=.12
 tc=n.new('ShaderNodeTexCoord');broad=n.new('ShaderNodeTexNoise');broad.inputs['Scale'].default_value=.24;broad.inputs['Detail'].default_value=3;broad.inputs['Roughness'].default_value=.7
 fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=1.1;fine.inputs['Detail'].default_value=3
 # Gentle density modulation throughout a solid connected core: no radial fade,
 # no threshold which could erase the bank and turn it into disconnected wisps.
 map1=n.new('ShaderNodeMapRange');map1.inputs['From Min'].default_value=.15;map1.inputs['From Max'].default_value=.85;map1.inputs['To Min'].default_value=.34;map1.inputs['To Max'].default_value=.95;map1.clamp=True
 map2=n.new('ShaderNodeMapRange');map2.inputs['To Min'].default_value=.7;map2.inputs['To Max'].default_value=1.15
 mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
 for a,b in [(tc.outputs['Object'],broad.inputs[0]),(tc.outputs['Object'],fine.inputs[0]),(broad.outputs['Fac'],map1.inputs[0]),(fine.outputs['Fac'],map2.inputs[0]),(map1.outputs[0],mul.inputs[0]),(map2.outputs[0],mul.inputs[1]),(mul.outputs[0],vol.inputs['Density']),(vol.outputs[0],out.inputs['Volume'])]:l.new(a,b)
 return m


def _bank(name,anchors,seed,material):
 rng=random.Random(seed);mb=bpy.data.metaballs.new(name+' multiscale union');mb.resolution=.33;mb.render_resolution=.33;mb.threshold=.64
 ob=bpy.data.objects.new(name,mb);bpy.context.collection.objects.link(ob)
 def ball(p,rx,ry,rz):
  e=mb.elements.new();e.type='ELLIPSOID';e.co=p;e.radius=1;e.size_x=rx;e.size_y=ry;e.size_z=rz;e.stiffness=2
 # Large unequal overlapping bodies establish connected banks. Small attached
 # shoulder lobes articulate their perimeter, rather than isolated cotton balls.
 for index,(x,y,z,r) in enumerate(anchors):
  ball((x,y,z),r*1.25,r,r*.6)
  for j in range(7):
   a=j*math.tau/7+rng.uniform(-.28,.28);rr=rng.uniform(.34,.64)*r
   px=x+math.cos(a)*r*.74;py=y+math.sin(a)*r*.65;pz=z+rng.uniform(-.1,.45)*r
   ball((px,py,pz),rr,rr*rng.uniform(.75,1.2),rr*rng.uniform(.6,.95))
   for k in range(3):
    aa=a+rng.uniform(-1.2,1.2);small=rr*rng.uniform(.25,.43)
    ball((px+math.cos(aa)*rr*.72,py+math.sin(aa)*rr*.72,pz+rng.uniform(.1,.55)*rr),small,small*.9,small*.9)
 bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');ob=bpy.context.object;ob.name=name
 ob.data.materials.append(material)
 for v in ob.data.vertices:
  p=v.co.copy();dis=.23*noise.noise_vector(p*1.8)[0]+.09*noise.noise_vector(p*5.5)[1];v.co+=v.normal*dis
 # Compress vertically, never clip: no horizontal cut surface and all crowns
 # remain below the hero spillways / top elevation10.
 maxz=max(v.co.z for v in ob.data.vertices);minz=min(v.co.z for v in ob.data.vertices)
 if maxz>8.65:
  for v in ob.data.vertices:v.co.z=minz+(v.co.z-minz)*(8.65-minz)/(maxz-minz)
 for p in ob.data.polygons:p.use_smooth=True
 ob.data.update();ob.select_set(False)
 near=[v.co.z for v in ob.data.vertices if 28<=v.co.y<=44]
 print('CANOPY BANK DIAGNOSTIC',name,'near y28–44 top',max(near) if near else None,'global top',max(v.co.z for v in ob.data.vertices),flush=True)
 return ob


def apply_cloud_canopy12():
 if bpy.data.objects.get('REV12 CANOPY | connected middle cloud canyon'):raise RuntimeError('Cloud canopy12 already applied')
 hidden=[]
 for ob in bpy.data.objects:
  if ob.name.startswith('REV11 | cliff embracing cloud crown'):
   ob.hide_render=True;ob.hide_viewport=True;hidden.append(ob.name)
 material=_material()
 # Main bank runs into the distance, not a flat slab parallel to the image plane.
 main=[(-17,28,1.1,5.0),(-10,31,1.9,5.8),(-2,34,2.4,6.4),(6,39,2.1,5.2),(-7,44,2.8,5.8),(-9,55,3.4,6.7),(-5,67,3.3,7.1),(1,81,3.5,8.1),(5,98,3.9,9.2)]
 # A lower, narrower connected bank conceals portions of the cliff foot, while
 # upper waterfall exits and the vegetated shelf crowns remain readable.
 lower=[(6,15,1.5,3.6),(12,17,1.8,4.4),(18,20,2.1,4.8),(24,23,2.0,4.0),(29,28,1.7,3.8)]
 objects=[_bank('REV12 CANOPY | connected middle cloud canyon',main,12191,material),_bank('REV12 CANOPY | connected lower cliff skirts',lower,12207,material)]
 bpy.context.view_layer.update()
 print('CANOPY12 replaced',len(hidden),'crowns; meshes',len(objects),'vertices',sum(len(o.data.vertices) for o in objects))
 return objects

apply_cloud_canopy=apply_cloud_canopy12
