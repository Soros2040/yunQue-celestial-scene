"""Deterministic, editable gnarled blossom tree for the Celestial Palace scene.
No external assets. build_tree(root=(14,30,10), scale=1) returns object metrics.
"""
import bpy, math, random
from mathutils import Vector
from mathutils.noise import noise_vector

def build_tree(root=(14,30,10), scale=1):
    rng=random.Random(780319)
    collection=bpy.data.collections.new('V4 HERO • The wild celestial blossom'); bpy.context.scene.collection.children.link(collection)
    origin=Vector(root)-Vector((10,28,5))
    def world(p):
        q=p-Vector((10,28,5)); q.z*=.76
        return q*scale+Vector(root)
    def material(name,color,rough):
        m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
        bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=rough
        return m
    bark=material('HERO bark • charcoal bronze fissured heartwood',(.052,.039,.027),.71)
    nt=bark.node_tree;bs=nt.nodes.get('Principled BSDF')
    tc=nt.nodes.new('ShaderNodeTexCoord'); vector=nt.nodes.new('ShaderNodeVectorMath');vector.operation='MULTIPLY';vector.inputs[1].default_value=(2.4,2.4,.38);nt.links.new(tc.outputs['Object'],vector.inputs[0])
    noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=3.1;noise.inputs['Detail'].default_value=5;noise.inputs['Roughness'].default_value=.8;nt.links.new(vector.outputs[0],noise.inputs['Vector'])
    ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.19;ramp.color_ramp.elements[0].color=(.009,.012,.009,1);ramp.color_ramp.elements[1].position=.8;ramp.color_ramp.elements[1].color=(.16,.114,.067,1);nt.links.new(noise.outputs['Fac'],ramp.inputs[0]);nt.links.new(ramp.outputs[0],bs.inputs['Base Color'])
    bump=nt.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.48;bump.inputs['Distance'].default_value=.09;nt.links.new(noise.outputs['Fac'],bump.inputs['Height']);nt.links.new(bump.outputs['Normal'],bs.inputs['Normal'])
    ivory=material('HERO petals • warm ivory silk',(.83,.76,.65),.48);ivory.node_tree.nodes.get('Principled BSDF').inputs['Subsurface Weight'].default_value=.13
    blush=material('HERO petals • muted rose',(.68,.43,.36),.52)
    pollen=material('HERO blossom hearts • ochre',(.33,.16,.041),.7)
    leaves=material('HERO buds • muted jade',(.09,.12,.058),.72)
    verts=[];faces=[]
    def sample(points,steps):
        ps=[Vector(p[:3]) for p in points]; rs=[p[3] for p in points];out=[]
        for i in range(len(ps)-1):
            a=ps[max(0,i-1)];b=ps[i];c=ps[i+1];d=ps[min(len(ps)-1,i+2)]
            for j in range(steps):
                t=j/steps;p=.5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)
                out.append((p,rs[i]*(1-t)+rs[i+1]*t))
        out.append((ps[-1],rs[-1]));return out
    def tube(points,sides=12,steps=8,ridged=True):
        seq=sample(points,steps);base=len(verts)
        for i,(p,r) in enumerate(seq):
            tangent=(seq[min(len(seq)-1,i+1)][0]-seq[max(0,i-1)][0]).normalized()
            axis=Vector((0,1,0)) if abs(tangent.y)<.9 else Vector((1,0,0));e=tangent.cross(axis).normalized();f=tangent.cross(e).normalized()
            for k in range(sides):
                ang=math.tau*k/sides;phase=ang+i*.043
                groove=1+.13*math.sin(phase*7)+.065*math.sin(phase*17+i*.11)+.045*math.sin(phase*29-i*.18) if ridged else 1
                distort=noise_vector(p*.7+Vector((math.cos(ang),math.sin(ang),i*.07)))
                q=p+(e*math.cos(ang)+f*math.sin(ang))*r*groove+distort*min(.13,r*.15)
                verts.append(tuple(world(q)))
            if i:
                prev=base+(i-1)*sides;cur=base+i*sides
                for k in range(sides):faces.append((prev+k,prev+(k+1)%sides,cur+(k+1)%sides,cur+k))
        faces.append(tuple(base+k for k in range(sides-1,-1,-1)));faces.append(tuple(base+(len(seq)-1)*sides+k for k in range(sides)))
        return seq
    main=[(10,28,4,3.8),(11,28,7,3.6),(16,28,10.5,3.3),(18,28,14.5,2.9),(16,28,18.2,2.6),(11,28,21,2.15),(6.8,28,23.4,1.75),(3.6,28,22.8,1.55),(1.4,28,19.7,1.27),(-1,27,18.4,1.15),(-4.8,25.7,17.6,1),(-7.4,26.3,20,.85),(-9.2,29,21.2,.68),(-11.8,30,19.4,.52),(-15,28,19,.37),(-17,26,22,.2),(-20,25,23,.04)]
    seq=tube(main,80,18)
    # Twisted ropes of exposed heartwood clasp the main trunk, generating silhouette-level fluting.
    for n in range(22):
        pts=[]
        for i,(p,r) in enumerate(seq[::5]):
            j=i*5;tangent=(seq[min(j+1,len(seq)-1)][0]-seq[max(0,j-1)][0]).normalized(); e=tangent.cross(Vector((0,1,0))).normalized();f=tangent.cross(e).normalized()
            ang=n*math.tau/22+i*.18+.22*math.sin(i*.7+n);q=p+(e*math.cos(ang)+f*math.sin(ang))*r*(.94+.025*math.sin(i))
            pts.append((*q,max(.02,r*(.05+.035*math.sin(n*4)**2))))
        tube(pts,9,3)
    # Sweeping diagonal buttress roots carry the visual motion toward the left.
    for n in range(9):
        y=25.4+n*.69
        tube([(15,y,10.3,.85),(11.8,y-.35,7.4,.75),(6.5,y-.65,6.1,.57),(1.5,y-.8,4.7,.31),(-5-rng.random()*3,y-.5,4,.03)],18,11)
    # Long root purls: exposed thin corkscrews break the unnaturally smooth buttress silhouette.
    for n in range(24):
        a=n*.53; points=[]
        for j in range(10):
            t=j/9;x=14-22*t;y=26+(n%7)*.68+math.sin(t*11+a)*.4;z=8.3-4.1*t+math.sin(t*12+a)*.35
            points.append((x,y,z,.11*(1-t)+.012))
        tube(points,7,5)
    # Crooked exposed splinters and fissure scars on the lower arch.
    for n in range(35):
        j=rng.randrange(15,min(130,len(seq)-1));p,r=seq[j];p=p+Vector((rng.uniform(-.5,.5)*r,-r*.88,0))
        q=p+Vector((rng.uniform(-.8,.8),rng.uniform(-.2,.2),rng.uniform(.3,1.2)))
        tube([(*p,.08),(*(p+(q-p)*.6+Vector((.2,-.12,0))),.05),(*q,.003)],6,4)
    # Great splayed, angular buttress roots run over the floating island's crown.
    for n in range(19):
        a=n*math.tau/19;le=rng.uniform(7,14);sx=math.cos(a);sy=math.sin(a)
        tube([(10+sx,28+sy,8,rng.uniform(.45,.9)),(10+sx*3,28+sy*2.5,5.8,.6),(10+sx*le*.65,28+sy*le*.55,4.2,.3),(10+sx*le,28+sy*le*.7,3.7,.035)],16,12)
    arms=[
       [(10,28,21,1.5),(7.5,28.5,25,1.2),(8.4,28.5,28,.88),(6,28.5,30,.65),(3,28.5,31,.4),(1,28.8,34,.12),(-1,29,35,.02)],
       [(8.2,28.4,28,.8),(11,30,29.3,.62),(13,29,28,.5),(15,26.8,29,.4),(16.5,27,31.2,.28),(19,29,30.3,.15),(21,29,31.8,.025)],
       [(6,28.5,30,.64),(3,27,29.2,.5),(.5,25.8,30.4,.4),(-1,27.3,32.2,.3),(-4,29,31.8,.2),(-6.3,27,33,.12),(-9,26,32.7,.02)],
       [(3,28,23,.9),(.3,29.2,24.5,.8),(-2.3,30,23.6,.7),(-4,28,25.7,.54),(-6.5,25,26.6,.42),(-9,24,25,.32),(-12,25.7,25.8,.24),(-14,29,28.7,.15),(-17,29.5,29,.02)],
       [(-4.8,25.7,17.6,.78),(-8,24.3,17.9,.65),(-10,25.4,20.2,.49),(-13,28,21.6,.38),(-16,29,20.8,.29),(-19,26,21.7,.2),(-22,24.7,24.5,.02)],
       [(-11.8,30,19.4,.5),(-14,30.5,16.4,.38),(-17,28,15.5,.3),(-20,26.8,16.7,.22),(-21,27.5,19.6,.12),(-25,28,20,.02)],
       [(14.5,28,18,1.05),(18,29,20,.8),(21,29,21,.52),(24,29,22.8,.3),(27,29,23.2,.03)],
       [(18,29,20,.7),(19,31,24,.47),(22,31,25.7,.3),(26,31,26.1,.03)],
       [(7.5,28.5,25,.58),(5,31,27,.36),(2,33,28.5,.2),(-2,34,29,.03)],
       [(1.4,28,19.7,.6),(-2,25,22,.4),(-5,23,22.7,.23),(-8,22,24.3,.03)],
       [(14,28,10.5,.9),(18,27.5,10,.6),(20,27,12.2,.3),(24,27,13.2,.03)]
    ]
    tips=[]
    for arm in arms:
        crooked=[]
        for i in range(len(arm)-1):
            a=Vector(arm[i][:3]); b=Vector(arm[i+1][:3]); crooked.append(arm[i]); mid=(a+b)*.5+Vector((rng.uniform(-.45,.45),rng.uniform(-.3,.3),rng.uniform(-.65,.65))); crooked.append((*mid,(arm[i][3]+arm[i+1][3])*.5))
        crooked.append(arm[-1]); tube(crooked,28,8)
        # Surface exposed splinter veins follow larger branches.
        for n in range(4):
            pts=[]
            for i,(x,y,z,r) in enumerate(arm):
                a=n*math.tau/4+i*.5;pts.append((x+math.cos(a)*r*.6,y+math.sin(a)*r*.9,z,r*.09+.012))
            tube(pts,7,8)
        for j in range(1,len(arm)):
            x,y,z,r=arm[j]
            for k in range(4):
                dx=rng.uniform(-3.1,3.1);dy=rng.uniform(-2.3,2.3);dz=rng.uniform(.5,2.5)
                p=Vector((x,y,z));q=p+Vector((dx,dy,dz));mid=p+Vector((dx*.42+math.copysign(.35,dx),dy*.65,dz*.1-.3))
                bend=mid+(q-mid)*.55+Vector((rng.uniform(-.55,.55),rng.uniform(-.4,.4),-.2))
                tube([(*p,min(.2,r*.53)),(*mid,.11),(*bend,.07),(*q,.025)],9,6)
                for m in range(7):
                    end=q+Vector((rng.uniform(-1.6,1.6),rng.uniform(-1.2,1.2),rng.uniform(.15,1.2)))
                    kink=q+(end-q)*.52+Vector((rng.uniform(-.2,.2),0,-.12))
                    tube([(*q,.034),(*kink,.019),(*end,.003)],6,5,False)
                    tips.append((q,kink,end))
                    if m%3==0:
                        sub=end+Vector((rng.uniform(-.8,.8),rng.uniform(-.5,.5),rng.uniform(.3,.9)))
                        tube([(*kink,.02),(*end,.012),(*sub,.002)],5,5,False)
                        tips.append((kink,end,sub))
    # Craggy spikes, torn-off limbs and hanging aerial roots under arch.
    for n in range(55):
        j=rng.randrange(10,len(seq)-12);p,r=seq[j];a=rng.uniform(0,math.tau);offset=Vector((math.cos(a)*r*.6,math.sin(a)*r*.85,0));start=p+offset
        end=start+Vector((rng.uniform(-1,1),rng.uniform(-.5,.5),rng.uniform(-2.1,-.4)))
        tube([(*start,rng.uniform(.07,.18)),(*(start+(end-start)*.45+Vector((.2,0,.2))),.07),(*end,.004)],7,5)
    for n in range(18):
        t=rng.random();start=Vector((-9+16*t,27.3,19+3*math.sin(t*math.pi)));length=rng.uniform(1.3,4)
        pts=[(*(start+Vector((math.sin(i*.8+n)*.17,math.cos(i*.7+n)*.13,-length*i/8))),.025*(1-i/9)) for i in range(9)]
        tube(pts,5,4,False)
    def obj(name,v,f,mats):
        me=bpy.data.meshes.new(name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(name,me);collection.objects.link(ob)
        for m in mats:me.materials.append(m)
        for p in me.polygons:p.use_smooth=True
        return ob
    wood=obj('HERO • sculpted braided bark, roots, limbs and twigs',verts,faces,[bark])
    # Petals are modeled as cupped five-lobed flowers, never billboard alpha cards or blobs.
    pv=[];pf=[];pm=[]
    def flower(pos,size):
        normal=Vector((rng.uniform(-.6,.6),rng.uniform(-1,.5),rng.uniform(.15,1))).normalized();e=normal.cross(Vector((1,0,0))).normalized();f=normal.cross(e).normalized();phase=rng.random()*math.tau
        center=pos
        for petal in range(5):
            ang=phase+petal*math.tau/5;d=e*math.cos(ang)+f*math.sin(ang);side=e*(-math.sin(ang))+f*math.cos(ang)
            b=len(pv);points=[center,center+d*size*.62+side*size*.34+normal*size*.1,center+d*size+side*size*.19+normal*size*.3,center+d*size*1.08+normal*size*.36,center+d*size-side*size*.19+normal*size*.3,center+d*size*.62-side*size*.34+normal*size*.1,center+d*size*.55+normal*size*.17]
            pv.extend([tuple(world(p)) for p in points])
            for a in range(6):pf.append((b+a,b+(a+1)%6,b+6));pm.append(1 if rng.random()<.08 else 0)
    # Three large asymmetric canopy envelopes, with gaps between them.
    # Projection-scale petals and clustered occupancy remain readable in a wide establishing shot.
    masses=[(Vector((-13,27,25)),Vector((12,6,5))), (Vector((5,29,32)),Vector((10,6,4.5))), (Vector((23,29,25)),Vector((9,5,5)))]
    for q,mid,end in tips:
        distances=[sum(((end[i]-c[i])/r[i])**2 for i in range(3)) for c,r in masses]
        dist=min(distances)
        density=1 if dist<.9 else (.55 if dist<1.45 else .12)
        if rng.random()>density: continue
        count=rng.randint(9,15) if dist<1.3 else rng.randint(3,6)
        for n in range(count):
            t=rng.uniform(.3,1.2);p=mid+(end-mid)*t+Vector((rng.uniform(-.32,.32),rng.uniform(-.3,.3),rng.uniform(-.13,.22)))
            flower(p,rng.uniform(.18,.31))
    blossoms=obj('HERO • thousands of individual ivory five-petal blossoms',pv,pf,[ivory,blush])
    for p,mi in zip(blossoms.data.polygons,pm):p.material_index=mi
    # Fine broken luminous channels run within the dark front-facing bark fissures.
    gold=material('HERO • old-gold vitality channels',(.25,.13,.043),.48)
    gbs=gold.node_tree.nodes.get('Principled BSDF');gbs.inputs['Metallic'].default_value=.65;gbs.inputs['Emission Color'].default_value=(1,.37,.055,1);gbs.inputs['Emission Strength'].default_value=.1
    curve=bpy.data.curves.new('HERO • broken inner bark glints','CURVE');curve.dimensions='3D';curve.resolution_u=2;curve.bevel_depth=.023*scale;curve.bevel_resolution=1
    for n in range(8):
        start=6+n*2;stop=min(len(seq)-20,135+n*6)
        path=[]
        for i in range(start,stop,3):
            p,r=seq[i];a=n*.65+i*.035
            q=p+Vector((math.sin(a)*r*.58,-r*.89,math.cos(a)*r*.18))
            path.append(world(q))
        sp=curve.splines.new('POLY');sp.points.add(len(path)-1)
        for pt,p in zip(sp.points,path):pt.co=(*p,1)
    co=bpy.data.objects.new('HERO • restrained gold bark fissures',curve);collection.objects.link(co);curve.materials.append(gold)
    # Small pendants: gold chain, luminous hexagonal center, thin tassel.
    orn_v=[];orn_f=[]
    def rod(a,b,r,sides=6):
        a=Vector(a);b=Vector(b);t=(b-a).normalized();axis=Vector((0,1,0)) if abs(t.y)<.9 else Vector((1,0,0));u=t.cross(axis).normalized();v=t.cross(u).normalized();base=len(orn_v)
        for p in (a,b):
            for k in range(sides):orn_v.append(tuple(world(p+(u*math.cos(math.tau*k/sides)+v*math.sin(math.tau*k/sides))*r)))
        for k in range(sides):orn_f.append((base+k,base+(k+1)%sides,base+sides+(k+1)%sides,base+sides+k))
    for n,x in enumerate((-18,-14,-10,-6,-2,2,5,19,23)):
        candidates=main+[p for a in arms for p in a]
        target_z=20 if x<10 else 23
        anchor=min(candidates,key=lambda p:(p[0]-x)**2+.35*(p[2]-target_z)**2)
        x=anchor[0];y=anchor[1]-anchor[3]*.72;z=anchor[2]-anchor[3]*.6;length=1.4+(n%4)*.55
        rod((x,y,z),(x,y,z-length),.018)
        zz=z-length-.35
        for k in range(6):
            a=math.tau*k/6;aa=math.tau*(k+1)/6
            p=(x+math.cos(a)*.19,y+math.sin(a)*.19,zz);q=(x+math.cos(aa)*.19,y+math.sin(aa)*.19,zz)
            rod(p,q,.035);rod((x,y,zz+.35),p,.028);rod(p,(x,y,zz-.35),.028)
        rod((x,y,zz+.18),(x,y,zz-.18),.075)
        rod((x,y,zz-.35),(x,y,zz-1),.02)
    obj('HERO • hanging ritual gold lantern pendants',orn_v,orn_f,[gold])
    return {'collection':collection.name,'objects':len(collection.objects),'bark_vertices':len(verts),'petal_vertices':len(pv),'flower_count':len(pv)//35,'bounds':'x -24..35, y 19..41, z 9..35'}
