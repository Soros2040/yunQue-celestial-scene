import bpy

def apply_sky_mask12():
 n=bpy.context.scene.world.node_tree.nodes;l=bpy.context.scene.world.node_tree.links
 physical=next(q for q in n if q.bl_idname=='ShaderNodeMixRGB' and q.blend_type=='MULTIPLY' and q.inputs[1].is_linked and q.inputs[1].links[0].from_node.type=='TEX_SKY')
 mix=next(q for q in n if q.bl_idname=='ShaderNodeMixRGB' and q.inputs[2].is_linked and q.inputs[2].links[0].from_node==physical)
 tc=next(q for q in n if q.type=='TEX_COORD');sep=n.new('ShaderNodeSeparateXYZ');l.new(tc.outputs['Normal'],sep.inputs[0]);mask=n.new('ShaderNodeMapRange');mask.name='Physical horizon blend only12';mask.inputs['From Min'].default_value=-.12;mask.inputs['From Max'].default_value=-.02;mask.inputs['To Min'].default_value=0;mask.inputs['To Max'].default_value=.6;mask.clamp=True;l.new(sep.outputs['Z'],mask.inputs[0]);l.new(mask.outputs[0],mix.inputs[0]);print('SKY_HORIZON_MASK',mix.name,flush=True)
if __name__=='__main__':
 import os
 apply_sky_mask12();s=bpy.context.scene
 for o in bpy.data.objects:
  if o.type not in ('CAMERA','LIGHT') and not o.name.startswith('Sun '):o.hide_render=True
 s.render.use_compositing=False;s.render.resolution_percentage=40;s.cycles.samples=16;s.render.filepath=os.path.join(os.path.dirname(__file__),'sky_mask12.png');bpy.ops.render.render(write_still=True)
