"""Final authorized cloud-boundary optimization; all other scene design frozen."""
import bpy,os,sys,json
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT);s=bpy.context.scene
if s.get('Coherent revision13 applied'):raise RuntimeError('Revision13 already applied')
from cloud_grid13 import apply_cloud_grid13
volumes=apply_cloud_grid13(feather=1.15,density=1,core_power=True)
assert len(volumes)==2
s['Coherent revision13 applied']=True;s['Final cloud method']='Native mesh-to-volume density grid; actual inward extinction gradient, nonlinear dense core; no image blur.'
json.dump({'revision':13,'volume_objects':len(volumes),'voxel_size':.22,'interior_band_width':1.15,'grid_density':1,'density_shader':'grid^1.5 * 6 * correlated 3D noise','status':'final authorized optimization; moving-camera film follows'},open(os.path.join(ROOT,'revision13_validation.json'),'w'),indent=2)
s.cycles.samples=96;s.cycles.use_denoising=False;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_13.png');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_可编辑.blend'),compress=True)
if os.environ.get('MEGASCENE_BUILD_ONLY')!='1':bpy.ops.render.render(write_still=True)
