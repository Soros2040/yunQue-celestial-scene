"""Additive carved foreground railing relief. No existing geometry is removed.
Follows the exact diagonal terrace boundary in V2. No render or scene reset.
"""
import bpy, math
from math import sin,cos,pi
from mathutils import Vector
from architecture import Batch,_materials,_mat

def build_foreground_rail():
 mats=_materials().copy()
 mats['basalt']=_mat('rail09 carved blue basalt',(.075,.105,.13),.1,.48,bump=.025)
 mats['gilt']=_mat('rail09 chased antique gold',(.45,.24,.065),.8,.28,bump=.006)
 mats['inlay']=_mat('rail09 satin dark lacquer panel',(.018,.028,.033),.28,.29,bump=.005)
 b=Batch(mats);p0=Vector((-30,5,8));p1=Vector((35,-47,8));t=(p1-p0).normalized();n=Vector((t.y,-t.x,0));up=Vector((0,0,1));path=[p0.lerp(p1,i/45) for i in range(46)];span=(p1-p0).length/45
 def local(c,u,d,v):return tuple(c+t*u+n*d+up*v)
 def tube(c,uvs,r=.014,ma='gilt',depth=.14):b.tube([local(c,u,depth,v) for u,v in uvs],r,ma,5)
 def obox(c,u,d,v,w,depth,h,ma):
  vs=[local(c,u+su*w/2,d+sd*depth/2,v+sv*h/2) for su,sd,sv in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
  b.mesh(vs,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],ma)
 def panel(c,w,h,depth=.17):
  a=w/2;v=h/2;clip=.055
  outline=[(-a+clip,-v),(a-clip,-v),(a,-v+clip),(a,v-clip),(a-clip,v),(-a+clip,v),(-a,v-clip),(-a,-v+clip)]
  vs=[local(c,u,dd,z) for dd in [depth-.04,depth] for u,z in outline];fs=[tuple(range(7,-1,-1)),tuple(range(8,16))]+[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(8)];b.mesh(vs,fs,'inlay')
  tube(c,outline+[outline[0]],.018,'gilt',depth+.012)
  outline2=[(u*.91,z*.78) for u,z in outline];tube(c,outline2+[outline2[0]],.008,'gilt',depth+.014)
 # posts: thick carved square bases, channel collars and lotus crown caps
 for i,p in enumerate(path):
  obox(p,0,0,.07,.35,.35,.14,'basalt');obox(p,0,0,.16,.29,.29,.08,'gilt')
  obox(p,0,0,.64,.235,.235,.93,'basalt')
  for dz in [.21,1.10,1.26,1.41]:obox(p,0,0,dz,.30,.30,.055,'gilt')
  # slender engraved corner channels catch glints on the dark post
  for u in [-.107,.107]:tube(p,[(u,.27),(u,1.04)],.007,'gilt',.125)
  obox(p,0,0,1.34,.36,.36,.12,'basalt');obox(p,0,0,1.43,.39,.39,.055,'gilt')
  # actual five-ring octagonal lotus pedestal and eight convex petals
  b.cylinder(tuple(p+up*1.51),.15,.12,'basalt',12)
  for j in range(8):
   a=2*pi*j/8;radial=t*cos(a)+n*sin(a);side=-t*sin(a)+n*cos(a);vs=[]
   for k in range(9):
    tt=k/8;rr=.055+.125*sin(pi*tt);zz=1.48+.31*tt;wid=.075*sin(pi*tt)
    for sg in [-1,1]:vs.append(tuple(p+radial*rr+side*(sg*wid)+up*zz))
   fs=[(2*k,2*k+1,2*k+3,2*k+2) for k in range(8)];b.mesh(vs,fs,'gilt' if j%2 else 'basalt')
  b.sphere(tuple(p+up*1.77),.075,'gilt')
 # projected, properly oriented carved insets with lotus/scroll relief
 for i in range(45):
  c=(path[i]+path[i+1])*.5+up*.756
  panel(c,span*.78,.49,.18)
  d=.205
  # central six-petal rosette, relief sits above lacquer and gilded framing
  for k in range(6):
   a=2*pi*k/6;pts=[]
   for j in range(17):
    tt=2*pi*j/16;rr=.035+.125*sin(tt/2)**1.3;aa=a+.21*sin(tt);pts.append((rr*cos(aa),rr*sin(aa)))
   tube(c,pts,.012,'gilt',d)
  tube(c,[(.044*cos(2*pi*j/16),.044*sin(2*pi*j/16)) for j in range(17)],.012,'gilt',d+.012)
  # mirrored scrolling acanthus / ruyi cloud arabesques
  for sign in [-1,1]:
   for offset,sz in [(0,.15),(.145,.075),(-.145,.075)]:
    pts=[]
    for j in range(25):
     a=j/24*pi*2.65;rr=sz*(1-j/40);uu=sign*(.31+rr*cos(a));vv=offset+rr*sin(a)*(.75 if offset==0 else .5);pts.append((uu,vv))
    tube(c,pts,.011,'gilt',d)
   # sprouting pointed leaves branching off inner stem
   for j in range(3):
    u=sign*(.20+j*.10);vv=.04*sin(j*1.3);pts=[(u,vv),(u+sign*.07,vv+.065),(u+sign*.105,vv+.008),(u+sign*.07,vv-.045),(u,vv)]
    tube(c,pts,.008,'gilt',d+.004)
  # fine beadwork and tiny square studs at each framed corner
  for u in [-span*.34,span*.34]:
   for v in [-.17,.17]:
    obox(c,u,d,v,.04,.035,.04,'gilt')
 # additional continuous stepped rails following boundary, dark carved top moulding
 for dh,depth,r,ma in [(1.30,.02,.065,'basalt'),(1.38,.02,.025,'gilt'),(.31,.04,.035,'gilt')]:
  b.tube([tuple(p+n*depth+up*dh) for p in path],r,ma,8)
 root=b.finish('Foreground rail 09 / oriented lotus and ruyi relief',(0,0,0));root['type']='Additive detail only; exact V2 diagonal boundary retained';return root
