"""Coherent revision12: open galleries, hooked ancient arm, layered sky and cloud ocean."""
import bpy,os,sys,math,json
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT);s=bpy.context.scene
if s.get('Coherent revision12 applied'):raise RuntimeError('Revision12 already applied')
from environment_study12 import apply_environment12
from foliage_revision12 import apply_foliage_revision
from overhead_revision12 import apply_overhead_revision
apply_environment12();apply_foliage_revision();apply_overhead_revision()
for o in list(bpy.data.objects):
 if o.name.startswith('HERO •'):
  d=o.data;typ=o.type;bpy.data.objects.remove(o,do_unlink=True)
  if d and d.users==0:
   if typ=='MESH':bpy.data.meshes.remove(d)
   elif typ=='CURVE':bpy.data.curves.remove(d)
from hero_tree_v8 import build_tree
build_tree(root=(14,30,10),scale=1)
# Physical horizon contribution with the existing directional blue atmosphere.
n=s.world.node_tree.nodes;l=s.world.node_tree.links;halo=next(q for q in n if q.bl_idname=='ShaderNodeMixRGB' and q.blend_type=='ADD');grad=halo.inputs[1].links[0].from_socket
sky=n.new('ShaderNodeTexSky');sky.sky_type='NISHITA';sky.sun_disc=False;sky.sun_elevation=math.radians(3);sky.sun_rotation=math.atan2(50,355);sky.altitude=.1;sky.air_density=1;sky.dust_density=.5;sky.ozone_density=1.5
scale=n.new('ShaderNodeMixRGB');scale.blend_type='MULTIPLY';scale.inputs[0].default_value=1;scale.inputs[2].default_value=(.15,.15,.15,1);l.new(sky.outputs[0],scale.inputs[1]);mix=n.new('ShaderNodeMixRGB');mix.inputs[0].default_value=.6;l.new(grad,mix.inputs[1]);l.new(scale.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],halo.inputs[1])
for q in n:
 if q.bl_idname=='ShaderNodeVectorMath' and q.operation=='DOT_PRODUCT':q.inputs[1].default_value=tuple(-(Vector((50,300,22))-s.camera.location).normalized())
from sky_mask12 import apply_sky_mask12
apply_sky_mask12()
from cloud_canopy12 import apply_cloud_canopy12
apply_cloud_canopy12()
for o in bpy.data.objects:
 if o.name.startswith('REV12 CANOPY | connected middle'):
  for v in o.data.vertices:v.co.z+=2*max(0,min(1,(70-v.co.y)/45))
  o.data.update()
 if o.name.startswith('REV12 CANOPY | connected lower'):
  o.location.y-=6;o.location.z+=2.4
  for v in o.data.vertices:
   x,y,z=v.co;top=max(0,min(1,(z+.5)/5));v.co.z+=(math.exp(-((x-8)/4.5)**2)-1.6*math.exp(-((x-17)/3.8)**2)+1.3*math.exp(-((x-26)/4)**2))*top
  o.data.update()
 if any(o.name.startswith('Cloud canyon | luminous bank %02d'%i) for i in [0,1,2]):o.hide_render=True
 if o.name.startswith('REV11 | cliff embracing cloud crown'):
  idx=int(o.name.split()[-1].split('.')[0])
  if idx in [0,2,3,6,9,11]:o.hide_render=False;o.hide_viewport=False;o.scale*=.83
  if idx==8:o.hide_render=False;o.hide_viewport=False;o.scale*=.95;o.location.z+=.55
m=bpy.data.materials['REV12 CANOPY | dense ivory scattering and blue cavities']
for q in m.node_tree.nodes:
 if q.type=='MAP_RANGE' and abs(q.inputs['To Min'].default_value-.34)<.01:q.inputs['To Min'].default_value=1.2;q.inputs['To Max'].default_value=3.6
# Artistic light linking isolates cloud rims from reflective roofs.
d=bpy.data.lights.new('REV12 | warm upper cloud rim','AREA');d.energy=65000;d.color=(1,.55,.25);d.shape='DISK';d.size=12;o=bpy.data.objects.new(d.name,d);bpy.context.collection.objects.link(o);o.location=(35,58,27);o.rotation_euler=(Vector((8,22,4))-o.location).to_track_quat('-Z','Y').to_euler()
receivers=bpy.data.collections.new('REV12 | cloud light receivers only');s.collection.children.link(receivers)
for ob in bpy.data.objects:
 if ob.type=='MESH' and any('cloud' in m.name.lower() or 'canopy' in m.name.lower() for m in ob.data.materials if m):receivers.objects.link(ob)
o.light_linking.receiver_collection=receivers;bpy.data.lights['Warm cloud bounce'].energy=500
bpy.context.view_layer.update();origin=s.camera.location.copy();target=Vector((50,300,22));ray=(target-origin).normalized();blockers=[]
for ob in bpy.data.objects:
 if ob.type=='MESH' and not ob.hide_render and any(k in ob.name.lower() for k in ['cloud','canopy']):
  inv=ob.matrix_world.inverted();ok,co,n,idx=ob.ray_cast(inv@origin,(inv.to_3x3()@ray).normalized())
  if ok and (ob.matrix_world@co-origin).length<(target-origin).length:blockers.append(ob.name)
if blockers:raise RuntimeError('Sun cloud blockers: '+str(blockers))
s['Coherent revision12 applied']=True;s['Cloud rim lighting']='Artistic receiver-linked area light; real Cycles geometry and volumes.'
json.dump({'revision':12,'sun_cloud_blockers':blockers,'cloud_light_receivers':len(receivers.objects),'status':'geometry preflight passed; visual verification required'},open(os.path.join(ROOT,'revision12_validation.json'),'w'),indent=2)
s.cycles.samples=96;s.cycles.use_denoising=False;s.cycles.adaptive_threshold=.035;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_12.png');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_可编辑.blend'),compress=True)
if os.environ.get('MEGASCENE_BUILD_ONLY')!='1':bpy.ops.render.render(write_still=True)
