"""Rev11 material aging and actual moon-gate relief. No layout or light changes.
Run apply_architecture_revision() once on the phase10 scene.
"""
import bpy, math
from math import sin,cos,pi
from mathutils import Vector
from architecture import Batch

def _new_weathered(name,low,high,metal,rough):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;m.diffuse_color=(*high,1);n=m.node_tree.nodes;ln=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 g=n.new('ShaderNodeNewGeometry');no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=5;no.inputs['Detail'].default_value=5;no.inputs['Roughness'].default_value=.8;ln.new(g.outputs['Position'],no.inputs['Vector']);r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.23;r.color_ramp.elements[0].color=(*low,1);r.color_ramp.elements[1].position=.78;r.color_ramp.elements[1].color=(*high,1);ln.new(no.outputs['Fac'],r.inputs[0]);ln.new(r.outputs[0],p.inputs['Base Color'])
 fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=36;fine.inputs['Detail'].default_value=3;ln.new(g.outputs['Position'],fine.inputs['Vector']);bu=n.new('ShaderNodeBump');bu.inputs['Strength'].default_value=.26;bu.inputs['Distance'].default_value=.018;ln.new(fine.outputs['Fac'],bu.inputs['Height']);ln.new(bu.outputs['Normal'],p.inputs['Normal']);return m

def _age_existing_materials():
 changed=[]
 woods={
  'Pavilion · ebonized cedar':((.011,.022,.023),(.043,.061,.053)),
  'Pavilion · aged oxblood lacquer':((.013,.026,.025),(.057,.070,.048)),
  'Court • black lacquer':((.012,.023,.027),(.033,.052,.053)),
 }
 for m in list(bpy.data.materials):
  if not m.use_nodes or m.get('rev11_aged'):continue
  p=m.node_tree.nodes.get('Principled BSDF')
  if p is None:continue
  wood=m.name in woods
  metal=m.name.startswith(('Court •','Pavilion ·')) and ('gilt' in m.name.lower() or 'bronze' in m.name.lower() or 'antique gold' in m.name.lower())
  stone=m.name in ['Court • blue grey carved stone','Pavilion · weathered grey limestone']
  if not (wood or metal or stone):continue
  n=m.node_tree.nodes;ln=m.node_tree.links;g=n.new('ShaderNodeNewGeometry');g.label='Rev11 world-scale weathering';no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=2.8 if wood else 3.7;no.inputs['Detail'].default_value=5;no.inputs['Roughness'].default_value=.78;ln.new(g.outputs['Position'],no.inputs['Vector'])
  if wood:
   lo,hi=woods[m.name];p.inputs['Metallic'].default_value=.12 if 'cedar' in m.name else .22
  elif metal:
   lo=(.095,.073,.037);hi=(.40,.245,.085);p.inputs['Metallic'].default_value=.78
  else:
   lo=(.065,.091,.104);hi=(.19,.235,.25);p.inputs['Metallic'].default_value=.08
  ramp=n.new('ShaderNodeValToRGB');ramp.label='Rev11 aged pigment variation';ramp.color_ramp.elements[0].position=.25;ramp.color_ramp.elements[0].color=(*lo,1);ramp.color_ramp.elements[1].position=.8;ramp.color_ramp.elements[1].color=(*hi,1);ln.new(no.outputs['Fac'],ramp.inputs[0]);ln.new(ramp.outputs[0],p.inputs['Base Color'])
  rm=n.new('ShaderNodeMapRange');rm.inputs['From Min'].default_value=.1;rm.inputs['From Max'].default_value=.9;rm.inputs['To Min'].default_value=.30 if metal else (.32 if wood else .45);rm.inputs['To Max'].default_value=.56 if metal else (.52 if wood else .72);ln.new(no.outputs['Fac'],rm.inputs['Value']);ln.new(rm.outputs['Result'],p.inputs['Roughness'])
  fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=32 if wood else 23;fine.inputs['Detail'].default_value=4;ln.new(g.outputs['Position'],fine.inputs['Vector']);bu=n.new('ShaderNodeBump');bu.inputs['Strength'].default_value=.15 if metal else .25;bu.inputs['Distance'].default_value=.007 if metal else (.012 if wood else .04);ln.new(fine.outputs['Fac'],bu.inputs['Height']);ln.new(bu.outputs['Normal'],p.inputs['Normal'])
  m['rev11_aged']=True;changed.append(m.name)
 return changed

def _ring_relief():
 if bpy.data.objects.get('Rev11 / carved moon-gate relief'):return None
 mats={
 'stone':_new_weathered('Rev11 • weathered dark gate relief',(.025,.042,.049),(.105,.14,.15),.07,.62),
 'patina':_new_weathered('Rev11 • oxidized bronze bas-relief',(.035,.065,.052),(.19,.17,.095),.63,.48),
 'edge':_new_weathered('Rev11 • rubbed gilt high points',(.14,.09,.025),(.36,.22,.065),.75,.38)
 }
 b=Batch(mats);C=Vector((10,45.3,22.5))
 for k in range(48):
  a=2*pi*(k+.5)/48;radial=Vector((cos(a),0,sin(a)));tangent=Vector((-sin(a),0,cos(a)));front=Vector((0,-1,0));base=C+radial*22.5
  def p(u,v,h=0):return tuple(base+tangent*u+radial*v+front*h)
  # Individually chamfered inset stone fields: front surfaces remain within the widened band.
  w=2.53;hh=1.43;ch=.13;outline=[(-w/2+ch,-hh/2),(w/2-ch,-hh/2),(w/2,-hh/2+ch),(w/2,hh/2-ch),(w/2-ch,hh/2),(-w/2+ch,hh/2),(-w/2,hh/2-ch),(-w/2,-hh/2+ch)]
  # low-profile stepped perimeter is mass, not a new continuous circle bar
  vs=[p(u,v,h) for h in [-.075,-.012] for u,v in outline];fs=[tuple(range(7,-1,-1)),tuple(range(8,16))]+[(i,(i+1)%8,(i+1)%8+8,i+8) for i in range(8)];b.mesh(vs,fs,'stone')
  # eight sculpted lotus petals, convex lobes rather than wire ornaments
  for j in range(8):
   ang=j*pi/4+(k%2)*.12;vv=[];ff=[];rings=6;steps=10
   for q in range(rings):
    rr=q/(rings-1)
    for l in range(steps):
     t=l/(steps-1)*2*pi;length=.13+.35*(1+cos(t))*.5;width=.135*sin(t);u=(length*cos(ang)-width*sin(ang))*rr;v=(length*sin(ang)+width*cos(ang))*rr;h=.022+.095*(1-rr**2)+.025*cos(t)*rr
     vv.append(p(u,v,h))
   for q in range(rings-1):
    for l in range(steps-1):o=q*steps+l;ff.append((o,o+1,o+steps+1,o+steps))
   b.mesh(vv,ff,'patina' if j%3 else 'stone')
   # selectively rubbed crest on alternate petals, discontinuous and understated
   if j%2==0:b.tube([p(.14*cos(ang),.14*sin(ang),.115),p(.30*cos(ang),.30*sin(ang),.078),p(.42*cos(ang),.42*sin(ang),.038)],.018,'edge',6)
  # hammered central boss with irregular scallop silhouette
  vv=[];ff=[]
  for q in range(4):
   rr=.13*q/3
   for j in range(24):
    ang=j*2*pi/24;r=rr*(1+.07*cos(8*ang));vv.append(p(r*cos(ang),r*sin(ang),.14-.07*(q/3)**2))
  for q in range(3):
   for j in range(24):o=q*24+j;n=q*24+(j+1)%24;ff.append((o,n,n+24,o+24))
  b.mesh(vv,ff,'patina')
  # paired thick cloud-scroll relief to each side; terminating leaf lobes.
  for sign in [-1,1]:
   for offset,scale in [(0,.32),(.34,.16),(-.34,.16)]:
    pts=[];rads=[]
    for j in range(29):
     t=j/28*2.65*pi;rr=scale*(1-j/36);u=sign*(.81+rr*cos(t));v=offset+rr*sin(t)*.82;pts.append(p(u,v,.043+.012*sin(t)));rads.append(.026+.022*(1-j/28))
    b.tube(pts,.04,'patina',8,radii=rads)
   for signv in [-1,1]:
    # solid leaf teardrop joining paired scrolls, slightly chipped asymmetric rim
    coords=[(.58,.13),(.73,.26),(.9,.28),(.82,.13),(.58,.13)];v=[p(sign*u,signv*vv,.055) for u,vv in coords];v.append(p(sign*.76,signv*.18,.10));b.mesh(v,[(5,j,j+1) for j in range(4)],'stone')
  # joints and discrete patinated studs reinforce monumental masonry rhythm.
  for sign in [-1,1]:
   b.tube([p(sign*1.19,-.52,.015),p(sign*1.22,0,.028),p(sign*1.19,.52,.015)],.025,'stone',6)
  for u in [-1.05,1.05]:
   for v in [-.52,.52]:b.sphere(p(u,v,.03),.055,'patina')
 root=b.finish('Rev11 / carved moon-gate relief',(0,0,0))
 # curved bronze lobe and tube surfaces should shade continuously; stone fields keep bevels.
 for ob in root.children:
  if ob.type=='MESH' and not ob.name.endswith('/ stone'):
   for f in ob.data.polygons:f.use_smooth=True
 root['note']='Carved segmented relief inside existing ring band; no added full-circle bars or layout changes'
 return root

def apply_architecture_revision():
 changes=_age_existing_materials();root=_ring_relief();print('Rev11 architecture material revisions:',changes)
 if root:print('Rev11 ring relief vertices:',sum(len(o.data.vertices) for o in root.children if o.type=='MESH'))
 return root
