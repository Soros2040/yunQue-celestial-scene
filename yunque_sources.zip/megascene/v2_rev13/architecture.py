"""Detailed editable Chinese pavilion kit. All geometry local, batched by material.
Use build_pavilion(name, center, width, depth, stories, story_height, seed).
No downloads, no scene reset, no cameras or lights.
"""
import bpy, math, random
from mathutils import Vector
from math import sin,cos,pi

def _mat(name, col, metal=0, rough=.4, emission=0, bump=.03):
 name='Pavilion · '+name
 if name in bpy.data.materials:return bpy.data.materials[name]
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*col,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emission:p.inputs['Emission Color'].default_value=(*col,1);p.inputs['Emission Strength'].default_value=emission
 if bump:
  t=n.new('ShaderNodeTexNoise');t.inputs['Scale'].default_value=23;t.inputs['Detail'].default_value=3;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.25;b.inputs['Distance'].default_value=bump;m.node_tree.links.new(t.outputs['Fac'],b.inputs['Height']);m.node_tree.links.new(b.outputs['Normal'],p.inputs['Normal'])
 return m

def _materials():
 return {
 'wood':_mat('ebonized cedar',(.032,.023,.015),.08,.34,bump=.025),
 'red':_mat('aged oxblood lacquer',(.095,.027,.015),.25,.27,bump=.009),
 'gold':_mat('worn gilt bronze',(.48,.255,.065),.78,.25,bump=.012),
 'tile':_mat('ink blue glazed ceramic',(.018,.046,.061),.28,.31,bump=.017),
 'tile2':_mat('varied slate tile',(.033,.071,.079),.25,.4,bump=.019),
 'stone':_mat('weathered grey limestone',(.29,.32,.32),.1,.48,bump=.05),
 'dark':_mat('shadowed wall plaster',(.075,.087,.082),0,.74,bump=.025),
 'silk':_mat('amber lantern silk',(.9,.43,.11),0,.48,2.0,bump=0),
 'paper':_mat('dim rice paper screens',(.19,.135,.07),0,.65,.12,bump=.005)
 }

class Batch:
 def __init__(self,mats):self.mats=mats;self.data={k:([],[]) for k in mats}
 def mesh(self,vs,fs,ma):
  v,f=self.data[ma];o=len(v);v.extend(vs);f.extend(tuple(o+i for i in q) for q in fs)
 def box(self,loc,size,ma='wood'):
  x,y,z=loc;a,b,c=[v*.5 for v in size]
  self.mesh([(x+u*a,y+v*b,z+w*c) for u,v,w in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]],[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],ma)
 def tube(self,pts,r,ma='gold',sides=8,radii=None):
  vs=[];fs=[]
  for i,p in enumerate(pts):
   p=Vector(p);t=Vector(pts[min(i+1,len(pts)-1)])-Vector(pts[max(i-1,0)]);t.normalize();ref=Vector((0,0,1)) if abs(t.z)<.95 else Vector((1,0,0));a=t.cross(ref).normalized();b=t.cross(a).normalized();rr=radii[i] if radii else r
   for j in range(sides):vs.append(tuple(p+rr*(a*cos(j*2*pi/sides)+b*sin(j*2*pi/sides))))
  for i in range(len(pts)-1):
   for j in range(sides):a=i*sides+j;bb=i*sides+(j+1)%sides;fs.append((a,bb,bb+sides,a+sides))
  fs += [tuple(range(sides-1,-1,-1)),tuple((len(pts)-1)*sides+j for j in range(sides))];self.mesh(vs,fs,ma)
 def cylinder(self,loc,r,h,ma='wood',sides=16):self.tube([(loc[0],loc[1],loc[2]-h/2),(loc[0],loc[1],loc[2]+h/2)],r,ma,sides)
 def sphere(self,loc,r,ma='gold'):
  vs=[];fs=[]
  for i in range(7):
   th=pi*i/6
   for j in range(12):a=j*2*pi/12;vs.append((loc[0]+r*sin(th)*cos(a),loc[1]+r*sin(th)*sin(a),loc[2]+r*cos(th)))
  for i in range(6):
   for j in range(12):a=i*12+j;bb=i*12+(j+1)%12;fs.append((a,bb,bb+12,a+12))
  self.mesh(vs,fs,ma)
 def finish(self,name,center):
  root=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(root);root.location=center
  for k,(v,f) in self.data.items():
   if not v:continue
   me=bpy.data.meshes.new(name+' '+k);me.from_pydata(v,[],f);me.materials.append(self.mats[k]);me.update();ob=bpy.data.objects.new(name+' / '+k,me);bpy.context.collection.objects.link(ob);ob.parent=root
   # geometry has true round tubes; preserve flat carved/structural faces
   if k in ['gold','tile','tile2','silk']:
    for p in me.polygons:p.use_smooth=True
  return root

def build_pavilion(name, center=(0,0,0), width=12, depth=9, stories=2, story_height=4.2, seed=1):
 rng=random.Random(seed);mats=_materials();b=Batch(mats);sc=width/12;w=width;d=depth
 # helpers all in local coordinates
 def band(z,ww,dd,thick,ma):
  for side in [-1,1]:
   b.box((0,side*dd/2,z),(ww,thick,thick),ma);b.box((side*ww/2,0,z),(thick,dd,thick),ma)
 def scroll(cx,cy,cz,size=.22,axis='xz'):
  # curling gilt foliage decoration
  pts=[]
  for j in range(25):
   a=j/24*pi*2.6;rr=size*(1-j/32);xx=rr*cos(a);zz=rr*sin(a)
   pts.append((cx+xx,cy,cz+zz) if axis=='xz' else (cx,cy+xx,cz+zz))
  b.tube(pts,.018*sc,'gold',5)
 def railing(ww,dd,z):
  # solid stone parapet base and carved infill, all four sides
  for axis,length,offset in [('x',ww,dd/2),('y',dd,ww/2)]:
   for side in [-1,1]:
    n=max(2,int(length/(1.7*sc)));step=length/n
    for dz in [.15,.92]:b.box((0,side*offset,z+dz) if axis=='x' else (side*offset,0,z+dz),(length,.12*sc,.12*sc) if axis=='x' else (.12*sc,length,.12*sc),'wood')
    for i in range(n+1):
     q=-length/2+i*step;xx,yy=(q,side*offset) if axis=='x' else (side*offset,q)
     b.box((xx,yy,z+.52),(.19*sc,.19*sc,1.04*sc),'stone');b.box((xx,yy,z+1.08*sc),(.29*sc,.29*sc,.13*sc),'gold');b.sphere((xx,yy,z+1.2*sc),.095*sc,'stone')
    for i in range(n):
     q=-length/2+(i+.5)*step;xx,yy=(q,side*offset) if axis=='x' else (side*offset,q)
     b.box((xx,yy,z+.51*sc),(step-.25*sc,.08*sc,.44*sc) if axis=='x' else (.08*sc,step-.25*sc,.44*sc),'wood')
     # raised golden framed panel and scroll rosette
     for dz in [-.18,.18]:b.box((xx,yy,z+.51*sc+dz*sc),(step-.36*sc,.1*sc,.025*sc) if axis=='x' else (.1*sc,step-.36*sc,.025*sc),'gold')
     scroll(xx,yy-.05*sc if axis=='x' else yy,z+.51*sc,.15*sc,'xz' if axis=='x' else 'yz')
 def roof(ww,dd,z,story):
  rw=ww+3.0*sc;rd=dd+3.0*sc;rise=2.3*sc
  def p(u,v,offset=0):
   t=max(abs(v),max(0,(abs(u)-.48)/.52));zz=rise*max(0,1-t)**1.65+.7*sc*abs(u)**7*abs(v)**7
   return (u*rw/2,v*rd/2,z+zz+offset)
  # dense continuous underside and ceramic surface
  for dz,ma in [(-.13*sc,'wood'),(0,'tile')]:
   nu=40;nv=32;vs=[p(-1+2*i/nu,-1+2*j/nv,dz) for i in range(nu+1) for j in range(nv+1)];fs=[]
   for i in range(nu):
    for j in range(nv):a=i*(nv+1)+j;fs.append((a,a+1,a+nv+2,a+nv+1))
   b.mesh(vs,fs,ma)
  # continuous raised tile rolls, separately jointed with overlap caps
  count=max(20,int(rw/(.27*sc)))
  for i in range(count+1):
   u=-1+2*i/count
   for side in [-1,1]:
    vmax=max(.02,1-(max(0,abs(u)-.48)/.52)); start=0
    # full slope ribs and shallow intermediate cover joints
    pts=[p(u,side*j/20,.045*sc) for j in range(21)];b.tube(pts,.058*sc,'tile2' if i%7==0 else 'tile',7)
    for j in range(1,12):
     v=side*j/12;pp=p(u,v,.06*sc)
     b.tube([p(u-.008,v,.065*sc),pp,p(u+.008,v,.065*sc)],.067*sc,'tile2' if (i+j)%9==0 else 'tile',6)
    # round hanging eave tile caps
    q=p(u,side,.005*sc);b.tube([(q[0],q[1]-.06*side*sc,q[2]),(q[0],q[1]+.12*side*sc,q[2])],.085*sc,'gold' if i%5==0 else 'tile',10)
  # edge apron: three layered sweeping gilt bands and exposed structural rafters
  for h in [0,-.13,-.28]:
   for side in [-1,1]:
    b.tube([p(-1+2*j/40,side,h*sc) for j in range(41)],(.06 if h==0 else .045)*sc,'gold',8)
    b.tube([p(side,-1+2*j/32,h*sc) for j in range(33)],.05*sc,'gold',8)
  for i in range(max(12,int(rw/.55))):
   u=-.95+1.9*i/(max(12,int(rw/.55))-1)
   for side in [-1,1]:b.tube([p(u,.75*side,-.2*sc),p(u,side,-.2*sc)],.075*sc,'red',8)
  # hip seams diagonally out to each raised corner
  for su in [-1,1]:
   for sv in [-1,1]:b.tube([p(su*(.48+.52*j/20),sv*j/20,.12*sc) for j in range(21)],.10*sc,'gold',8)
  b.tube([p(-.5+1.0*j/20,0,.15*sc) for j in range(21)],.15*sc,'tile2',10)
  for su in [-1,1]:
   q=p(su*.5,0,.2*sc)
   pts=[q,(q[0]+su*.3*sc,0,q[2]+.1*sc),(q[0]+su*.55*sc,0,q[2]+.55*sc),(q[0]+su*.4*sc,0,q[2]+1.1*sc),(q[0]+su*.1*sc,0,q[2]+1.25*sc)]
   b.tube(pts,.13*sc,'gold',10,radii=[.17*sc,.16*sc,.12*sc,.09*sc,.02*sc]);b.sphere((q[0]+su*.34*sc,-.09*sc,q[2]+.95*sc),.045*sc,'gold')
   for sv in [-1,1]:
    q=p(su,sv,.08*sc);b.tube([q,(q[0]+su*.28*sc,q[1]+sv*.28*sc,q[2]+.3*sc),(q[0]+su*.3*sc,q[1]+sv*.3*sc,q[2]+.65*sc)],.085*sc,'gold',8)
 def lantern(x,y,z):
  h=.72*sc;r=.19*sc;b.cylinder((x,y,z),r,h,'silk',8)
  for zz in [-h/2,h/2]:
   b.cylinder((x,y,z+zz),r*1.32,.08*sc,'gold',8);b.cylinder((x,y,z+zz*1.18),r*1.5,.07*sc,'wood',8)
  for i in range(8):a=2*pi*i/8;b.tube([(x+r*cos(a),y+r*sin(a),z-h/2),(x+r*cos(a),y+r*sin(a),z+h/2)],.024*sc,'wood',6)
  b.tube([(x,y,z+h/2),(x,y,z+h/2+.6*sc)],.015*sc,'gold',6)
  b.tube([(x,y,z-h/2),(x,y,z-h/2-.45*sc)],.018*sc,'red',5)
 # plinth stair treads
 for i in range(3):b.box((0,0,-.45*sc+i*.15*sc),(w+2.0*sc-i*.3*sc,d+2.0*sc-i*.3*sc,.18*sc),'stone')
 for k in range(stories):
  z=k*story_height;ww=w*(.89**k);dd=d*(.89**k);height=story_height*.8
  b.box((0,0,z),(ww+1.2*sc,dd+1.2*sc,.24*sc),'wood')
  band(z-.12*sc,ww+1.4*sc,dd+1.4*sc,.12*sc,'gold');band(z+.08*sc,ww+1.25*sc,dd+1.25*sc,.07*sc,'gold')
  railing(ww+1.1*sc,dd+1.1*sc,z+.12*sc)
  # back and side screens set inward, leave open foreground colonnade
  b.box((0,dd*.23,z+height*.5),(ww*.78,.13*sc,height*.9),'dark')
  for side in [-1,1]:b.box((side*ww*.39,dd*.06,z+height*.5),(.13*sc,dd*.36,height*.9),'dark')
  bays=max(3,round(ww/(2.1*sc)))
  for i in range(bays):
   xx=-ww*.36+(i+.5)*(ww*.72/bays);bw=ww*.72/bays*.78;hh=height*.61;zz=z+height*.56
   b.box((xx,dd*.23-.08*sc,zz),(bw,.04*sc,hh),'paper')
   for dx in [-bw/2,bw/2]:b.box((xx+dx,dd*.23-.13*sc,zz),(.06*sc,.08*sc,hh+.1*sc),'red')
   for j in range(6):
    x=xx-bw/2+j*bw/5;b.box((x,dd*.23-.14*sc,zz),(.027*sc,.06*sc,hh),'gold' if j in [0,5] else 'wood')
   for j in range(7):b.box((xx,dd*.23-.15*sc,zz-hh/2+j*hh/6),(bw,.05*sc,.026*sc),'wood')
   # upper transom lattice diamonds
   for j in range(4):
    xc=xx-bw*.36+j*bw*.24;zc=z+height*.85;sz=bw*.11
    b.tube([(xc-sz,dd*.23-.17*sc,zc),(xc,dd*.23-.17*sc,zc+sz),(xc+sz,dd*.23-.17*sc,zc),(xc,dd*.23-.17*sc,zc-sz),(xc-sz,dd*.23-.17*sc,zc)],.023*sc,'gold',5)
  # circular columns with stone bases, multiple brass collars and carved capitals
  for side in [-1,1]:
   n=max(4,round(ww/(2.0*sc)))
   for i in range(n+1):
    xx=-ww/2+i*ww/n;yy=side*dd/2
    b.cylinder((xx,yy,z+height/2),.15*sc,height,'red',16)
    b.cylinder((xx,yy,z+.18*sc),.25*sc,.3*sc,'stone',16)
    for zz,rr in [(z+.35*sc,.19),(z+height-.25*sc,.21),(z+height-.05*sc,.29)]:b.cylinder((xx,yy,zz),rr*sc,.09*sc,'gold',16)
    # stacked dougong cross arms with notched tips and scrolls
    for j in range(4):
     zz=z+height-.1*sc+j*.18*sc;span=(.45+j*.27)*sc
     b.box((xx,yy+side*j*.11*sc,zz),(span,.22*sc,.14*sc),'red' if j%2 else 'wood')
     for ss in [-1,1]:b.box((xx+ss*(span/2-.07*sc),yy+side*j*.11*sc,zz+.08*sc),(.13*sc,.28*sc,.1*sc),'gold')
     b.box((xx,yy+side*j*.15*sc,zz+.10*sc),(.18*sc,span*.8,.11*sc),'wood')
    if i%2==0:scroll(xx,yy-side*.14*sc,z+height-.4*sc,.18*sc)
   for zz in [height-.45*sc,height-.12*sc]:b.box((0,side*dd/2,z+zz),(ww+.5*sc,.25*sc,.22*sc),'wood')
   # relief frets on front beam
   for i in range(n*3):
    xx=-ww/2+(i+.5)*ww/(n*3);scroll(xx,side*(dd/2+.14*sc),z+height-.45*sc,.09*sc)
  # lateral columns also form visible open porches
  for side in [-1,1]:
   for yy in [-dd*.25,0,dd*.25]:
    b.cylinder((side*ww/2,yy,z+height/2),.15*sc,height,'red',16)
    b.cylinder((side*ww/2,yy,z+.16*sc),.24*sc,.26*sc,'stone',16)
   b.box((side*ww/2,0,z+height-.2*sc),(.25*sc,dd,.25*sc),'wood')
  for side in [-1,1]:
   for sx in [-1,1]:lantern(sx*(ww/2-.5*sc),side*(dd/2-.1*sc),z+height-.75*sc)
  roof(ww,dd,z+height+.42*sc,k)
 root=b.finish(name,center)
 root['style']='Carved dougong, true curved ceramic roofs, open colonnade, gilded lattice';root['stories']=stories
 return root
