import bpy,os
from mathutils import Vector
s=bpy.context.scene;ROOT=os.path.dirname(os.path.abspath(__file__))
o=bpy.data.objects['Golden sunset bounce'];o.location=(17,43,22);o.data.energy=48000;o.data.size=6;o.data.color=(1,.45,.12);o.rotation_euler=(Vector((16,28,24))-o.location).to_track_quat('-Z','Y').to_euler()
bpy.data.lights['Golden reflected light on wet stone'].energy=3200
m=bpy.data.materials['Sun • luminous gold'];p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=(1,.28,.018,1);p.inputs['Emission Strength'].default_value=16
for n in s.world.node_tree.nodes:
 if n.bl_idname=='ShaderNodeMixRGB' and n.blend_type=='ADD':n.inputs[2].default_value=(2.4,.65,.035,1)
s.cycles.samples=96;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'rim08_study.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_08light.blend'));
if os.environ.get('MEGASCENE_BUILD_ONLY') != '1': bpy.ops.render.render(write_still=True)
