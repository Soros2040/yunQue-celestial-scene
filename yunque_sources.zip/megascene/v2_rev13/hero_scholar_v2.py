"""Standalone, non-destructive replacement candidate for the terrace scholar.
Actual modeled cloth layers, hair, folds and gold piping. Faces +Y.
Call build_scholar(root=(-13.5,-10,8), height=2.7). No scene reset or rendering.
"""
import bpy, math, random
from mathutils import Vector

def build_scholar(root=(-13.5,-10,8),height=2.7):
    rng=random.Random(3917); P='SCHOLAR V2 • '
    col=bpy.data.collections.new(P+'Layered celestial silk');bpy.context.scene.collection.children.link(col)
    anchor=bpy.data.objects.new(P+'placement',None);col.objects.link(anchor);anchor.location=root;anchor.scale=(height,height,height);anchor['height']=height;anchor['facing']='+Y, camera sees long dark back hair'
    def material(name,color,rough,metal=0):
        m=bpy.data.materials.new(P+name);m.diffuse_color=(*color,1);m.use_nodes=True;bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=rough;bs.inputs['Metallic'].default_value=metal
        return m
    silk=material('ivory silk outer robe',(.73,.69,.59),.38);silk.node_tree.nodes.get('Principled BSDF').inputs['Sheen Weight'].default_value=.28
    inner=material('cloud silver inner folds',(.55,.58,.59),.46);inner.node_tree.nodes.get('Principled BSDF').inputs['Sheen Weight'].default_value=.15
    white=material('warm white gauze lining',(.86,.82,.72),.48)
    gold=material('restrained old gold embroidery',(.40,.23,.074),.31,.67)
    hair=material('long black brown hair',(.012,.009,.007),.31)
    hairlight=material('fine hair glints',(.037,.025,.014),.39)
    skin=material('warm skin only at face and hands',(.49,.32,.22),.63)
    shoe=material('ivory shoes',(.45,.43,.37),.55)
    def mesh(name,v,f,mat,thick=0):
        me=bpy.data.meshes.new(P+name);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(P+name,me);col.objects.link(ob);ob.parent=anchor;me.materials.append(mat)
        for poly in me.polygons:poly.use_smooth=True
        if thick:
            mod=ob.modifiers.new('Physical cloth thickness','SOLIDIFY');mod.thickness=thick;mod.offset=0
        return ob
    def curve(name,paths,r,mat):
        cu=bpy.data.curves.new(P+name,'CURVE');cu.dimensions='3D';cu.resolution_u=2;cu.bevel_depth=r;cu.bevel_resolution=2
        for path in paths:
            sp=cu.splines.new('POLY');sp.points.add(len(path)-1)
            for point,co in zip(sp.points,path):point.co=(*co,1)
        ob=bpy.data.objects.new(P+name,cu);col.objects.link(ob);ob.parent=anchor;cu.materials.append(mat);return ob
    def ellipsoid(name,center,radii,mat,N=24,M=16):
        v=[];f=[]
        for j in range(M+1):
            theta=math.pi*j/M
            for i in range(N):
                a=math.tau*i/N;v.append((center[0]+radii[0]*math.sin(theta)*math.cos(a),center[1]+radii[1]*math.sin(theta)*math.sin(a),center[2]+radii[2]*math.cos(theta)))
        for j in range(M):
            for i in range(N):
                a=j*N+i;b=j*N+(i+1)%N;f.append((a,b,b+N,a+N))
        return mesh(name,v,f,mat)
    # Layered skirt. Deep nonuniform pleats and scalloped weighted hem, not a smooth cone.
    def skirt(name,outer,mat,phase):
        N=100;M=28;v=[];f=[];hem=[]
        for j in range(M+1):
            t=j/M;z=.028+.58*t
            base=(.215*(1-t)**1.45+.085)*outer
            for i in range(N):
                a=math.tau*i/N;fold=(.012+.024*(1-t))*(math.sin(a*13+phase+t*.7)+.31*math.sin(a*27-t*1.2))
                rr=base+fold;zz=z+(.008*math.sin(a*7+phase)+.004*math.sin(a*19))*(1-t)**8
                x=math.cos(a)*rr-.022*(1-t);y=math.sin(a)*rr*.66
                v.append((x,y,zz))
                if j==0:hem.append((x,y,zz))
        for j in range(M):
            for i in range(N):a=j*N+i;b=j*N+(i+1)%N;f.append((a,b,b+N,a+N))
        mesh(name,v,f,mat,.0018);return hem
    skirt('inner silver pleated skirt',.91,inner,.7)
    hem=skirt('outer ivory weighted skirt',1,silk,0)
    curve('slender skirt hem piping',[hem+[hem[0]]],.0019,gold)
    # Shaped torso and neck are covered by overlapping robe layers.
    v=[];f=[];N=52
    profile=[(.59,.092,.065),(.64,.084,.064),(.70,.12,.072),(.77,.164,.073),(.805,.143,.067),(.82,.068,.055)]
    for z,rx,ry in profile:
        for i in range(N):
            a=math.tau*i/N;v.append((rx*math.cos(a),ry*math.sin(a),z))
    for j in range(len(profile)-1):
        for i in range(N):a=j*N+i;b=j*N+(i+1)%N;f.append((a,b,b+N,a+N))
    mesh('overlapping fitted robe bodice',v,f,white)
    ellipsoid('covered neck',(0,.007,.833),(.041,.039,.057),skin)
    # Open outer coat falls from the shoulders, widening toward a long left/back hem.
    N=100;M=30;v=[];f=[];edges=[[],[]];backhem=[]
    for j in range(M+1):
        t=j/M;z=.035+.76*t
        radius=.23*(1-t)**1.4+.105
        if t>.78:radius=.105+(.167-.105)*math.sin((t-.78)/.22*math.pi*.5)
        for i in range(N+1):
            a=math.pi/2+.34+(math.tau-.68)*i/N
            fold=(.009+.025*(1-t))*math.sin(a*11+t*.8)+.006*math.sin(a*21-t*1.3)
            rr=radius+fold;x=math.cos(a)*rr-.045*(1-t);y=math.sin(a)*rr*.72-.012
            zz=z+.012*(1-t)**5*math.sin(a*5)
            v.append((x,y,zz))
            if i==0:edges[0].append((x,y,zz))
            if i==N:edges[1].append((x,y,zz))
            if j==0:backhem.append((x,y,zz))
    for j in range(M):
        for i in range(N):a=j*(N+1)+i;f.append((a,a+1,a+N+2,a+N+1))
    mesh('open multilayer outer coat',v,f,silk,.002)
    curve('outer coat gold edging',edges+[backhem],.0024,gold)
    # Crossed ivory lapels, each a broad actual cloth band; camera mainly sees back collar.
    lapels=[]
    for sign in (-1,1):
        path=[(sign*.055,.049,.842),(sign*.092,.083,.785),(sign*.055,.087,.72),(-sign*.028,.072,.635)]
        vv=[]
        for x,y,z in path:vv.extend([(x-sign*.016,y+.003,z),(x+sign*.016,y,z)])
        mesh('layered cross collar '+str(sign),vv,[(i*2,i*2+1,i*2+3,i*2+2) for i in range(3)],white,.0015);lapels.append(path)
    curve('fine collar gold border',lapels,.0015,gold)
    # Wide hanging sleeves. The lower cloth volume drops far below the visible wrists.
    for sign in (-1,1):
        N=64;M=22;v=[];f=[];cuff=[]
        for j in range(M+1):
            t=j/M;x=sign*(.135+.17*t);cz=.772-.14*t
            for i in range(N):
                a=math.tau*i/N;sy=math.cos(a);sz=math.sin(a)
                ry=.046+.062*t;rz=(.06+.02*t) if sz>0 else (.055+.205*t)
                ripple=.006*math.sin(a*9+t*3)+.003*math.sin(a*17-t*4)
                y=sy*(ry+ripple)-.014*t;z=cz+sz*(rz+ripple);xx=x+sign*.008*math.sin(a*3+t*2)
                v.append((xx,y,z))
                if j==M:cuff.append((xx,y,z))
        for j in range(M):
            for i in range(N):a=j*N+i;b=j*N+(i+1)%N;f.append((a,b,b+N,a+N))
        mesh('broad hanging sleeve '+str(sign),v,f,silk,.002);curve('gilded cuff edge '+str(sign),[cuff+[cuff[0]]],.0026,gold)
        ellipsoid('subtle hand '+str(sign),(sign*.319,.022,.626),(.024,.027,.041),skin,16,12)
    # Brocade waist band and two discreet pendants.
    belt=[]
    for i in range(81):
        a=math.tau*i/80;belt.append((.095*math.cos(a),.068*math.sin(a),.615+.003*math.sin(a*6)))
    curve('double waist sash',[belt,[(x,y,z-.018) for x,y,z in belt]],.006,silk)
    curve('sash gold embroidery',[[(x*1.015,y*1.015,z-.008) for x,y,z in belt]],.0025,gold)
    curve('fine waist pendants', [[(-.045,.073,.602),(-.052,.075,.51),(-.047,.074,.47)],[(.045,.073,.602),(.04,.075,.53),(.045,.073,.49)]],.0022,gold)
    # Broad asymmetric train lies on the terrace and curls toward camera-left/back.
    def train(name,width,length,mat,phase,lift):
        N=65;M=26;v=[];f=[];edges=[[],[]]
        for i in range(N+1):
            t=i/N;x=-.035-length*t;y=-.1-.54*t+.06*math.sin(t*math.pi*2+phase)
            centerz=.32*(1-t)**5+.009+lift*math.sin(t*math.pi)**2
            w=width*(.55+.7*math.sin(math.pi*t)**.8)*(1-.55*t**6)
            for j in range(M+1):
                u=2*j/M-1;xx=x+.15*u*w;yy=y+u*w;zz=centerz+(.009+.014*math.sin(math.pi*t))*math.sin(u*math.pi*4+t*8+phase)+.025*u*u
                zz=max(.002,zz);v.append((xx,yy,zz))
                if j==0:edges[0].append((xx,yy,zz))
                if j==M:edges[1].append((xx,yy,zz))
        for i in range(N):
            for j in range(M):a=i*(M+1)+j;f.append((a,a+1,a+M+2,a+M+1))
        mesh(name,v,f,mat,.0014);return edges
    train_edges=train('broad pooled trailing outer robe',.24,1.32,silk,0,.025)
    curve('train hem gold line',train_edges,.0017,gold)
    train('silver under-train',.16,1.43,inner,1.4,.018)
    # Wind-swept silk ribbons spring from shoulders then fall toward the broad train.
    for n in range(2):
        N=70;v=[];f=[];edge=[]
        for i in range(N+1):
            t=i/N;x=-.08-(1.5+n*.15)*t;y=-.1-(.46+n*.15)*t;z=.755*(1-t)**1.55+.14*math.sin(t*math.pi*1.6+n*.4)*(1-t)+.025
            width=(.026+n*.008)*(1-.5*t);twist=t*4+n
            for sign in (-1,1):v.append((x,y+sign*width*math.cos(twist),max(.018,z+sign*width*math.sin(twist))))
            edge.append(v[-1])
        for i in range(N):a=i*2;f.append((a,a+1,a+3,a+2))
        mesh('wind ribbon '+str(n),v,f,white,.0008);curve('ribbon fine gold edge '+str(n),[edge],.0011,gold)
    # Black cap and long half-up hair ensure the rear silhouette is not a bald mannequin.
    ellipsoid('dark full scalp hair',(0,-.002,.905),(.061,.065,.087),hair)
    ellipsoid('small front face',(0,.034,.898),(.048,.045,.069),skin)
    ellipsoid('half-up low knot',(-.004,-.022,.983),(.041,.035,.033),hair,24,16)
    N=24;M=32;v=[];f=[]
    for j in range(M+1):
        t=j/M;cz=.943-.49*t;cx=-.012-.085*t*t;cy=-.06-.045*math.sin(t*math.pi*.8);width=.049+.047*math.sin(math.pi*t)**.8-.028*t
        for i in range(N+1):
            u=2*i/N-1;z=cz+.025*u*u*t;x=cx+u*width;y=cy-.009*math.sin(i*.9+t*2)-.012*(1-u*u)
            v.append((x,y,z))
    for j in range(M):
        for i in range(N):a=j*(N+1)+i;f.append((a,a+1,a+N+2,a+N+1))
    mesh('long black flowing back hair',v,f,hair,.0012)
    strands=[]
    for n in range(28):
        u=(n/27)*2-1;path=[]
        for j in range(25):
            t=j/24;x=-.012-.085*t*t+u*(.049+.047*math.sin(math.pi*t)**.8-.028*t);y=-.074-.045*math.sin(t*math.pi*.8)-.007*math.sin(n*.9+t*2);z=.943-.49*t+.025*u*u*t
            path.append((x,y,z))
        strands.append(path)
    curve('fine long hair strands',strands,.0013,hairlight)
    # Two loose temple locks, and a modest gold comb across the half-up knot.
    curve('loose temple locks',[[(-.049,-.015,.944),(-.067,-.024,.86),(-.079,-.049,.76),(-.1,-.08,.67)],[(.049,-.015,.944),(.067,-.025,.85),(.059,-.06,.73),(.025,-.09,.63)]],.006,hair)
    curve('antique hairpin',[ [(-.072,-.026,.973),(.075,-.026,.973)], [(-.026,-.056,.969),(0,-.068,.978),(.028,-.056,.969)] ],.003,gold)
    curve('hairpin pendant',[[(-.03,-.055,.971),(-.038,-.063,.918),(-.031,-.062,.89)],[(.031,-.055,.971),(.038,-.063,.927),(.032,-.063,.903)]],.0017,gold)
    for sign in (-1,1):ellipsoid('hidden slipper '+str(sign),(sign*.07,.035,.025),(.047,.092,.026),shoe,18,10)
    return {'collection':col.name,'root_object':anchor.name,'objects':[o.name for o in col.objects],'object_count':len(col.objects),'height':height,'facing':'+Y','train_extent_local':(-1.75,-.9,0),'mesh_vertices':sum(len(o.data.vertices) for o in col.objects if o.type=='MESH')}
