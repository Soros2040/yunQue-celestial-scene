"""Additive landscape realism pass; call apply_landscape_revision() on phase10.
Actual volumetric crowns, grounded vegetation, and foamy cascade geometry.
No camera, world, lights, render settings or original meshes are deleted.
"""
import bpy, math, random
from mathutils import Vector, noise
from landscape_v4 import _mesh, _material, _tube_append, _cloud_material, _cloud_group
from supplemental_islands import _pine, _plant_materials


def _ground(ob,x,y):
    inv=ob.matrix_world.inverted()
    origin=inv@Vector((x,y,150));direction=(inv.to_3x3()@Vector((0,0,-1))).normalized()
    hit,loc,norm,index=ob.ray_cast(origin,direction)
    if not hit:return None
    return ob.matrix_world@loc


def _crowns():
    material=_cloud_material('REV11 | luminous fractured crown scattering')
    n=material.node_tree.nodes
    volume=next(x for x in n if x.type=='PRINCIPLED_VOLUME')
    volume.inputs['Color'].default_value=(.98,.99,1,1)
    volume.inputs['Anisotropy'].default_value=.12
    # Tiny multiple-scattering approximation lifts deep blue cavities without flat emission.
    volume.inputs['Emission Color'].default_value=(.29,.37,.55,1)
    volume.inputs['Emission Strength'].default_value=.012
    ramp=next(x for x in n if x.type=='VALTORGB')
    ramp.color_ramp.elements[0].position=.30
    ramp.color_ramp.elements[1].position=.63
    ramp.color_ramp.elements[1].color=(5,5,5,1)
    # Keep a continuous scattering core; old fine-noise/fade multiplied most lobes away.
    for node in n:
        if node.type=='TEX_NOISE' and node.inputs['Scale'].default_value < 2:
            node.inputs['Scale'].default_value=1.15
        if node.type=='MAP_RANGE':
            if node.inputs['To Min'].default_value > .9:
                node.inputs['From Min'].default_value=.42
                node.inputs['From Max'].default_value=.72
            else:
                node.inputs['To Min'].default_value=.24
                node.inputs['To Max'].default_value=1.15
    rng=random.Random(11031)
    specs=[
      ((5.8,15,5.2),(1.35,1.05,1.05)),
      ((12.5,15,5.0),(1.55,1.1,1.20)),
      ((20,15.2,5.4),(1.70,1.1,1.10)),
      ((27,19,5.8),(1.45,1.1,1.05)),
      ((8,7,3.1),(1.35,1.0,1.05)),
      ((13,7,3.5),(1.25,1.0,1.10)),
      ((13.8,-2,2.0),(1.35,1.05,1.05)),
      ((21,-1,2.1),(1.55,1.0,1.05)),
      ((25,5.5,3.0),(1.25,1.0,1.10)),
      ((29,7,3.1),(1.20,1.0,1.0)),
      ((19,-6,.9),(1.45,1.0,1.0)),
      ((25,-4,1.2),(1.40,1.0,1.15)),
      ((30,15.5,3.8),(1.20,1.0,1.1)),
      ((4,23,4.3),(1.4,1.1,1.15)),
    ]
    result=[]
    for i,(center,scale) in enumerate(specs):
        ob=_cloud_group('REV11 | cliff embracing cloud crown %02d'%i,center,scale,rng,material,lobes=8)
        # Localized secondary scalloping only: retain crown extents and the dense core,
        # but interrupt marble-smooth metaball outlines at two smaller spatial scales.
        low=Vector(tuple(min(v.co[k] for v in ob.data.vertices) for k in range(3)))
        high=Vector(tuple(max(v.co[k] for v in ob.data.vertices) for k in range(3)))
        offset=Vector((i*2.37,i*.73,i*1.19))
        for vertex in ob.data.vertices:
            p=vertex.co.copy();normal=vertex.normal.copy()
            displacement=.25*noise.noise_vector(p*3.4+offset)[0]+.11*noise.noise_vector(p*8.2+offset)[1]
            q=p+normal*displacement
            vertex.co=Vector(tuple(max(low[k],min(high[k],q[k])) for k in range(3)))
        ob.data.update()
        result.append(ob)
    return result


def _vegetation():
    rng=random.Random(11047);wood,green,tip=_plant_materials()
    wv=[];wf=[];lv=[];lf=[];lm=[]
    moss=_material('REV11 | living moss hummocks',(.044,.084,.036),.93)
    objects=[o for o in bpy.data.objects if 'finely eroded layered plateau' in o.name and (o.name.startswith('CASCADE') or 'HERO' in o.name.upper() or 'hero' in o.name)]
    # Detect hero by highest mesh extent around its known center if naming differs.
    if not any('CASCADE' not in o.name for o in objects):
        for o in bpy.data.objects:
            if 'finely eroded layered plateau' in o.name and _ground(o,14,30) is not None:objects.append(o)
    mv=[];mf=[]
    for ob in objects:
        corners=[ob.matrix_world@Vector(c) for c in ob.bound_box]
        minx=min(p.x for p in corners);maxx=max(p.x for p in corners)
        miny=min(p.y for p in corners);maxy=max(p.y for p in corners)
        cx=(minx+maxx)/2;cy=(miny+maxy)/2;rx=(maxx-minx)/2;ry=(maxy-miny)/2
        # Crooked lateral pines read as trees, not a dense generic forest. Keep central buildings clear.
        angles=[-2.55,-.55,1.15] if 'CASCADE' in ob.name else [-2.6,-1.8,-.35,.4]
        for a in angles:
            p=_ground(ob,cx+rx*.7*math.cos(a),cy+ry*.68*math.sin(a))
            if p is not None:
                _pine(p+Vector((0,0,-.025)),rng.uniform(1.9,2.65),rng,wv,wf,lv,lf,lm)
        for k in range(22 if 'CASCADE' in ob.name else 34):
            a=rng.uniform(-math.pi,math.pi);r=rng.uniform(.45,.9)
            p=_ground(ob,cx+rx*r*math.cos(a),cy+ry*r*math.sin(a))
            if p is None:continue
            if k%5==0:_pine(p+Vector((0,0,-.02)),rng.uniform(.34,.65),rng,wv,wf,lv,lf,lm)
            # Ground-following moss pads sampled per vertex rather than floating flat disks.
            base=len(mv);mv.append(tuple(p+Vector((0,0,.018))))
            rr=rng.uniform(.24,.7)
            for j in range(12):
                a2=j*math.tau/12;xx=p.x+rr*math.cos(a2);yy=p.y+rr*.7*math.sin(a2)
                q=_ground(ob,xx,yy)
                if q is None:q=p.copy()
                mv.append(tuple(q+Vector((0,0,.022))))
            for j in range(12):mf.append((base,base+1+j,base+1+(j+1)%12))
    result=[]
    if wv:result.append(_mesh('REV11 | grounded windswept pine wood',wv,wf,[wood],smooth=True))
    if lv:result.append(_mesh('REV11 | grounded pine needles and scrub',lv,lf,[green,tip],lm))
    if mv:result.append(_mesh('REV11 | ground conforming moss colonies',mv,mf,[moss],smooth=True))
    # Remove sand-colored top read while retaining existing procedural mineral/moss variation.
    mat=bpy.data.materials.get('Cliff v4 | mottled moss and wet plateau')
    if mat:
        for node in mat.node_tree.nodes:
            if node.type=='VALTORGB':
                for el in node.color_ramp.elements:
                    if el.position<.45:el.color=(.023,.045,.027,1)
                    elif el.position<.8:el.color=(.065,.105,.045,1)
                    else:el.color=(.13,.17,.085,1)
    return result


def _water():
    rng=random.Random(11102)
    foam=_material('REV11 | aerated ivory foam lips',(.82,.9,.96),.27)
    p=foam.node_tree.nodes.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=.06
    p.inputs['Emission Color'].default_value=(.4,.52,.65,1);p.inputs['Emission Strength'].default_value=.025
    vv=[];ff=[]
    sheets=[o for o in bpy.data.objects if 'translucent corrugated fall veils' in o.name and ('CASCADE' in o.name or 'HERO' in o.name.upper())]
    if not any('CASCADE' not in o.name for o in sheets):
        sheets=[o for o in bpy.data.objects if 'translucent corrugated fall veils' in o.name]
    for ob in sheets:
        for start in range(0,len(ob.data.vertices),7*48):
            if start+7>len(ob.data.vertices):continue
            points=[ob.matrix_world@ob.data.vertices[start+k].co for k in range(7)]
            # Broken scalloped foam at the exact modeled waterfall spill edge.
            for k in range(6):
                if rng.random()<.12:continue
                a=points[k];b=points[k+1];mid=a.lerp(b,.5)+Vector((0,-.03,.025))
                _tube_append(vv,ff,[a+Vector((0,0,.025)),mid,b+Vector((0,0,.025))],[.035,.062,.04],6)
            for k in range(8):
                u=rng.uniform(0,6);j=min(5,int(u));top=points[j].lerp(points[j+1],u-j)
                height=rng.uniform(.35,1.55);pts=[];rr=[]
                for q in range(12):
                    t=q/11;pts.append(top+Vector((.018*math.sin(t*17+k),-.15*t-.18*t*t,-height*t)))
                    rr.append(rng.uniform(.018,.045)*(1-.78*t))
                _tube_append(vv,ff,pts,rr,5)
    water=bpy.data.materials.get('Waterfall v4 | transparent moving veil')
    if water:
        nodes=water.node_tree.nodes;p=nodes.get('Principled BSDF')
        p.inputs['Base Color'].default_value=(.76,.87,.94,1);p.inputs['Transmission Weight'].default_value=.22
        for node in nodes:
            if node.type=='VALTORGB':node.color_ramp.elements[-1].color=(.8,.8,.8,1)
    threads=bpy.data.materials.get('Waterfall v4 | fine aerated threads')
    if threads:
        p=threads.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(.78,.88,.96,1);p.inputs['Alpha'].default_value=.8
    return [_mesh('REV11 | irregular waterfall foam lips and descending froth',vv,ff,[foam],smooth=True)] if vv else []


def apply_landscape_revision():
    if bpy.data.objects.get('REV11 | grounded windswept pine wood'):raise RuntimeError('Landscape revision11 already applied')
    before=set(bpy.data.objects)
    _vegetation();_water();_crowns()
    added=[o for o in bpy.data.objects if o not in before]
    print('REV11 landscape:',len(added),'objects;',sum(len(o.data.vertices) for o in added if o.type=='MESH'),'vertices')
    return added
