"""Detailed foreground lantern replacements and a restrained flowering branch.
Only removes old Court lanterns batch vertices within the two specified bounds.
No camera, lights, render, scene reset or unrelated-object changes.
"""
import bpy, bmesh, math, random
from math import sin,cos,pi
from mathutils import Vector
from architecture import Batch,_materials,_mat

POSITIONS=[(-18,-20,8,1.5),(-4,-11,8,1.0)]

def _remove_exact_old_lanterns():
 removed=0
 for ob in list(bpy.data.objects):
  if ob.type!='MESH' or not ob.name.startswith('Court lanterns'):continue
  bm=bmesh.new();bm.from_mesh(ob.data);verts=[]
  for v in bm.verts:
   q=ob.matrix_world@v.co
   for x,y,z,s in POSITIONS:
    if abs(q.x-x)<=1.15*s and abs(q.y-y)<=1.15*s and z-.25*s<=q.z<=z+2.1*s:
     verts.append(v);break
  if verts:
   removed+=len(verts);bmesh.ops.delete(bm,geom=verts,context='VERTS');bm.to_mesh(ob.data);ob.data.update()
  bm.free()
 return removed

def _lantern(x,y,z,s,name):
 mats=_materials().copy()
 mats['diffuser']=_mat('ornament dim golden silk',(.66,.25,.045),0,.62,.65,bump=.002)
 mats['lace']=_mat('ornament chased warm bronze',(.39,.18,.04),.78,.25,bump=.005)
 b=Batch(mats)
 def box(c,sz,ma):b.box(tuple(v*s for v in c),tuple(v*s for v in sz),ma)
 def tube(pts,r=.012,ma='lace',sides=7):b.tube([tuple(v*s for v in p) for p in pts],r*s,ma,sides)
 def sphere(c,r,ma='lace'):b.sphere(tuple(v*s for v in c),r*s,ma)
 def facepoint(u,v,side):
  # four exterior faces of the cage, all detail proud of the dim inner diffuser
  if side==0:return (u,-.535,v)
  if side==1:return (.535,u,v)
  if side==2:return (-u,.535,v)
  return (-.535,-u,v)
 def fline(points,side,rad=.012,ma='lace'):tube([facepoint(u,v,side) for u,v in points],rad,ma)
 # stepped square stone plinth, carved lacquer feet and scalloped lower base
 for zz,ww,hh,ma in [(.045,1.24,.09,'stone'),(.12,1.14,.07,'lace'),(.21,1.06,.11,'wood'),(.29,1.12,.055,'lace')]:box((0,0,zz),(ww,ww,hh),ma)
 for sx in [-1,1]:
  for sy in [-1,1]:
   box((sx*.43,sy*.43,.22),(.15,.15,.28),'wood')
   tube([(sx*.43,sy*.43,.26),(sx*.51,sy*.51,.18),(sx*.52,sy*.52,.1)],.035)
 # luminous core is smaller than cage; no broad white emissive boxes
 box((0,0,.91),(.86,.86,1.18),'diffuser')
 # heavy lacquer posts with fine bronze edges/collars
 for sx in [-1,1]:
  for sy in [-1,1]:
   box((sx*.5,sy*.5,.93),(.085,.085,1.31),'wood')
   for dx in [-.045,.045]:tube([(sx*.5+dx,sy*.5-.048,.29),(sx*.5+dx,sy*.5-.048,1.58)],.009)
   for zz in [.35,1.47,1.56]:box((sx*.5,sy*.5,zz),(.13,.13,.045),'lace')
 for zz in [.32,1.53]:
  for side in [-1,1]:
   box((0,side*.5,zz),(1.1,.09,.09),'wood');box((side*.5,0,zz),(.09,1.1,.09),'wood')
   tube([(-.5,side*.55,zz+.025),(.5,side*.55,zz+.025)],.011)
   tube([(side*.55,-.5,zz+.025),(side*.55,.5,zz+.025)],.011)
 # lattice face: nested rectangular borders, key fret band, central lotus flower and cloud vines
 for side in range(4):
  for a,bottom,top in [(.445,.38,1.47),(.405,.42,1.43)]:
   fline([(-a,bottom),(a,bottom),(a,top),(-a,top),(-a,bottom)],side,.009)
  # fine diagonal lower/upper pierced fret borders
  for row in [.45,1.35]:
   for j in range(7):
    u=-.36+j*.12
    fline([(u-.05,row),(u,row+.065),(u+.05,row),(u,row-.065),(u-.05,row)],side,.009)
  # central lotus with lancet petals, two depth layers
  center=.92
  for k in range(8):
   a=2*pi*k/8;pts=[]
   for j in range(25):
    t=2*pi*j/24;rr=.075+.245*sin(t/2)**1.1;aa=a+.16*sin(t)
    pts.append((rr*cos(aa),center+rr*sin(aa)*1.15))
   fline(pts,side,.013)
  fline([(.073*cos(2*pi*j/32),center+.073*sin(2*pi*j/32)) for j in range(33)],side,.012)
  # side meandering vines mirrored, scrolling inward at tips
  for sign in [-1,1]:
   for offset in [-.24,.24]:
    pts=[]
    for j in range(33):
     a=j/32*pi*2.5;rr=.12*(1-j/40);pts.append((sign*(.27+rr*cos(a)),center+offset+rr*sin(a)))
    fline(pts,side,.012)
   fline([(sign*.36,.53),(sign*.28,.63),(sign*.33,.77),(sign*.28,.92),(sign*.34,1.08),(sign*.27,1.22),(sign*.36,1.31)],side,.015)
  # lower foot rococo scrolls on dark apron
  box(facepoint(0,.22,side),(.75,.05,.12) if side in [0,2] else (.05,.75,.12),'wood')
  for sign in [-1,1]:
   pts=[]
   for j in range(25):
    a=j/24*pi*2.5;rr=.095*(1-j/31);pts.append((sign*(.16+rr*cos(a)),.22+rr*sin(a)*.6))
   fline(pts,side,.013)
 # three stacked tiny curved pagoda roof caps
 for k,(ww,base,rise) in enumerate([(1.5,1.6,.27),(1.13,1.84,.23),(.78,2.03,.17)]):
  n=12;vs=[];fs=[]
  def p(u,v):
   t=max(abs(u),abs(v));h=base+rise*(1-t)**1.5+.12*abs(u)**8*abs(v)**8
   return (u*ww/2,v*ww/2,h)
  for i in range(n+1):
   for j in range(n+1):vs.append(tuple(a*s for a in p(-1+2*i/n,-1+2*j/n)))
  for i in range(n):
   for j in range(n):a=i*(n+1)+j;fs.append((a,a+1,a+n+2,a+n+1))
  b.mesh(vs,fs,'tile')
  for side in [-1,1]:
   tube([p(-1+2*j/24,side) for j in range(25)],.023,'lace')
   tube([p(side,-1+2*j/24) for j in range(25)],.023,'lace')
  for j in range(13):
   u=-1+2*j/12;tube([p(u,-1+2*i/20) for i in range(21)],.014,'tile2')
  for sx in [-1,1]:
   for sy in [-1,1]:
    q=p(sx,sy);tube([q,(q[0]+sx*.07,q[1]+sy*.07,q[2]+.08),(q[0]+sx*.06,q[1]+sy*.06,q[2]+.17)],.02,'lace')
 # lotus bud finial
 sphere((0,0,2.23),.075,'lace');tube([(0,0,2.23),(0,0,2.38)],.025,'lace');sphere((0,0,2.4),.033,'lace')
 root=b.finish(name,(x,y,z));root['replacement']='Exact two nearest Court lanterns only';return root

def _blossom_foreground():
 # restrained lower-left branch, behind the nearest lantern, never across the scholar
 mats=_materials().copy();mats['bark']=_mat('foreground plum bark',(.065,.038,.021),0,.7,bump=.035);mats['petal']=_mat('foreground ivory petals',(.76,.69,.55),0,.5,bump=0);mats['pink']=_mat('foreground warm petal backs',(.66,.43,.35),0,.6,bump=0)
 b=Batch(mats);rng=random.Random(621)
 # global coordinates deliberately outside figure x=-13.5,y=-10
 main=[(-27,-22,8.2),(-25.6,-21.8,8.7),(-24.0,-21.2,9.1),(-22.8,-20.6,9.3),(-21.5,-20.1,9.1)]
 b.tube(main,.11,'bark',10,radii=[.20,.16,.11,.07,.025])
 tips=[]
 for i in range(1,5):
  q=Vector(main[i]);sg=-1 if i%2 else 1;end=q+Vector((rng.uniform(.4,1.4),sg*rng.uniform(.5,1.2),rng.uniform(.3,.85)));mid=q.lerp(end,.5)+Vector((0,0,.13));b.tube([tuple(q),tuple(mid),tuple(end)],.04,'bark',8,radii=[.065,.035,.009]);tips.extend([end,mid])
 for p in tips:
  for _ in range(5):
   c=p+Vector((rng.uniform(-.32,.32),rng.uniform(-.25,.25),rng.uniform(-.14,.17)));r=rng.uniform(.10,.17)
   for k in range(5):
    a=2*pi*k/5+rng.uniform(-.08,.08);right=Vector((cos(a),sin(a),.15));perp=Vector((-sin(a),cos(a),0));v0=c;v1=c+right*r+perp*r*.6;v2=c+right*r*1.7+Vector((0,0,.035));v3=c+right*r-perp*r*.6;b.mesh([tuple(v0),tuple(v1),tuple(v2),tuple(v3)],[(0,1,2,3)],'petal' if k%3 else 'pink')
   b.sphere(tuple(c+Vector((0,0,.025))),r*.18,'gold')
 return b.finish('Foreground / delicate ivory plum sprig',(0,0,0))

def build_foreground_ornament(include_branch=True):
 removed=_remove_exact_old_lanterns();roots=[]
 for i,(x,y,z,s) in enumerate(POSITIONS):roots.append(_lantern(x,y,z,s,'Foreground / pierced bronze lantern %d'%i))
 if include_branch:roots.append(_blossom_foreground())
 print('Foreground ornament: removed',removed,'old lantern vertices; created',len(roots),'roots')
 return roots
