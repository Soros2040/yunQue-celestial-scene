"""Sparse foreground rock gardens and ivory blossoms for V2 camera.
No render, no scene reset, no removal of existing blossom sprig.
Call build_foreground_garden(). Camera-target placement checked numerically.
"""
import bpy, bmesh, math, random
from math import sin,cos,pi
from mathutils import Vector
from architecture import Batch,_materials,_mat


def _smooth_rock_meshes(root):
 # Weld the independently built rock/moss faces into one continuous surface.
 # An interpolated point attribute replaces polygon-shaped moss material patches.
 parts=[o for o in root.children if o.type=='MESH' and o.name.rsplit(' / ',1)[-1] in ['rock','rock_light','moss']]
 if not parts:return
 vs=[];fs=[];indices=[]
 for ob in parts:
  off=len(vs);vs.extend(tuple(v.co) for v in ob.data.vertices)
  mi={'rock':0,'rock_light':1,'moss':2}[ob.name.rsplit(' / ',1)[-1]]
  for f in ob.data.polygons:fs.append(tuple(off+i for i in f.vertices));indices.append(mi)
 me=bpy.data.meshes.new('Garden08 continuous weathered rock surface');me.from_pydata(vs,[],fs);me.update()
 for f,mi in zip(me.polygons,indices):f.material_index=mi
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.0001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free();me.update()
 weights=[0.0]*len(me.vertices);counts=[0]*len(me.vertices)
 for f in me.polygons:
  for i in f.vertices:weights[i]+=1.0 if f.material_index==2 else 0.0;counts[i]+=1
 attr=me.attributes.new('moss_weight','FLOAT','POINT')
 for i,a in enumerate(attr.data):a.value=weights[i]/max(1,counts[i])
 for f in me.polygons:f.material_index=0;f.use_smooth=True
 ma=bpy.data.materials.get('Garden08 smoothly weathered mossy stone')
 if ma is None:
  ma=bpy.data.materials.new('Garden08 smoothly weathered mossy stone');ma.use_nodes=True;n=ma.node_tree.nodes;ln=ma.node_tree.links;p=n.get('Principled BSDF');p.inputs['Roughness'].default_value=.88
  geo=n.new('ShaderNodeNewGeometry');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=8;noise.inputs['Detail'].default_value=5;noise.inputs['Roughness'].default_value=.75;ln.new(geo.outputs['Position'],noise.inputs['Vector'])
  stone=n.new('ShaderNodeValToRGB');stone.color_ramp.elements[0].position=.2;stone.color_ramp.elements[0].color=(.035,.045,.043,1);stone.color_ramp.elements[1].position=.8;stone.color_ramp.elements[1].color=(.16,.18,.16,1);ln.new(noise.outputs['Fac'],stone.inputs[0])
  moss=n.new('ShaderNodeValToRGB');moss.color_ramp.elements[0].position=.22;moss.color_ramp.elements[0].color=(.022,.038,.009,1);moss.color_ramp.elements[1].position=.79;moss.color_ramp.elements[1].color=(.085,.12,.026,1);ln.new(noise.outputs['Fac'],moss.inputs[0])
  at=n.new('ShaderNodeAttribute');at.attribute_name='moss_weight';mult=n.new('ShaderNodeMath');mult.operation='MULTIPLY';ln.new(at.outputs['Fac'],mult.inputs[0]);ln.new(noise.outputs['Fac'],mult.inputs[1])
  ramp=n.new('ShaderNodeMapRange');ramp.clamp=True;ramp.inputs['From Min'].default_value=.10;ramp.inputs['From Max'].default_value=.52;ln.new(mult.outputs[0],ramp.inputs['Value'])
  mix=n.new('ShaderNodeMixRGB');ln.new(ramp.outputs['Result'],mix.inputs[0]);ln.new(stone.outputs[0],mix.inputs[1]);ln.new(moss.outputs[0],mix.inputs[2]);ln.new(mix.outputs[0],p.inputs['Base Color'])
  fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=53;fine.inputs['Detail'].default_value=3;ln.new(geo.outputs['Position'],fine.inputs['Vector']);bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.28;bump.inputs['Distance'].default_value=.055;ln.new(fine.outputs['Fac'],bump.inputs['Height']);ln.new(bump.outputs['Normal'],p.inputs['Normal'])
 me.materials.append(ma);ob=bpy.data.objects.new('Foreground garden 08 / smooth mossy weathered stone',me);bpy.context.collection.objects.link(ob);ob.parent=root
 for old in parts:bpy.data.objects.remove(old,do_unlink=True)
 print('Garden08 rocks welded and smoothed:',len(vs),'->',len(me.vertices),'vertices')

def build_foreground_garden():
 mats=_materials().copy()
 mats['rock']=_mat('foreground garden fissured slate',(.065,.078,.074),.05,.76,bump=.16)
 mats['rock_light']=_mat('foreground garden weathered stone',(.13,.15,.13),.03,.8,bump=.15)
 mats['moss']=_mat('foreground garden velvet moss',(.058,.09,.023),0,.93,bump=.09)
 mats['grass']=_mat('foreground garden sparse sedge',(.11,.14,.035),0,.81,bump=0)
 mats['bark']=_mat('foreground garden old plum branch',(.07,.039,.018),0,.7,bump=.05)
 mats['petal']=_mat('foreground garden warm ivory blossoms',(.82,.76,.64),0,.45,bump=0)
 mats['petal_back']=_mat('foreground garden rosy petal backs',(.62,.44,.39),0,.57,bump=0)
 p=mats['petal'].node_tree.nodes.get('Principled BSDF');p.inputs['Subsurface Weight'].default_value=.12
 b=Batch(mats);rng=random.Random(8015)
 def rock(center,scale,seed):
  rr=random.Random(seed);nx=28;ny=16;vs=[];fs=[];ma=[];cx,cy,cz=center;sx,sy,sz=scale;phase=rr.uniform(0,6)
  for j in range(ny+1):
   t=pi*j/ny
   for i in range(nx):
    a=2*pi*i/nx;u=sin(t)*cos(a);v=sin(t)*sin(a);w=cos(t)
    irregular=1+.12*sin(5*u+3*v+phase)*sin(4*w-2*v)+.055*sin(13*u+7*w+phase)+.035*cos(19*v-11*w)
    xx=u*sx*irregular+.13*sx*w;yy=v*sy*irregular;zz=w*sz*irregular
    # naturally fractured top rather than a smooth polished boulder
    zz+=.06*sz*sin(17*u+phase)*cos(11*v)
    vs.append((cx+xx,cy+yy,cz+zz))
  for j in range(ny):
   for i in range(nx):
    a=j*nx+i;c=j*nx+(i+1)%nx;f=(a,c,c+nx,a+nx);pts=[vs[k] for k in f];avgz=sum(p[2] for p in pts)/4
    # real moss caps follow rock geometry and leave large exposed slate faces
    patch=sin(i*.71+phase)+cos(j*.84-phase)
    mk='moss' if avgz>cz+sz*.32 and patch>.25 else ('rock_light' if patch>1.1 else 'rock')
    b.mesh(pts,[(0,1,2,3)],mk)
  return center,scale
 # Left-edge low weathered stones anchor existing sprig without entering figure path.
 left=[((-17.8,-22.9,8.06),(2.0,1.35,.72)),((-15.2,-25.1,8.04),(1.48,1.05,.52)),((-19.0,-20.6,8.2),(1.55,1.15,.77)),((-13.6,-26.3,8.03),(.75,.65,.34)),((-16.1,-22.7,8.17),(.8,.62,.49))]
 # Right-edge boulders slightly project beyond terrace lip, creating a natural garden edge.
 right=[((16.2,-30.6,7.95),(2.25,1.6,1.18)),((14.5,-29.3,8.05),(1.36,1.0,.72)),((17.8,-28.4,8.2),(1.3,1.1,.83))]
 for i,(c,s) in enumerate(left+right):rock(c,s,131+i)
 # Sparse grass tufts, not a carpet: few tapering bent triangular blades.
 for c,s in left+right:
  for q in range(6):
   base=Vector((c[0]+rng.uniform(-.42,.42)*s[0],c[1]+rng.uniform(-.38,.38)*s[1],c[2]+s[2]*rng.uniform(.65,.85)))
   for k in range(4):
    a=rng.uniform(0,2*pi);h=rng.uniform(.13,.3);r=rng.uniform(.055,.13);side=Vector((-sin(a),cos(a),0))*.018;mid=base+Vector((cos(a)*r*.4,sin(a)*r*.4,h*.65));tip=base+Vector((cos(a)*r,sin(a)*r,h))
    b.mesh([tuple(base-side),tuple(base+side),tuple(mid+side*.5),tuple(mid-side*.5),tuple(tip)],[(0,1,2,3),(3,2,4)],'grass')
 # Pale plum branch enters from offscreen right and ends within normalized x .90–1 / bottom .14.
 main=[(17.5,-31.1,8.1),(16.6,-30.0,8.65),(15.2,-28.9,9.15),(13.8,-27.9,9.45),(13.05,-27.3,9.65)]
 b.tube(main,.08,'bark',9,radii=[.19,.14,.09,.055,.015])
 terminals=[]
 for idx,(end,offset) in enumerate([
  ((15.4,-27.2,9.9),2),((16.8,-28.1,9.5),1),((14.2,-25.9,9.6),3),((12.9,-27.0,9.5),3),((14.2,-28.8,9.95),2),((16.5,-26.6,9.75),1)]):
  start=Vector(main[offset]);end=Vector(end);mid=start.lerp(end,.55)+Vector((0,0,.16));b.tube([tuple(start),tuple(mid),tuple(end)],.04,'bark',7,radii=[.055,.026,.005]);terminals.extend([end,mid])
 def blossom(center,r,phase):
  c=Vector(center)
  for k in range(5):
   a=phase+2*pi*k/5;direction=Vector((cos(a),sin(a),.2));side=Vector((-sin(a),cos(a),0));vs=[]
   # convex, curved petal with rounded tip; actual geometry catches rim light
   for j in range(9):
    t=2*pi*j/8;along=r*(.65+.65*cos(t));across=r*.49*sin(t);p=c+direction*along+side*across+Vector((0,0,.045*sin(t)**2+.025*cos(t)))
    vs.append(tuple(p))
   vs.append(tuple(c+direction*r*.7+Vector((0,0,.09))));fs=[(9,j,(j+1)%8) for j in range(8)]
   b.mesh(vs,fs,'petal' if (k+int(phase*10))%4 else 'petal_back')
  # slender stamens and pollen tips instead of large decorative balls
  for k in range(5):
   a=2*pi*k/5;tip=c+Vector((cos(a)*r*.15,sin(a)*r*.15,r*.34));b.tube([tuple(c),tuple(tip)],.006,'gold',4)
 for tip in terminals:
  for j in range(4):
   c=tip+Vector((rng.uniform(-.2,.2),rng.uniform(-.2,.2),rng.uniform(-.08,.13)));blossom(c,rng.uniform(.10,.18),rng.uniform(0,2*pi))
 root=b.finish('Foreground garden 08 / mossy slate and ivory plum',(0,0,0));_smooth_rock_meshes(root);root['placement']='Sparse frame corners, central walking floor and scholar clear'
 return root
