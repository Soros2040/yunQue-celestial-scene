"""Restart-safe actual Cycles rendering, exact full-frame camera border crops.
Run: blender -b 云阙_V2_可编辑.blend -t8 --python render_tiles.py
Each finished tile is a linear32-bitEXR plus an atomic completion marker.
"""
import bpy,os,json,time,datetime,hashlib
ROOT=os.path.dirname(os.path.abspath(__file__));OUT=os.path.join(ROOT,'tiles_qa12');os.makedirs(OUT,exist_ok=True)
W,H=1440,810;NX,NY=6,5;SAMPLES=256;SEED=73109
scene_path=os.path.join(ROOT,'云阙_V2_可编辑.blend')
with open(scene_path,'rb') as f:fingerprint=hashlib.file_digest(f,'sha256').hexdigest()
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=SAMPLES;s.cycles.use_adaptive_sampling=False;s.cycles.use_denoising=False;s.cycles.seed=SEED;s.cycles.use_animated_seed=False
s.cycles.max_bounces=10;s.cycles.volume_bounces=4;s.cycles.volume_step_rate=1;s.cycles.sample_clamp_indirect=3;s.cycles.blur_glossy=.5
s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.use_border=True;s.render.use_crop_to_border=True;s.render.use_compositing=False;s.render.use_sequencer=False;s.render.use_persistent_data=True
s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='32';s.render.image_settings.exr_codec='ZIP'
state={'status':'running','width':W,'height':H,'columns':NX,'rows':NY,'tile_width':W//NX,'tile_height':H//NY,'samples_per_pixel':SAMPLES,'seed':SEED,'scene_sha256':fingerprint,'completed':0,'total':NX*NY,'started_or_resumed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tiles':[]}
def atomic(path,data):
 tmp=path+'.tmp'
 with open(tmp,'w') as f:json.dump(data,f,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def save():atomic(os.path.join(OUT,'progress.json'),state)
for row in range(NY):
 for col in range(NX):
  name='tile_r%02d_c%02d'%(row,col);path=os.path.join(OUT,name+'.exr');mark=os.path.join(OUT,name+'.done.json')
  if os.path.exists(mark) and os.path.exists(path):
   d=json.load(open(mark))
   if d['scene_sha256']!=fingerprint or d['samples']!=SAMPLES or d['width']!=W//NX or d['height']!=H//NY:raise RuntimeError('Refusing incompatible tile checkpoint: '+name)
   state['completed']+=1;state['tiles'].append(d);save();print('TILE_RESUMED',name,flush=True);continue
  state['active_tile']=name;save();print('TILE_START',name,flush=True)
  s.render.border_min_x=col/NX;s.render.border_max_x=(col+1)/NX;s.render.border_min_y=row/NY;s.render.border_max_y=(row+1)/NY;s.render.filepath=path
  t=time.time();bpy.ops.render.render(write_still=True)
  im=bpy.data.images.load(path,check_existing=False);size=list(im.size);bpy.data.images.remove(im)
  if size!=[W//NX,H//NY]:raise RuntimeError('Unexpected cropped tile dimensions: '+str(size))
  d={'name':name,'file':name+'.exr','column':col,'row_from_bottom':row,'x':col*(W//NX),'y':row*(H//NY),'width':W//NX,'height':H//NY,'samples':SAMPLES,'seed':SEED,'scene_sha256':fingerprint,'render_seconds':round(time.time()-t,2),'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  atomic(mark,d);state['completed']+=1;state['tiles'].append(d);save();print('TILE_COMPLETE',json.dumps(d),flush=True)
state['status']='tiles_complete';state.pop('active_tile',None);save();print('ALL_TILES_COMPLETE',flush=True)
