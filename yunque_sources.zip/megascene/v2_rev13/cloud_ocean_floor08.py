"""Continuous low cloud ocean below cascade shelves, with eroded crowns.

Adds no fog at hero-tree/sunset level, changes no lights or render settings.
The density field is a warped upper cloud surface with a continuous deeper
core, so the lower background cannot reveal orange world-sky holes.
"""
import bpy, random
from landscape_v4 import _cloud_group, _cloud_material

def _floor_material():
    name='OCEAN FLOOR08 | stratified low scattering core'
    old=bpy.data.materials.get(name)
    if old:return old
    m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
    out=n.new('ShaderNodeOutputMaterial');vol=n.new('ShaderNodeVolumePrincipled')
    vol.inputs['Color'].default_value=(.995,.998,1,1);vol.inputs['Anisotropy'].default_value=.18
    tc=n.new('ShaderNodeTexCoord');sep=n.new('ShaderNodeSeparateXYZ');xy=n.new('ShaderNodeCombineXYZ')
    # Meter-scale coordinates: large cloud waves and finer 3-D erosion are separate.
    broad=n.new('ShaderNodeTexNoise');broad.name='Wide cloud-ocean height waves';broad.inputs['Scale'].default_value=.045;broad.inputs['Detail'].default_value=3;broad.inputs['Roughness'].default_value=.72
    h=n.new('ShaderNodeMapRange');h.name='Cloud top stays below shelves';h.inputs['From Min'].default_value=.2;h.inputs['From Max'].default_value=.8;h.inputs['To Min'].default_value=-14;h.inputs['To Max'].default_value=-8.5;h.clamp=True
    fine=n.new('ShaderNodeTexNoise');fine.name='Meter-scale cloud-edge erosion';fine.inputs['Scale'].default_value=.48;fine.inputs['Detail'].default_value=4;fine.inputs['Roughness'].default_value=.75
    er=n.new('ShaderNodeMapRange');er.inputs['From Min'].default_value=.15;er.inputs['From Max'].default_value=.85;er.inputs['To Min'].default_value=-1.15;er.inputs['To Max'].default_value=1.15;er.clamp=True
    add=n.new('ShaderNodeMath');add.operation='ADD';sub=n.new('ShaderNodeMath');sub.operation='SUBTRACT'
    edge=n.new('ShaderNodeMapRange');edge.name='Soft eroded surface to solid cloud core';edge.inputs['From Min'].default_value=0;edge.inputs['From Max'].default_value=3.2;edge.inputs['To Min'].default_value=0;edge.inputs['To Max'].default_value=.48;edge.clamp=True
    mod=n.new('ShaderNodeMapRange');mod.inputs['From Min'].default_value=0;mod.inputs['From Max'].default_value=1;mod.inputs['To Min'].default_value=.48;mod.inputs['To Max'].default_value=1.15;mod.clamp=True
    mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
    links=[(tc.outputs['Object'],sep.inputs[0]),(sep.outputs['X'],xy.inputs['X']),(sep.outputs['Y'],xy.inputs['Y']),(xy.outputs[0],broad.inputs[0]),(broad.outputs['Fac'],h.inputs[0]),(tc.outputs['Object'],fine.inputs[0]),(fine.outputs['Fac'],er.inputs[0]),(h.outputs[0],add.inputs[0]),(er.outputs[0],add.inputs[1]),(add.outputs[0],sub.inputs[0]),(sep.outputs['Z'],sub.inputs[1]),(sub.outputs[0],edge.inputs[0]),(fine.outputs['Fac'],mod.inputs[0]),(edge.outputs[0],mul.inputs[0]),(mod.outputs[0],mul.inputs[1]),(mul.outputs[0],vol.inputs['Density']),(vol.outputs[0],out.inputs['Volume'])]
    for a,b in links:l.new(a,b)
    return m

def build_cloud_ocean_floor():
    if bpy.data.objects.get('OCEAN FLOOR08 | continuous low cloud volume'):
        raise RuntimeError('Cloud ocean floor08 already exists; call once per scene.')
    # World-space mesh coordinates keep texture scales physically consistent.
    x0,x1=-160,160;y0,y1=-15,245;z0,z1=-38,-6
    verts=[(x,y,z) for x,y,z in [(x0,y0,z0),(x0,y0,z1),(x0,y1,z0),(x0,y1,z1),(x1,y0,z0),(x1,y0,z1),(x1,y1,z0),(x1,y1,z1)]]
    faces=[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]
    me=bpy.data.meshes.new('OCEAN FLOOR08 bounded volume');me.from_pydata(verts,[],faces);me.materials.append(_floor_material())
    ob=bpy.data.objects.new('OCEAN FLOOR08 | continuous low cloud volume',me);bpy.context.collection.objects.link(ob)
    ob['purpose']='Fill only lower cloud canyon sky gaps; eroded top approximately z -8 to -14.'
    rng=random.Random(808);ma=_cloud_material();obs=[ob]
    # Low localized crowns break the distant horizon surface without obscuring sun/branches.
    for i,(center,scale) in enumerate([((12,55,-8),(4.2,3.0,1.1)),((42,43,-9),(4.0,3.0,1.2)),((65,72,-8),(4.5,3.2,1.25)),((-18,80,-9),(5.0,3.3,1.3))]):
        obs.append(_cloud_group('OCEAN FLOOR08 | broken low crown %02d'%i,center,scale,rng,ma,14))
    return obs
