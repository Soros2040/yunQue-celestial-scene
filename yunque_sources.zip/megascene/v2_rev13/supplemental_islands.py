"""Staggered lower-right cascade shelves for the cloud-palace scene.

Usage: from supplemental_islands import build_supplemental_islands
anchors = build_supplemental_islands()

No scene reset, camera, light, or render changes. Imports the preserved
landscape_v4 terrain/water API. Returns pavilion placement metadata.
"""
import bpy, math, random
from mathutils import Vector
from math import sin, cos, pi
from landscape_v4 import build_island, _mesh, _tube_append, _material

SHELVES = [
    dict(name='CASCADE 01 | upper moss shelf', center=(10,16,7), radius=(5.3,3.2), depth=5.8, seed=601),
    dict(name='CASCADE 02 | middle pine terrace', center=(16,5,5), radius=(6.0,3.6), depth=6.2, seed=602),
    dict(name='CASCADE 03 | right linking shelf', center=(25,14,6.5), radius=(5.2,3.3), depth=5.3, seed=603),
    dict(name='CASCADE 04 | lower cloud garden', center=(20,-1,3.8), radius=(4.4,2.7), depth=4.8, seed=604),
]

def _plant_materials():
    wood=_material('CASCADE foliage | weathered pine bark',(.045,.049,.038),.91)
    green=_material('CASCADE foliage | deep jade pine needles',(.025,.058,.038),.88)
    tip=_material('CASCADE foliage | muted olive needle tips',(.065,.105,.051),.9)
    if 'Fine bark ridges' not in wood.node_tree.nodes:
        n=wood.node_tree.nodes;l=wood.node_tree.links;p=n.get('Principled BSDF')
        no=n.new('ShaderNodeTexNoise');no.name='Fine bark ridges';no.inputs['Scale'].default_value=17;no.inputs['Detail'].default_value=3
        bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.33;bump.inputs['Distance'].default_value=.035
        l.new(no.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs[0],p.inputs['Normal'])
    return wood,green,tip

def _pine(root,height,rng,woodverts,woodfaces,leafverts,leaffaces,leafmats):
    """Small windswept pine: bent woody skeleton and flat irregular needle fans."""
    base=Vector(root);wind=Vector((rng.uniform(-.4,.4),rng.uniform(-.22,.22),0))*height
    pts=[];rr=[]
    for j in range(11):
        t=j/10;pts.append(base+Vector((wind.x*(.35*sin(t*pi)+.7*t),wind.y*t,height*t)))
        rr.append(height*.043*(1-.83*t))
    _tube_append(woodverts,woodfaces,pts,rr,7)
    clusters=[]
    for level in range(3):
        t=.43+level*.2;origin=base+Vector((wind.x*(.35*sin(t*pi)+.7*t),wind.y*t,height*t))
        branches=5-level
        for q in range(branches):
            a=q*2*pi/branches+rng.uniform(-.4,.4)+level*.55
            ln=height*(.45-level*.07)*rng.uniform(.72,1.15)
            end=origin+Vector((ln*cos(a),ln*sin(a),height*rng.uniform(.04,.11)))
            mid=origin.lerp(end,.55)+Vector((0,0,-height*.03))
            _tube_append(woodverts,woodfaces,[origin,mid,end],[height*.019,height*.012,height*.004],6)
            for twig in range(3):
                aa=a+(twig-1)*.55;tl=height*rng.uniform(.12,.23);ep=end+Vector((tl*cos(aa),tl*sin(aa),height*rng.uniform(.005,.06)))
                _tube_append(woodverts,woodfaces,[end,ep],[height*.006,height*.0018],5)
                clusters.append((ep,height*rng.uniform(.15,.24)))
    clusters.append((pts[-1],height*.23))
    for center,rad in clusters:
        # Needles are real narrow triangles, spread into irregular flat pine pads.
        for j in range(44):
            a=rng.uniform(0,2*pi);r=rad*math.sqrt(rng.random());z=rng.uniform(-.055,.055)*height
            p=center+Vector((cos(a)*r,sin(a)*r*.72,z))
            direction=Vector((cos(a+rng.uniform(-.5,.5)),sin(a+rng.uniform(-.5,.5)),rng.uniform(.08,.35))).normalized()
            ln=height*rng.uniform(.035,.085);side=direction.cross(Vector((0,0,1))).normalized()*height*.008
            start=len(leafverts);leafverts.extend([tuple(p-side),tuple(p+side),tuple(p+direction*ln)])
            leaffaces.append((start,start+1,start+2));leafmats.append(1 if rng.random()<.16 else 0)

def build_supplemental_islands():
    """Add four cascade levels. Returns centers/radii and clear pavilion anchors."""
    if bpy.data.objects.get('CASCADE | pine trunks and branches'):
        raise RuntimeError('Supplemental cascade islands already exist; call once per fresh scene.')
    wood,green,tip=_plant_materials();wv=[];wf=[];lv=[];lf=[];lm=[];anchors=[]
    for index,spec in enumerate(SHELVES):
        build_island(spec['name'],spec['center'],spec['radius'],spec['depth'],spec['seed'],True)
        rng=random.Random(spec['seed']+1000);cx,cy,cz=spec['center'];rx,ry=spec['radius']
        # Keep a clear central footprint for optional architecture.
        for k,(a,rad,h) in enumerate([(2.6,.68,1.8),(.35,.68,2.25),(-1.2,.73,1.4)]):
            a+=rng.uniform(-.18,.18);height=h*(.88 if index==3 else 1)
            root=(cx+rx*rad*cos(a),cy+ry*rad*sin(a),cz+.08)
            _pine(root,height,rng,wv,wf,lv,lf,lm)
        # Low scrub on the exposed rim, much smaller than the tree silhouettes.
        for k in range(3):
            a=rng.uniform(-pi,pi);root=(cx+rx*.8*cos(a),cy+ry*.8*sin(a),cz+.07)
            _pine(root,rng.uniform(.38,.65),rng,wv,wf,lv,lf,lm)
        anchors.append(dict(name=spec['name'],center=spec['center'],radius=spec['radius'],pavilion_anchor=(cx,cy,cz+.03),recommended_width=min(rx*1.0,4.8),recommended_depth=min(ry*.95,3.2)))
    _mesh('CASCADE | pine trunks and branches',wv,wf,[wood],smooth=True)
    _mesh('CASCADE | individual pine needle fans',lv,lf,[green,tip],lm,smooth=False)
    return anchors
