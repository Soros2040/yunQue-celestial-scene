"""Rebuild every editable component from source. Blender4.3+, no external assets.
blender -b -t8 --python rebuild_scene.py -- --preview
blender -b -t8 --python rebuild_scene.py -- --build-only
blender -b -t8 --python rebuild_scene.py
"""
import bpy,os,sys,runpy,json,time,argparse
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
a=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
p=argparse.ArgumentParser();p.add_argument('--preview',action='store_true');p.add_argument('--production',action='store_true');p.add_argument('--build-only',action='store_true');p.add_argument('--samples',type=int,default=512);args=p.parse_args(a)
t0=time.time();os.environ['MEGASCENE_BUILD_ONLY']='1'
for stage in ['scene_main.py','progress06.py','detail_pass07.py','rim08_study.py','detail_pass08.py','detail_pass09.py','revision11.py','revision12.py','revision13.py']:
 print('REBUILD_STAGE',stage,flush=True);runpy.run_path(os.path.join(ROOT,stage),run_name='__main__')
s=bpy.context.scene;s.cycles.use_denoising=False;s.cycles.samples=96 if args.preview else args.samples;s.cycles.adaptive_threshold=.025 if args.preview else .008;s.render.resolution_percentage=50 if args.preview else 100
s.render.filepath=os.path.join(ROOT,'preview_13_verified.png' if args.preview else '云阙_V2_重建渲染.png');s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='8'
s['Reconstruction status']='Iterative modeled reconstruction, not a claim of exact1:1 photographic match.'
s['Build source']='rebuild_scene.py';s['Reference use']='Visual analysis only, no reference picture projected as final render.'
metrics={'stage':'13','build_seconds':round(time.time()-t0,2),'objects':len(bpy.data.objects),'mesh_objects':sum(o.type=='MESH' for o in bpy.data.objects),'vertices_including_linked_instances':sum(len(o.data.vertices) for o in bpy.data.objects if o.type=='MESH'),'unique_mesh_vertices':sum(len(d.vertices) for d in {o.data for o in bpy.data.objects if o.type=='MESH'}),'polygons':sum(len(o.data.polygons) for o in bpy.data.objects if o.type=='MESH'),'curve_objects':sum(o.type=='CURVE' for o in bpy.data.objects),'lights':sum(o.type=='LIGHT' for o in bpy.data.objects),'materials':len(bpy.data.materials),'render_samples':s.cycles.samples,'resolution_percentage':s.render.resolution_percentage,'blender_version':bpy.app.version_string,'denoise':False}
with open(os.path.join(ROOT,'build_metrics.json'),'w') as f:json.dump(metrics,f,indent=2)
print('BUILD_METRICS',json.dumps(metrics),flush=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_可编辑.blend'),compress=True)
if not args.build_only:
 if args.production:runpy.run_path(os.path.join(ROOT,'render_high_quality.py'),run_name='__main__')
 else:bpy.ops.render.render(write_still=True)
