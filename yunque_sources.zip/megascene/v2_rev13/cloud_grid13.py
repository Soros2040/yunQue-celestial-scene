"""Real density-grid clouds with mesh-distance boundary feathering."""
import bpy

def apply_cloud_grid13(feather=1.15,density=2.5,core_power=None):
 s=bpy.context.scene;mat=bpy.data.materials.new('REV13 | SDF feathered vapor density');mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links;out=n.new('ShaderNodeOutputMaterial');v=n.new('ShaderNodeVolumePrincipled');v.inputs['Color'].default_value=(.985,.993,1,1);v.inputs['Anisotropy'].default_value=.12;v.inputs['Density Attribute'].default_value=''
 info=n.new('ShaderNodeVolumeInfo');co=n.new('ShaderNodeTexCoord');fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=1.2;fine.inputs['Detail'].default_value=4;fine.inputs['Roughness'].default_value=.7;l.new(co.outputs['Object'],fine.inputs[0]);r=n.new('ShaderNodeMapRange');r.interpolation_type='SMOOTHSTEP';r.inputs['From Min'].default_value=.34;r.inputs['From Max'].default_value=.7;r.inputs['To Min'].default_value=.15;r.inputs['To Max'].default_value=1.4;r.clamp=True;l.new(fine.outputs['Fac'],r.inputs[0]);mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
 for a,b in [(info.outputs['Density'],mul.inputs[0]),(r.outputs[0],mul.inputs[1]),(mul.outputs[0],v.inputs['Density']),(v.outputs[0],out.inputs['Volume'])]:l.new(a,b)
 if core_power:
  power=n.new('ShaderNodeMath');power.operation='POWER';power.inputs[1].default_value=1.5;gain=n.new('ShaderNodeMath');gain.operation='MULTIPLY';gain.inputs[1].default_value=6;l.new(info.outputs['Density'],power.inputs[0]);l.new(power.outputs[0],gain.inputs[0]);l.new(gain.outputs[0],mul.inputs[0])
 result=[];receivers=bpy.data.collections.get('REV12 | cloud light receivers only')
 for mesh in list(bpy.data.objects):
  if not mesh.name.startswith('REV12 CANOPY | connected'):continue
  mesh.hide_render=True
  data=bpy.data.volumes.new('REV13 density grid '+mesh.name);ob=bpy.data.objects.new(data.name,data);bpy.context.collection.objects.link(ob);data.materials.append(mat)
  mod=ob.modifiers.new('Signed interior boundary density fade','MESH_TO_VOLUME');mod.object=mesh;mod.resolution_mode='VOXEL_SIZE';mod.voxel_size=.22;mod.interior_band_width=feather;mod.density=density
  if receivers:receivers.objects.link(ob)
  result.append(ob)
 print('REV13_GRID_VOLUMES',len(result),flush=True);return result
