import bpy,os
s=bpy.context.scene;ROOT=os.path.dirname(os.path.abspath(__file__))
# retain cool sky above the tree, confine golden HDR halo to sunset opening
for n in s.world.node_tree.nodes:
 if n.bl_idname=='ShaderNodeMapRange' and abs(n.inputs['From Min'].default_value-.945)<.002:n.inputs['From Min'].default_value=.985
 if n.type=='VALTORGB' and len(n.color_ramp.elements)>4:
  for e in n.color_ramp.elements:
   if abs(e.position-.51)<.002:e.color=(2,.9,.1,1)
   if abs(e.position-.48)<.002:e.color=(.7,.28,.035,1)
 if n.bl_idname=='ShaderNodeMixRGB' and n.blend_type=='ADD':n.inputs[2].default_value=(1.6,.8,.07,1)
# opaque billowing cores with v3's eroded soft edges still intact
m=bpy.data.materials['Cloud | eroded fractal scattering v3'];n=m.node_tree.nodes;l=m.node_tree.links;v=next(q for q in n if q.bl_idname=='ShaderNodeVolumePrincipled');source=v.inputs['Density'].links[0].from_socket;mul=n.new('ShaderNodeMath');mul.name='Cloud core optical depth boost';mul.operation='MULTIPLY';mul.inputs[1].default_value=2.0;l.new(source,mul.inputs[0]);l.new(mul.outputs[0],v.inputs['Density']);v.inputs['Anisotropy'].default_value=.3
# visible framed fretwork on the closest lanterns, with actual shadow-casting geometry
ma=bpy.data.materials['Court • black lacquer']
for x,y,z,sc in [(-18,-20,8,1.5),(-4,-11,8,1)]:
 for j in [-.35,-.175,0,.175,.35]:
  bpy.ops.mesh.primitive_cube_add(size=1,location=(x+j*sc,y-.52*sc,z+.7*sc));ob=bpy.context.object;ob.name='Lantern fine black fret';ob.scale=(.045*sc,.035,1.3*sc);ob.data.materials.append(ma)
 for dz in [.3,.7,1.1]:
  bpy.ops.mesh.primitive_cube_add(size=1,location=(x,y-.525*sc,z+dz*sc));ob=bpy.context.object;ob.name='Lantern cross fret';ob.scale=(.88*sc,.035,.035*sc);ob.data.materials.append(ma)
s.cycles.samples=256;s.cycles.adaptive_threshold=.015;s.cycles.volume_bounces=4;s.render.resolution_percentage=75;s.render.filepath=os.path.join(ROOT,'progress_06_1440.png');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2.blend'));
if os.environ.get('MEGASCENE_BUILD_ONLY') != '1': bpy.ops.render.render(write_still=True)
