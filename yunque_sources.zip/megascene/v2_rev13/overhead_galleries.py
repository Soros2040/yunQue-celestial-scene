"""Dense carved sky-palace galleries, designed for the V2 moon-gate camera.
Adds geometry only. build_overhead() returns root objects. No scene reset.
Central gate opening remains free of columns and slabs.
"""
import bpy, math, random
from math import sin,cos,pi
from architecture import Batch,_materials,build_pavilion

def build_overhead():
 mats=_materials();b=Batch(mats);rng=random.Random(138);roots=[]
 def ring_xy(cx,cy,z,r,rad=.035,ma='gold',n=32):
  b.tube([(cx+r*cos(2*pi*i/n),cy+r*sin(2*pi*i/n),z) for i in range(n+1)],rad,ma,6)
 def scroll_xz(x,y,z,sz=.5,sgn=1):
  pts=[]
  for i in range(33):a=i/32*pi*3.1;r=sz*(1-.8*i/32);pts.append((x+sgn*r*cos(a),y,z+r*sin(a)))
  b.tube(pts,.028,'gold',5)
 def lotus(x,y,z,r=.65):
  # underside lotus medallion carved in concentric petal loops
  ring_xy(x,y,z,r*.25,.035);ring_xy(x,y,z,r,.025)
  for k in range(8):
   a=2*pi*k/8;pts=[]
   for j in range(17):
    t=2*pi*j/16;rr=r*(.3+.65*sin(t/2)**2);aa=a+.20*sin(t);pts.append((x+rr*cos(aa),y+rr*sin(aa),z-.035*sin(t/2)))
   b.tube(pts,.022,'gold',5)
  b.sphere((x,y,z-.08),.12,'gold')
 def bracket(x,y,z,scale=1):
  # five diminishing layers suspended from each beam junction, with angled arms
  for k in range(5):
   zz=z-k*.24*scale;span=(3.6-.52*k)*scale
   b.box((x,y,zz),(span,.4*scale,.2*scale),'wood')
   b.box((x,y,zz-.12*scale),(.4*scale,span,.18*scale),'red')
   for sign in [-1,1]:
    b.box((x+sign*(span/2-.13*scale),y,zz+.1*scale),(.26*scale,.55*scale,.18*scale),'gold')
    b.box((x,y+sign*(span/2-.13*scale),zz-.02*scale),(.55*scale,.26*scale,.18*scale),'gold')
  b.cylinder((x,y,z-1.5*scale),.25*scale,.6*scale,'wood',16)
  b.cylinder((x,y,z-1.8*scale),.32*scale,.11*scale,'gold',16)
  for sg in [-1,1]:
   b.tube([(x+sg*1.65*scale,y,z+.03*scale),(x+sg*1.2*scale,y,z-.45*scale),(x+sg*.5*scale,y,z-1.1*scale),(x,y,z-1.3*scale)],.09*scale,'red',8)
   scroll_xz(x+sg*.55*scale,y-.24*scale,z-.55*scale,.36*scale,sg)
 def gallery_rail(x0,x1,y,z):
  for dz in [.12,1.15]:b.box(((x0+x1)/2,y,z+dz),(x1-x0,.12,.12),'gold' if dz>1 else 'wood')
  count=max(3,int((x1-x0)/1.4))
  for i in range(count+1):
   x=x0+(x1-x0)*i/count;b.box((x,y,z+.6),(.12,.12,1.25),'wood');b.sphere((x,y,z+1.28),.1,'gold')
  for i in range(count):
   x=x0+(x1-x0)*(i+.5)/count
   b.box((x,y,z+.6),((x1-x0)/count-.2,.07,.48),'dark')
   for zz in [.38,.82]:b.box((x,y-.055,z+zz),((x1-x0)/count-.27,.035,.028),'gold')
   scroll_xz(x,y-.06,z+.6,.15)
 def lantern(x,y,z,scale=1):
  b.tube([(x,y,z+3.3*scale),(x,y,z+.6*scale)],.025*scale,'gold',6)
  b.cylinder((x,y,z),.23*scale,1.0*scale,'silk',8)
  for zz in [-.55,.55]:
   b.cylinder((x,y,z+zz*scale),.36*scale,.1*scale,'wood',8);b.cylinder((x,y,z+(zz-.05)*scale),.34*scale,.04*scale,'gold',8)
  for k in range(8):
   a=2*pi*k/8;b.tube([(x+.24*scale*cos(a),y+.24*scale*sin(a),z-.5*scale),(x+.24*scale*cos(a),y+.24*scale*sin(a),z+.5*scale)],.025*scale,'gold',6)
  b.tube([(x,y,z-.6*scale),(x,y,z-1.45*scale)],.025*scale,'red',5);b.sphere((x,y,z-.7*scale),.1*scale,'gold')
 # broad connected side galleries. Side bands preserve projected portal opening.
 for side,x0,x1 in [(-1,-64,-14),(1,35,70)]:
  for iy,y in enumerate([39,52,65,78,91]):
   z=41.0+iy*.65
   # long layered carved cornices mask sparse underlying warehouse beams
   for dz,th,ma in [(0,.75,'wood'),(-.45,.16,'gold'),(-.75,.4,'red'),(-1.02,.1,'gold')]:
    b.box(((x0+x1)/2,y,z+dz),(x1-x0,1.4,th),ma)
   n=int((x1-x0)/4)
   for k in range(n+1):
    xx=x0+(x1-x0)*k/n;bracket(xx,y,z-.9,.75)
    if k<n:
     # fret / rosette motifs on the beam's vertical face
     for q in range(4):scroll_xz(xx+(q+.5)*(x1-x0)/n/4,y-.76,z-.15,.25)
   # open gallery above each cornice: rail, thin columns and connected headers
   gallery_rail(x0,x1,y-.4,z+.45)
   b.box(((x0+x1)/2,y,z+4.4),(x1-x0,.32,.32),'wood')
   b.box(((x0+x1)/2,y-.2,z+4.25),(x1-x0,.09,.06),'gold')
   for k in range(0,n+1,2):
    xx=x0+(x1-x0)*k/n;b.cylinder((xx,y,z+2.4),.14,4.0,'red',12)
    b.cylinder((xx,y,z+4.2),.23,.18,'gold',12)
  # transverse layered spine beams and octagonal recessed caissons
  for x in [x0+4+j*6 for j in range(int((x1-x0-6)/6)+1)]:
   b.box((x,65,42.0),(1.0,61,.7),'wood')
   for dx in [-.55,.55]:b.box((x+dx,65,41.75),(.065,61,.08),'gold')
   for y in [44,57,70,83]:
    z=40.6+(y-44)*.05
    # paneled octagonal coffers built as concentric raised bands, not floating checkerboards
    b.box((x,y,z+.2),(5.5,7.0,.22),'dark')
    for rr,dz in [(2.5,0),(2.15,-.12),(1.72,-.24)]:
     pts=[(x+rr*cos(pi/8+2*pi*j/8),y+rr*sin(pi/8+2*pi*j/8),z+dz) for j in range(9)]
     b.tube(pts,.07 if rr==2.5 else .035,'gold' if rr!=2.15 else 'red',6)
    lotus(x,y,z-.35,1.15)
    # fine beam ribs stitch each coffer into structure
    for sg in [-1,1]:
     b.box((x+sg*2.8,y,z),( .2,7.0,.35),'red')
     b.box((x,y+sg*3.5,z),(5.8,.22,.35),'wood')
  # long gilt side soffit edge with staggered pendant lamps
  inner=x1 if side<0 else x0
  for zz in [39.6,40.0,40.5]:b.box((inner,64,zz),(.25,60,.16),'gold' if zz!=40 else 'wood')
  for j,y in enumerate([41,59,77]):lantern(inner+side*.35,y,37.7+j*.7,.85)
 # dress the existing colossal supports in rounded lacquer and carved bronze collars
 for x in [-53,-41,-29,-17,31,43,55]:
  for y in [36,62,88]:
   if y==36 and abs(x)<38:continue
   if y==62 and x==-17:continue
   b.cylinder((x,y,28),.53,29.8,'wood',20)
   for z in [13.5,14.0,38.1,39.0,41.0]:
    b.cylinder((x,y,z),.7,.13,'gold',20)
   for z in [14.6,37.2,40.0]:
    b.cylinder((x,y,z),.59,1.0,'red',20)
    for j in range(6):
     a=2*pi*j/6;xx=x+.6*cos(a);yy=y+.6*sin(a)
     b.tube([(xx,yy,z-.42),(xx,yy,z+.42)],.022,'gold',5)
    scroll_xz(x,y-.61,z,.36)
   for a in [-pi*.25,-pi*.75]:
    xx=x+.54*cos(a);yy=y+.54*sin(a)
    b.tube([(xx,yy,15.3),(xx,yy,36.5)],.018,'gold',5)
 # monumental upper moon-gate archivolt: decorative structure stays outside inner radius
 cx,cy,cz=10,45.4,22.5
 for r,yy,th,ma in [(23.85,cy,.20,'wood'),(24.3,cy-.12,.12,'gold'),(25.2,cy+.2,.25,'wood'),(25.65,cy+.12,.10,'gold')]:
  pts=[(cx+r*cos(math.radians(20+140*i/112)),yy,cz+r*sin(math.radians(20+140*i/112))) for i in range(113)];b.tube(pts,th,ma,10)
 # tangential lattice and stylized floral panels follow the arch crown
 for k in range(57):
  a=math.radians(20+140*k/56);rr=24.75
  b.tube([(cx+23.95*cos(a),cy,cz+23.95*sin(a)),(cx+25.5*cos(a),cy,cz+25.5*sin(a))],.05,'gold',6)
  if k%2==0:
   p=(cx+rr*cos(a),cy-.14,cz+rr*sin(a));b.sphere(p,.12,'gold')
   # four petal filigree around each arc rosette
   for kk in range(4):
    aa=kk*pi/2;px=p[0]+.19*cos(aa);pz=p[2]+.19*sin(aa)
    b.tube([(px+.15*cos(t*2*pi/16),cy-.13,pz+.10*sin(t*2*pi/16)) for t in range(17)],.018,'gold',5)
 # interconnecting stepped upper cross galleries behind and above the crown
 for y,z,x0,x1 in [(87,55,-55,67),(103,61,-62,73)]:
  b.box(((x0+x1)/2,y,z),(x1-x0,4.6,.6),'wood');gallery_rail(x0,x1,y-2.4,z+.32)
  for zz,ma in [(z-.4,'gold'),(z-.7,'red')]:b.box(((x0+x1)/2,y-2.4,zz),(x1-x0,.3,.18),ma)
  for xx in range(int(x0)+2,int(x1),6):
   bracket(xx,y-2,z-.6,.8);b.cylinder((xx,y,z+3.0),.16,5.8,'red',12)
  b.box(((x0+x1)/2,y,z+5.8),(x1-x0,.55,.5),'wood')
 roots.append(b.finish('Sky palace / carved suspended gallery network',(0,0,0)))
 # elevated pavilions bring recognizable roof silhouettes and inhabited galleries
 for name,pos,w,d,st,sh,seed in [
  ('Upper left celestial gallery',(-42,64,38),20,12,2,5.5,410),
  ('Upper right celestial gallery',(49,68,37),22,13,2,5.8,411),
  ('Receding west sky pavilion',(-27,90,46),12,9,2,4.2,412),
  ('Receding east sky pavilion',(37,101,49),13,9,2,4.4,413),
  ('Crown watch pavilion',(9,103,61),15,10,2,4.5,414)]:
  roots.append(build_pavilion(name,pos,w,d,st,sh,seed))
 return roots
