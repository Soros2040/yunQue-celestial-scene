"""Procedural floating cliffs, flowing falls and turbulent volume clouds.
No external files; build_island() and build_cloudsea() are scene-safe.
"""
import bpy, math, random
from mathutils import Vector, noise
from math import sin,cos,pi

def _material(name,color,rough=.7,metal=0):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 return m

def _materials():
 rock=_material('Cliff | weathered charcoal schist',(.075,.105,.13),.83)
 if 'Erosion color' not in rock.node_tree.nodes:
  n=rock.node_tree.nodes;l=rock.node_tree.links;p=n.get('Principled BSDF');tc=n.new('ShaderNodeTexCoord');tex=n.new('ShaderNodeTexNoise');tex.name='Erosion color';tex.inputs['Scale'].default_value=2.2;tex.inputs['Detail'].default_value=5;tex.inputs['Roughness'].default_value=.78;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].color=(.018,.027,.035,1);r.color_ramp.elements[1].color=(.23,.25,.23,1);r.color_ramp.elements.new(.57).color=(.065,.09,.1,1);b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.56;b.inputs['Distance'].default_value=.3;l.new(tc.outputs['Object'],tex.inputs[0]);l.new(tex.outputs['Fac'],r.inputs[0]);l.new(r.outputs[0],p.inputs['Base Color']);l.new(tex.outputs['Fac'],b.inputs['Height']);l.new(b.outputs[0],p.inputs['Normal'])
 strata=_material('Cliff | mineral strata',(.2,.225,.22),.9)
 moss=_material('Cliff | moss and roots',(.055,.095,.04),.95)
 water=_material('Waterfall | aerated silver water',(.55,.72,.8),.16,.08)
 if 'Streak turbulence' not in water.node_tree.nodes:
  n=water.node_tree.nodes;l=water.node_tree.links;p=n.get('Principled BSDF');tc=n.new('ShaderNodeTexCoord');mp=n.new('ShaderNodeVectorMath');mp.operation='MULTIPLY';mp.inputs[1].default_value=(18,.1,.45);tex=n.new('ShaderNodeTexNoise');tex.name='Streak turbulence';tex.inputs['Scale'].default_value=1.7;tex.inputs['Detail'].default_value=3;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.25;r.color_ramp.elements[0].color=(.05,.09,.13,1);r.color_ramp.elements[1].position=.7;r.color_ramp.elements[1].color=(.85,.94,1,1);b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.23;b.inputs['Distance'].default_value=.11;l.new(tc.outputs['Object'],mp.inputs[0]);l.new(mp.outputs[0],tex.inputs[0]);l.new(tex.outputs[0],r.inputs[0]);l.new(r.outputs[0],p.inputs['Base Color']);l.new(tex.outputs[0],b.inputs['Height']);l.new(b.outputs[0],p.inputs['Normal']);p.inputs['Emission Color'].default_value=(.12,.22,.27,1);p.inputs['Emission Strength'].default_value=.025
  # Broken, translucent falling spray rather than opaque white ribbons.
  mask=n.new('ShaderNodeValToRGB');mask.name='Broken falling streak alpha';mask.color_ramp.elements[0].position=.36;mask.color_ramp.elements[0].color=(0,0,0,1);mask.color_ramp.elements[1].position=.68;mask.color_ramp.elements[1].color=(.82,.82,.82,1)
  sep=n.new('ShaderNodeSeparateXYZ');fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.02;fade.inputs['From Max'].default_value=.38;fade.inputs['To Min'].default_value=0;fade.inputs['To Max'].default_value=1;fade.clamp=True;mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
  l.new(tex.outputs['Fac'],mask.inputs[0]);l.new(tc.outputs['Generated'],sep.inputs[0]);l.new(sep.outputs['Z'],fade.inputs[0]);l.new(mask.outputs[0],mul.inputs[0]);l.new(fade.outputs[0],mul.inputs[1]);l.new(mul.outputs[0],p.inputs['Alpha']);p.inputs['Transmission Weight'].default_value=.16;p.inputs['Roughness'].default_value=.24
  if hasattr(water,'surface_render_method'):water.surface_render_method='DITHERED'
 foam=_material('Waterfall | white foam threads',(.74,.85,.9),.44)
 return rock,strata,moss,water,foam

def _mesh(name,verts,faces,mats,mi=None,smooth=False):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
 for m in mats:me.materials.append(m)
 ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob)
 for i,p in enumerate(me.polygons):p.use_smooth=smooth;p.material_index=mi[i] if mi else 0
 return ob

def _tube_append(verts,faces,points,radii,sides=5):
 base=len(verts)
 for j,p in enumerate(points):
  tan=Vector(points[min(j+1,len(points)-1)])-Vector(points[max(0,j-1)]);tan.normalize();u=tan.cross(Vector((0,0,1)))
  if u.length<.01:u=tan.cross(Vector((1,0,0)))
  u.normalize();v=tan.cross(u).normalized()
  for k in range(sides):verts.append(Vector(p)+radii[j]*(u*cos(2*pi*k/sides)+v*sin(2*pi*k/sides)))
 for j in range(len(points)-1):
  for k in range(sides):a=base+j*sides+k;b=base+j*sides+(k+1)%sides;faces.append((a,b,b+sides,a+sides))

def build_island(name,center=(0,0,0),radius=(10,8),depth=8,seed=1,waterfalls=True):
 rng=random.Random(seed);cx,cy,cz=center;rx,ry=radius;rock,strata,moss,water,foam=_materials();verts=[];faces=[];mi=[];nr=112;nl=18
 phases=[rng.random()*6.28 for i in range(6)]
 def contour(a):return 1+.1*sin(3*a+phases[0])+.075*sin(7*a+phases[1])+.045*sin(13*a+phases[2])+.028*sin(29*a+phases[3])
 for j in range(nl):
  t=j/(nl-1); taper=(1-.2*t-.38*t*t);offx=.12*rx*sin(t*3+phases[4])*t;offy=.16*ry*sin(t*2+phases[5])*t
  for i in range(nr):
   a=2*pi*i/nr;c=contour(a);r=taper*c*(1+.055*sin(j*3.4+i*.7)+.035*sin(i*1.5+j*.3));z=cz-depth*t+.18*sin(i*.8+j*.2)+.16*sin(i*.21+j*1.4)
   if j==0:z=cz+.08*sin(i*.6)
   verts.append((cx+rx*r*cos(a)+offx,cy+ry*r*sin(a)+offy,z))
 for j in range(nl-1):
  for i in range(nr):a=j*nr+i;b=j*nr+(i+1)%nr;faces.append((a,a+nr,b+nr,b));mi.append(1 if j in [1,6,12] and rng.random()<.5 else 0)
 # irregular but mostly level upper terrace
 top=len(verts);verts.append((cx,cy,cz+.04))
 for i in range(nr):faces.append((top,i,(i+1)%nr));mi.append(2 if rng.random()<.35 else 0)
 bottom=len(verts);verts.append((cx-.3*rx,cy+.1*ry,cz-depth*1.13))
 for i in range(nr):faces.append((bottom,(nl-1)*nr+(i+1)%nr,(nl-1)*nr+i));mi.append(0)
 ob=_mesh(name+' | eroded layered plateau',verts,faces,[rock,strata,moss],mi)
 # rock buttresses and hanging columnar fractured roots, batched
 vv=[];ff=[]
 for q in range(32):
  a=2*pi*q/32+rng.uniform(-.06,.06);c=contour(a);start=Vector((cx+rx*c*.96*cos(a),cy+ry*c*.96*sin(a),cz-.2));h=depth*rng.uniform(.5,1.15);rad=rng.uniform(.22,.65)*min(rx,ry)/8;pts=[];rr=[]
  for j in range(8):
   t=j/7;pts.append(start+Vector((-cos(a)*rx*.2*t+sin(t*4+q)*.2,-sin(a)*ry*.2*t,-h*t)));rr.append(rad*(1-.65*t)*(1+.15*sin(j*3+q)))
  _tube_append(vv,ff,pts,rr,7)
 _mesh(name+' | fractured cliff buttresses',vv,ff,[rock],smooth=False)
 # scattered irregular stones/moss shelves are additional geometry, one mesh
 vv=[];ff=[];mm=[]
 for q in range(85):
  a=rng.uniform(0,2*pi);r=rng.uniform(.25,1);x=cx+rx*r*cos(a);y=cy+ry*r*sin(a);z=cz+rng.uniform(.02,.2);sz=rng.uniform(.13,.5);base=len(vv)
  for j in range(7):ang=2*pi*j/7;vv.append((x+cos(ang)*sz*(1+rng.uniform(-.2,.2)),y+sin(ang)*sz,z+rng.uniform(-.05,.08)))
  vv.append((x,y,z+sz*.45))
  for j in range(7):ff.append((base+j,base+(j+1)%7,base+7));mm.append(1 if q%3 else 0)
 _mesh(name+' | mossy weathered rim stones',vv,ff,[rock,moss],mm)
 if waterfalls:
  vv=[];ff=[];sv=[];sf=[]
  # many thin fall groups clustered on the visible/front rim, leaving cliff gaps
  groups=[(-.82,.20),(-.45,.18),(.05,.27),(.5,.16),(.8,.14)]
  for gi,(u,span) in enumerate(groups):
   for q in range(rng.randint(3,6)):
    xx=u+span*rng.random();ang=-math.acos(max(-.99,min(.99,xx)));c=contour(ang);x=cx+rx*c*cos(ang);y=cy+ry*c*sin(ang);h=depth*rng.uniform(.65,1.25);width=rng.uniform(.25,.57)*rx/10;phase=rng.uniform(0,6.28);base=len(vv)
    for j in range(25):
     t=j/24;dx=.07*sin(11*t+phase)+.02*sin(41*t);yy=y-.2*t-.5*t*t;ww=width*(1+.15*sin(t*12+phase))
     vv.extend([(x+dx-ww/2,yy,cz-.08-h*t),(x+dx+ww/2,yy+.04,cz-.08-h*t)])
    for j in range(24):a=base+2*j;ff.append((a,a+1,a+3,a+2))
    # hairline foam threads along falling sheet
    for s in [-.27,.2]:
     pts=[];rr=[]
     for j in range(14):t=j/13;pts.append((x+s*width+.055*sin(t*14+phase),y-.2*t-.5*t*t-.025,cz-h*t));rr.append(.012*(1+.4*sin(t*10)))
     _tube_append(sv,sf,pts,rr,4)
  _mesh(name+' | falling water sheets',vv,ff,[water],smooth=True);_mesh(name+' | bright falling rivulets',sv,sf,[foam],smooth=True)
 return ob

def _cloud_material(name='Cloud | eroded fractal scattering v3',density=.65):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;out=n.new('ShaderNodeOutputMaterial');vol=n.new('ShaderNodeVolumePrincipled');vol.inputs['Color'].default_value=(.995,.997,1,1);vol.inputs['Anisotropy'].default_value=.25
 tc=n.new('ShaderNodeTexCoord');no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=1.65;no.inputs['Detail'].default_value=5;no.inputs['Roughness'].default_value=.78;no.inputs['Distortion'].default_value=.28
 detail=n.new('ShaderNodeTexNoise');detail.inputs['Scale'].default_value=5.8;detail.inputs['Detail'].default_value=3;detail.inputs['Roughness'].default_value=.8
 r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.48;r.color_ramp.elements[0].color=(0,0,0,1);r.color_ramp.elements[1].position=.64;r.color_ramp.elements[1].color=(5,5,5,1)
 rd=n.new('ShaderNodeMapRange');rd.inputs['From Min'].default_value=.25;rd.inputs['From Max'].default_value=.7;rd.inputs['To Min'].default_value=0;rd.inputs['To Max'].default_value=1.2;rd.clamp=True
 dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,.5);fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.28;fade.inputs['From Max'].default_value=.6;fade.inputs['To Min'].default_value=1;fade.inputs['To Max'].default_value=0;fade.clamp=True
 mult=n.new('ShaderNodeMath');mult.operation='MULTIPLY';mult2=n.new('ShaderNodeMath');mult2.operation='MULTIPLY'
 for aa,bb in [(tc.outputs['Object'],no.inputs[0]),(tc.outputs['Object'],detail.inputs[0]),(no.outputs['Fac'],r.inputs[0]),(detail.outputs['Fac'],rd.inputs[0]),(tc.outputs['Generated'],dist.inputs[0]),(dist.outputs['Value'],fade.inputs[0]),(r.outputs[0],mult.inputs[0]),(rd.outputs[0],mult.inputs[1]),(mult.outputs[0],mult2.inputs[0]),(fade.outputs[0],mult2.inputs[1]),(mult2.outputs[0],vol.inputs['Density']),(vol.outputs[0],out.inputs['Volume'])]:l.new(aa,bb)
 return m

def _cloud_group(name,center,scale,rng,material,lobes=10):
 # Metaball union creates actual connected lumpy bounds, then shader scatters inside.
 mb=bpy.data.metaballs.new(name+' bounds');mb.resolution=.38;mb.render_resolution=.38;mb.threshold=.7;ob=bpy.data.objects.new(name,mb);bpy.context.collection.objects.link(ob);ob.location=center
 for i in range(lobes*3):
  el=mb.elements.new();el.type='BALL';el.co=(rng.uniform(-3.5,3.5),rng.uniform(-2.7,2.7),rng.uniform(-.7,1.5));el.radius=rng.uniform(1.0,1.7);el.stiffness=2
 bpy.ops.object.select_all(action='DESELECT');bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob=bpy.context.object;ob.name=name;ob.scale=scale;ob.data.materials.append(material)
 for ve in ob.data.vertices:
  p=ve.co.copy();f=.55*noise.noise_vector(p*1.8)[0]+.16*noise.noise_vector(p*5.3)[1];ve.co+=ve.normal*f
 for p in ob.data.polygons:p.use_smooth=True
 ob.select_set(False);return ob

def build_cloudsea(seed=5):
 rng=random.Random(seed);ma=_cloud_material();obs=[]
 # Lateral pockets leave a readable central bridge/island corridor. All crowns stay below z~4.
 groups=[(-34,10,-4,(2.5,2,1.15)),(30,13,-5,(2.8,2.1,1.2)),(-22,28,-5,(2.8,2.5,1.25)),(-6,24,-6,(2.8,2.2,1.15)),(20,25,-6,(2.8,2.4,1.1)),(38,35,-4,(3,2.5,1.45)),(-38,42,-4,(3.2,2.5,1.4)),(-14,45,-5,(3.4,2.7,1.35)),(10,49,-5,(3.5,2.7,1.3)),(32,60,-4,(3.5,3,1.5)),(-34,65,-5,(3.5,3,1.5)),(-6,72,-5,(4,3.5,1.5)),(18,84,-5,(4,3.5,1.5)),(-26,96,-5,(4.5,3.5,1.5)),(0,115,-5,(5,4,1.7)),(38,105,-4,(4.5,4,1.7))]
 groups.extend([(-23,8,-7,(2.5,2,1.15)),(-6,12,-8,(2.7,2.2,1.15)),(13,12,-8,(2.7,2.2,1.15)),(-29,22,-5,(2.8,2.3,1.2)),(-13,30,-5,(2.7,2.3,1.2)),(6,34,-5,(2.7,2.4,1.2)),(25,39,-5,(2.7,2.3,1.2)),(-44,30,-5,(3,2.5,1.2)),(45,26,-5,(3,2.5,1.2))])
 for i,(x,y,z,sc) in enumerate(groups):obs.append(_cloud_group('Cloud sea | billow %02d'%i,(x,y,z+(0 if y<20 else 7)),sc,rng,ma,12))
 # Tall cumulus at distant sides, behind architecture and clear of moon-gate interior
 for i,(x,y,z,sc) in enumerate([(-52,95,8,(4,3,3.5)),(53,105,12,(4,3,4.5)),(-57,135,16,(5,4,5)),(64,142,18,(5,4,5))]):obs.append(_cloud_group('Cloud horizon | cumulus %02d'%i,(x,y,z),sc,rng,ma,14))
 # Prominent scalloped cloud canyon banks, visible above cliff bases.
 for i,(x,y,z,sc) in enumerate([(-18,17,5,(3.2,2.5,1.7)),(-3,24,4,(3.5,2.6,1.8)),(28,24,5,(3.0,2.5,1.65)),(2,48,7,(4.0,3.0,2.0)),(-20,60,11,(4.0,3.2,2.4)),(25,65,10,(4.2,3.2,2.5)),(-8,85,9,(5.0,3.6,2.3)),(22,94,12,(4.5,3.6,2.6)),(-30,83,19,(4.5,3.3,3.3)),(39,105,21,(4.3,3.5,4.0))]):
  obs.append(_cloud_group('Cloud canyon | luminous bank %02d'%i,(x,y,z),sc,rng,ma,14))
 return obs
