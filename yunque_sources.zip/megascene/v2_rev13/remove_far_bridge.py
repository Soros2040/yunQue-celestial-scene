"""Remove only unsupported distant bridge exposed by the corrected cloud opening."""
import bpy,bmesh

def remove_unsupported_far_bridge():
 count=0
 for ob in bpy.data.objects:
  if ob.type!='MESH' or not ob.name.startswith('Moon gate / terraces / bridge'):continue
  bm=bmesh.new();bm.from_mesh(ob.data)
  chosen=[v for v in bm.verts if 11.5<v.co.x<38.5 and 73.5<v.co.y<76.5 and 10.5<v.co.z<16]
  if chosen:
   count+=len(chosen);bmesh.ops.delete(bm,geom=chosen,context='VERTS');bm.to_mesh(ob.data);ob.data.update()
  bm.free()
 print('REMOVED_UNSUPPORTED_BRIDGE_VERTICES',count,flush=True)
 return count
