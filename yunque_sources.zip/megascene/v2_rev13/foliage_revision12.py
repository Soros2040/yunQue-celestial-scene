"""Replace only the REV11/CASCADE small pine meshes with dense sculptural pines.
Call apply_foliage_revision() on a revision11 scene. No render/save or light changes.
Self-contained; actual ground ray casts, geometry canopy pads and needle tufts.
"""
import bpy, math, random
from mathutils import Vector, noise


def _mat(name,color,rough=.85):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough
 n=m.node_tree.nodes;l=m.node_tree.links;t=n.new('ShaderNodeTexNoise');t.inputs['Scale'].default_value=21;t.inputs['Detail'].default_value=3
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(*(v*.55 for v in color),1);ramp.color_ramp.elements[1].color=(*(v*1.55 for v in color),1)
 b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.4;b.inputs['Distance'].default_value=.035
 l.new(t.outputs['Fac'],ramp.inputs[0]);l.new(ramp.outputs[0],p.inputs['Base Color']);l.new(t.outputs['Fac'],b.inputs['Height']);l.new(b.outputs[0],p.inputs['Normal'])
 return m


def _mesh(name,vs,fs,mats,mi=None):
 me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob)
 for m in mats:me.materials.append(m)
 for i,p in enumerate(me.polygons):p.use_smooth=True;p.material_index=mi[i] if mi else 0
 return ob


def _tube(vs,fs,points,radii,sides=7):
 start=len(vs)
 for i,p in enumerate(points):
  p=Vector(p);d=(Vector(points[min(i+1,len(points)-1)])-Vector(points[max(i-1,0)])).normalized();u=d.cross(Vector((0,1,0))).normalized();v=d.cross(u).normalized()
  for j in range(sides):vs.append(tuple(p+radii[i]*(u*math.cos(j*math.tau/sides)+v*math.sin(j*math.tau/sides))))
 for i in range(len(points)-1):
  for j in range(sides):a=start+i*sides+j;b=start+i*sides+(j+1)%sides;fs.append((a,b,b+sides,a+sides))


def _pad(center,radius,rng,vs,fs,mi,shade=0):
 # A pad is three overlapping asymmetric, serrated flattened lobes, not a sphere.
 for lobe in range(3):
  c=Vector(center)+Vector((rng.uniform(-.32,.32)*radius,rng.uniform(-.25,.25)*radius,rng.uniform(-.05,.05)*radius))
  rx=radius*(1 if lobe==0 else rng.uniform(.5,.75));ry=rx*rng.uniform(.57,.83);rz=rx*rng.uniform(.19,.3)
  phase=rng.random()*10;start=len(vs);sides=20;rings=7
  for k in range(rings):
   a=-math.pi/2+math.pi*(k+.08)/(rings-.84);z=math.sin(a);r=math.cos(a)
   for j in range(sides):
    th=j*math.tau/sides;wav=1+.13*math.sin(th*5+phase)+.09*math.sin(th*9-phase)+rng.uniform(-.07,.07)
    pp=c+Vector((rx*r*math.cos(th)*wav,ry*r*math.sin(th)*wav,rz*z+.035*rx*math.sin(th*7+k)))
    vs.append(tuple(pp))
  for k in range(rings-1):
   for j in range(sides):
    a=start+k*sides+j;b=start+k*sides+(j+1)%sides;fs.append((a,b,b+sides,a+sides));mi.append(shade if rng.random()<.86 else 1)
 # Dense visible needle fans make the silhouette feathered at render scale.
 for j in range(62):
  a=rng.uniform(0,math.tau);r=radius*math.sqrt(rng.uniform(.1,1.1));p=Vector(center)+Vector((r*math.cos(a),r*.75*math.sin(a),rng.uniform(-.04,.15)*radius))
  direction=Vector((math.cos(a),math.sin(a),rng.uniform(.08,.45)));side=Vector((-math.sin(a),math.cos(a),0))*radius*rng.uniform(.025,.045)
  start=len(vs);vs.extend([tuple(p-side),tuple(p+side),tuple(p+direction*radius*rng.uniform(.18,.35))]);fs.append((start,start+1,start+2));mi.append(1 if j%5==0 else shade)


def _tree(root,h,rng,wv,wf,lv,lf,lm):
 root=Vector(root);wind=Vector((h*rng.uniform(.25,.45),h*rng.uniform(-.12,.12),0))
 path=[root+wind*(.2*math.sin(t*math.pi)+.8*t)+Vector((0,0,h*t*.88)) for t in [i/14 for i in range(15)]]
 _tube(wv,wf,path,[h*.055*(1-.88*i/14) for i in range(15)],8)
 for layer in range(3):
  t=.35+.23*layer;origin=root+wind*(.2*math.sin(t*math.pi)+.8*t)+Vector((0,0,h*t*.88))
  for j in range(3):
   a=j*math.tau/3+layer*.65+rng.uniform(-.2,.2);length=h*(.51-.09*layer)*rng.uniform(.85,1.12)
   end=origin+Vector((math.cos(a)*length,math.sin(a)*length*.8,h*.09));mid=origin.lerp(end,.6)-Vector((0,0,h*.055))
   _tube(wv,wf,[origin,mid,end],[h*.028,h*.016,h*.005],7)
   padcenter=end+Vector((h*.07,0,h*.035));_pad(padcenter,h*(.25-.035*layer),rng,lv,lf,lm)
 _pad(path[-1]+Vector((h*.07,0,0)),h*.22,rng,lv,lf,lm)


def _ground(ob,x,y):
 inv=ob.matrix_world.inverted();hit,p,n,i=ob.ray_cast(inv@Vector((x,y,100)),(inv.to_3x3()@Vector((0,0,-1))).normalized())
 return ob.matrix_world@p if hit else None


def apply_foliage_revision():
 if bpy.data.objects.get('REV12 | dense windswept pine crowns'):raise RuntimeError('Revision12 foliage already applied')
 # Hide rather than delete previous foliage so rollback remains straightforward.
 oldnames={'REV11 | grounded windswept pine wood','REV11 | grounded pine needles and scrub','CASCADE | pine trunks and branches','CASCADE | individual pine needle fans'}
 hidden=[]
 for name in oldnames:
  ob=bpy.data.objects.get(name)
  if ob:ob.hide_render=True;ob.hide_viewport=True;hidden.append(name)
 wood=_mat('REV12 | sculptural pine bark',(.07,.065,.043));green=_mat('REV12 | dense deep jade needle pads',(.035,.085,.045));tip=_mat('REV12 | olive sunlit needle tips',(.09,.15,.055))
 rng=random.Random(12063);wv=[];wf=[];lv=[];lf=[];lm=[];roots=[]
 terrain=[o for o in bpy.data.objects if 'finely eroded layered plateau' in o.name and ('CASCADE' in o.name or 'HERO' in o.name.upper())]
 for ob in terrain:
  corners=[ob.matrix_world@Vector(c) for c in ob.bound_box];cx=(min(p.x for p in corners)+max(p.x for p in corners))/2;cy=(min(p.y for p in corners)+max(p.y for p in corners))/2;rx=(max(p.x for p in corners)-min(p.x for p in corners))/2;ry=(max(p.y for p in corners)-min(p.y for p in corners))/2
  angles=[-2.55,-.55,1.15] if 'CASCADE' in ob.name else [-2.6,-1.8,-.35,.4]
  for a in angles:
   root=_ground(ob,cx+rx*.7*math.cos(a),cy+ry*.68*math.sin(a))
   if root is None:continue
   h=rng.uniform(1.9,2.45);_tree(root-Vector((0,0,.025)),h,rng,wv,wf,lv,lf,lm);roots.append((ob.name,tuple(root),h))
  for k in range(5):
   a=rng.uniform(-math.pi,math.pi);root=_ground(ob,cx+rx*.8*math.cos(a),cy+ry*.78*math.sin(a))
   if root is not None:_pad(root+Vector((0,0,.18)),rng.uniform(.32,.55),rng,lv,lf,lm)
 objects=[_mesh('REV12 | sculptural crooked pine trunks',wv,wf,[wood]),_mesh('REV12 | dense windswept pine crowns',lv,lf,[green,tip],lm)]
 report={'hidden_previous':hidden,'trees':len(roots),'vertices':len(wv)+len(lv),'faces':len(wf)+len(lf),'roots':roots,'objects':objects}
 print('REV12 FOLIAGE',len(roots),'trees;',len(wv)+len(lv),'vertices;',len(wf)+len(lf),'faces; replaced',hidden)
 for ob in objects:
  bpy.context.view_layer.update();corners=[ob.matrix_world@Vector(c) for c in ob.bound_box];print(ob.name,'bounds',tuple(round(min(p[i] for p in corners),3) for i in range(3)),tuple(round(max(p[i] for p in corners),3) for i in range(3)))
 return report

# Explicit descriptive alias for assembly scripts.
apply_foliage_revision12=apply_foliage_revision
