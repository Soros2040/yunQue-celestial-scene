"""Single coherent corrected revision: grounding, nature, light, material and relief."""
import bpy,os,sys,json
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT);s=bpy.context.scene
if s.get('Coherent revision11 applied'):raise RuntimeError('Already applied')
from fix_bridge_pilgrims import fix_bridge_pilgrims,ray_ground,floor_objects
checks=fix_bridge_pilgrims()
for o in list(bpy.data.objects):
 if o.name.startswith('Scholar -13.5 ') or o.name in ['Face','Hair crown','Top knot']:
  bpy.data.objects.remove(o,do_unlink=True)
from hero_scholar_v2 import build_scholar
hero=build_scholar(root=(-13.5,-10,8),height=2.7);bpy.context.view_layer.update();anchor=bpy.data.objects[hero['root_object']]
feet=[o for o in bpy.data.objects if o.name.startswith('SCHOLAR V2 • hidden slipper')];low=min((o.matrix_world@v.co).z for o in feet for v in o.data.vertices);ground=ray_ground(-13.5,-10,8,floor_objects())[0];anchor.location.z+=ground-low;bpy.context.view_layer.update();foot=min((o.matrix_world@v.co).z for o in feet for v in o.data.vertices)
assert abs(foot-ground)<.001
from architecture_revision11 import apply_architecture_revision
apply_architecture_revision()
from landscape_revision11 import apply_landscape_revision
apply_landscape_revision()
from lighting_floor_revision11 import apply_lighting_floor_revision
apply_lighting_floor_revision()
from refine_sky11b import refine_sky
refine_sky();bpy.context.view_layer.update()
# Clear-sun line test against actual cloud boundaries, not just a screen assumption.
origin=s.camera.location.copy();target=Vector((50,300,22));ray=(target-origin).normalized();blockers=[]
for o in bpy.data.objects:
 if o.type=='MESH' and 'cloud' in o.name.lower():
  inv=o.matrix_world.inverted();ok,co,n,idx=o.ray_cast(inv@origin,(inv.to_3x3()@ray).normalized())
  if ok and (o.matrix_world@co-origin).length<(target-origin).length:blockers.append(o.name)
if blockers:raise RuntimeError('Cloud intersects sun corridor: '+str(blockers))
s['Coherent revision11 applied']=True
report={'bridge_grounding':checks,'hero_foot_z':foot,'hero_ground_z':ground,'sun_cloud_blockers':blockers,'unique_mesh_vertices':sum(len(d.vertices) for d in {o.data for o in bpy.data.objects if o.type=='MESH'}),'status':'geometry tests passed; visual preview required'}
json.dump(report,open(os.path.join(ROOT,'revision11_validation.json'),'w'),ensure_ascii=False,indent=2)
s.cycles.samples=96;s.cycles.use_denoising=False;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.035;s.cycles.volume_step_rate=2;s.cycles.blur_glossy=.5;s.cycles.sample_clamp_indirect=3
s.render.resolution_percentage=50;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8';s.render.use_border=False;s.render.use_crop_to_border=False;s.render.use_compositing=True;s.render.filepath=os.path.join(ROOT,'preview_11.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_可编辑.blend'),compress=True)
if os.environ.get('MEGASCENE_BUILD_ONLY')!='1':bpy.ops.render.render(write_still=True)
