"""Granular rock-crown breakup for hero and cascade shelves. Scene-safe."""
import bpy,bmesh,math,random
from mathutils import Vector,noise
from math import sin,cos,pi
from landscape_v4 import _materials

def build_cliff_rubble():
    if bpy.data.objects.get('CLIFF RUBBLE08 | weathered crowns and ledges'):
        raise RuntimeError('Cliff rubble08 already exists; call once.')
    rock,strata,moss,water,foam=_materials()
    bm=bmesh.new();bmesh.ops.create_icosphere(bm,subdivisions=3,radius=1);bm.verts.ensure_lookup_table();bm.verts.index_update()
    ico=[v.co.copy() for v in bm.verts];tris=[tuple(v.index for v in f.verts) for f in bm.faces];bm.free()
    verts=[];faces=[];matids=[];rng=random.Random(8088)
    islands=[((14,30,10),(14,10),14,11,22),((10,16,7),(5.3,3.2),5.8,601,4),((16,5,5),(6,3.6),6.2,602,4),((25,14,6.5),(5.2,3.3),5.3,603,4),((20,-1,3.8),(4.4,2.7),4.8,604,4)]
    def boulder(center,scale,seed,ledge=False):
        r=random.Random(seed);angle=r.uniform(0,2*pi);ca,sa=cos(angle),sin(angle);off=len(verts)
        for pp in ico:
            fac=1+.18*noise.noise_vector(pp*3.2+Vector((seed*.01,2,4)))[0]+.07*noise.noise_vector(pp*8)[1]
            p=Vector((pp.x*scale[0],pp.y*scale[1],pp.z*scale[2]))*fac
            verts.append((center[0]+p.x*ca-p.y*sa,center[1]+p.x*sa+p.y*ca,center[2]+p.z))
        for tri in tris:
            faces.append(tuple(off+i for i in tri));top=sum(ico[i].z for i in tri)/3
            matids.append(1 if top>.3 and r.random()<( .16 if ledge else .42) else 0)
    for idx,(center,radius,depth,seed,count) in enumerate(islands):
        cx,cy,cz=center;rx,ry=radius;ph=[random.Random(seed).random()]*6
        sr=random.Random(seed);ph=[sr.random()*2*pi for _ in range(6)]
        def contour(a):return 1+.09*sin(3*a+ph[0])+.055*sin(7*a+ph[1])+.035*sin(13*a+ph[2])+.018*sin(29*a+ph[3])
        accepted=0;tries=0
        while accepted<count and tries<300:
            tries+=1;a=rng.uniform(-pi,pi)
            # Preserve waterfall outflow channels on the front edge.
            if sin(a)<0 and any(abs(cos(a)-u)<.045 for u in [-.755,-.4,.005,.36,.72,.89]):continue
            c=contour(a)*rng.uniform(.945,.985);size=rng.uniform(.22,.62)*(1 if idx==0 else .72)
            pos=(cx+rx*c*cos(a),cy+ry*c*sin(a),cz+size*.08)
            boulder(pos,(size*rng.uniform(.8,1.6),size*rng.uniform(.65,1.2),size*rng.uniform(.28,.65)),80800+idx*100+accepted)
            accepted+=1
        if idx==0:
            for j in range(12):
                a=rng.uniform(-pi,0);t=rng.uniform(.17,.66);coarse=noise.noise_vector(Vector((cos(a)*3.2,sin(a)*3.2,t*2.3+seed)))[0];fissure=abs(sin(31*a+.35*sin(t*8+ph[3])))**12
                rad=contour(a)*(1-.12*t-.38*t*t)+.047*coarse-.032*fissure+.012*sin(t*depth*4+sin(a*6))+.008*sin(t*depth*13+a*3)
                ox=.09*rx*sin(t*3+ph[4])*t;oy=.1*ry*sin(t*2+ph[5])*t;sz=rng.uniform(.3,.65)
                pos=(cx+rx*rad*cos(a)+ox+cos(a)*.1,cy+ry*rad*sin(a)+oy+sin(a)*.1,cz-depth*t)
                boulder(pos,(sz*rng.uniform(1.1,1.9),sz*.7,sz*.3),80900+j,True)
    me=bpy.data.meshes.new('Weathered crown boulder mesh');me.from_pydata(verts,[],faces);me.materials.append(rock);me.materials.append(moss);me.update()
    ob=bpy.data.objects.new('CLIFF RUBBLE08 | weathered crowns and ledges',me);bpy.context.collection.objects.link(ob)
    for i,p in enumerate(me.polygons):p.material_index=matids[i];p.use_smooth=True
    ob['purpose']='50 small displaced boulders and embedded ledges break regular plateau rims; waterfall outlets and central roots remain open.'
    return ob
