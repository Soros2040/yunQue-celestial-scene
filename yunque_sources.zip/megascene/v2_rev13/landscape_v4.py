"""Procedural floating cliffs, flowing falls and turbulent volume clouds.
No external files; build_island() and build_cloudsea() are scene-safe.
"""
import bpy, math, random
from mathutils import Vector, noise
from math import sin,cos,pi

def _material(name,color,rough=.7,metal=0):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal
 return m

def _materials():
 rock=_material('Cliff v4 | continuous weathered schist',(.08,.10,.11),.88)
 if 'Weathered mineral color' not in rock.node_tree.nodes:
  n=rock.node_tree.nodes;l=rock.node_tree.links;p=n.get('Principled BSDF');tc=n.new('ShaderNodeTexCoord');coarse=n.new('ShaderNodeTexNoise');coarse.name='Weathered mineral color';coarse.inputs['Scale'].default_value=.85;coarse.inputs['Detail'].default_value=5;coarse.inputs['Roughness'].default_value=.8
  wave=n.new('ShaderNodeTexWave');wave.wave_type='BANDS';wave.bands_direction='Z';wave.inputs['Scale'].default_value=3.8;wave.inputs['Distortion'].default_value=7;wave.inputs['Detail'].default_value=4;wave.inputs['Detail Scale'].default_value=1.2
  mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=.22;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.16;r.color_ramp.elements[0].color=(.022,.032,.039,1);r.color_ramp.elements[1].position=.8;r.color_ramp.elements[1].color=(.25,.26,.22,1);r.color_ramp.elements.new(.48).color=(.08,.10,.105,1)
  fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=12;fine.inputs['Detail'].default_value=3;fine.inputs['Roughness'].default_value=.78;bum=n.new('ShaderNodeBump');bum.inputs['Strength'].default_value=.5;bum.inputs['Distance'].default_value=.14;bf=n.new('ShaderNodeBump');bf.inputs['Strength'].default_value=.38;bf.inputs['Distance'].default_value=.045
  for a,b in [(tc.outputs['Object'],coarse.inputs[0]),(tc.outputs['Object'],wave.inputs[0]),(tc.outputs['Object'],fine.inputs[0]),(coarse.outputs['Fac'],mix.inputs[1]),(wave.outputs['Color'],mix.inputs[2]),(mix.outputs[0],r.inputs[0]),(r.outputs[0],p.inputs['Base Color']),(mix.outputs[0],bum.inputs['Height']),(fine.outputs['Fac'],bf.inputs['Height']),(bum.outputs[0],bf.inputs['Normal']),(bf.outputs[0],p.inputs['Normal'])]:l.new(a,b)
 strata=_material('Cliff v4 | mineral inclusions',(.15,.17,.16),.9)
 moss=_material('Cliff v4 | mottled moss and wet plateau',(.07,.095,.055),.94)
 if 'Moss patches' not in moss.node_tree.nodes:
  n=moss.node_tree.nodes;l=moss.node_tree.links;p=n.get('Principled BSDF');tc=n.new('ShaderNodeTexCoord');t=n.new('ShaderNodeTexNoise');t.name='Moss patches';t.inputs['Scale'].default_value=1.4;t.inputs['Detail'].default_value=5;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].color=(.025,.038,.028,1);r.color_ramp.elements[1].color=(.17,.19,.12,1);r.color_ramp.elements.new(.55).color=(.075,.095,.068,1);b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.5;b.inputs['Distance'].default_value=.065
  for a,bb in [(tc.outputs['Object'],t.inputs[0]),(t.outputs['Fac'],r.inputs[0]),(r.outputs[0],p.inputs['Base Color']),(t.outputs['Fac'],b.inputs['Height']),(b.outputs[0],p.inputs['Normal'])]:l.new(a,bb)
 water=_material('Waterfall v4 | transparent moving veil',(.51,.69,.77),.13)
 if 'Flow streak mask' not in water.node_tree.nodes:
  n=water.node_tree.nodes;l=water.node_tree.links;p=n.get('Principled BSDF');p.inputs['IOR'].default_value=1.333;p.inputs['Transmission Weight'].default_value=.35;tc=n.new('ShaderNodeTexCoord');mp=n.new('ShaderNodeVectorMath');mp.operation='MULTIPLY';mp.inputs[1].default_value=(16,.8,1);tex=n.new('ShaderNodeTexNoise');tex.name='Flow streak mask';tex.inputs['Scale'].default_value=2;tex.inputs['Detail'].default_value=3;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.32;r.color_ramp.elements[0].color=(0,0,0,1);r.color_ramp.elements[1].position=.7;r.color_ramp.elements[1].color=(.5,.5,.5,1)
  sep=n.new('ShaderNodeSeparateXYZ');sub=n.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=.5;ab=n.new('ShaderNodeMath');ab.operation='ABSOLUTE';edge=n.new('ShaderNodeMapRange');edge.inputs['From Min'].default_value=0;edge.inputs['From Max'].default_value=.5;edge.inputs['To Min'].default_value=1;edge.inputs['To Max'].default_value=0;edge.clamp=True;fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.05;fade.inputs['From Max'].default_value=.4;fade.inputs['To Min'].default_value=0;fade.inputs['To Max'].default_value=1;fade.clamp=True;mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';mul2=n.new('ShaderNodeMath');mul2.operation='MULTIPLY';b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.18;b.inputs['Distance'].default_value=.025
  for a,bb in [(tc.outputs['UV'],mp.inputs[0]),(mp.outputs[0],tex.inputs[0]),(tex.outputs['Fac'],r.inputs[0]),(tc.outputs['UV'],sep.inputs[0]),(sep.outputs['X'],sub.inputs[0]),(sub.outputs[0],ab.inputs[0]),(ab.outputs[0],edge.inputs[0]),(sep.outputs['Y'],fade.inputs[0]),(edge.outputs[0],mul.inputs[0]),(fade.outputs[0],mul.inputs[1]),(mul.outputs[0],mul2.inputs[0]),(r.outputs[0],mul2.inputs[1]),(mul2.outputs[0],p.inputs['Alpha']),(tex.outputs['Fac'],b.inputs['Height']),(b.outputs[0],p.inputs['Normal'])]:l.new(a,bb)
  if hasattr(water,'surface_render_method'):water.surface_render_method='DITHERED'
 foam=_material('Waterfall v4 | fine aerated threads',(.55,.74,.83),.24)
 p=foam.node_tree.nodes.get('Principled BSDF');p.inputs['Alpha'].default_value=.65;p.inputs['Transmission Weight'].default_value=.16;p.inputs['IOR'].default_value=1.333
 return rock,strata,moss,water,foam

def _mesh(name,verts,faces,mats,mi=None,smooth=False):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update()
 for m in mats:me.materials.append(m)
 ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob)
 for i,p in enumerate(me.polygons):p.use_smooth=smooth;p.material_index=mi[i] if mi else 0
 return ob

def _tube_append(verts,faces,points,radii,sides=5):
 base=len(verts)
 for j,p in enumerate(points):
  tan=Vector(points[min(j+1,len(points)-1)])-Vector(points[max(0,j-1)]);tan.normalize();u=tan.cross(Vector((0,0,1)))
  if u.length<.01:u=tan.cross(Vector((1,0,0)))
  u.normalize();v=tan.cross(u).normalized()
  for k in range(sides):verts.append(Vector(p)+radii[j]*(u*cos(2*pi*k/sides)+v*sin(2*pi*k/sides)))
 for j in range(len(points)-1):
  for k in range(sides):a=base+j*sides+k;b=base+j*sides+(k+1)%sides;faces.append((a,b,b+sides,a+sides))

def build_island(name,center=(0,0,0),radius=(10,8),depth=8,seed=1,waterfalls=True):
 rng=random.Random(seed);cx,cy,cz=center;rx,ry=radius;rock,strata,moss,water,foam=_materials();verts=[];faces=[];mi=[];nr=192;nl=65
 phases=[rng.random()*6.28 for i in range(6)]
 def contour(a):return 1+.09*sin(3*a+phases[0])+.055*sin(7*a+phases[1])+.035*sin(13*a+phases[2])+.018*sin(29*a+phases[3])
 def radial(a,t):
  coarse=noise.noise_vector(Vector((cos(a)*3.2,sin(a)*3.2,t*2.3+seed)))[0]
  fissure=abs(sin(31*a+.35*sin(t*8+phases[3])))**12
  strataform=.012*sin(t*depth*4+sin(a*6))+.008*sin(t*depth*13+a*3)
  return contour(a)*(1-.12*t-.38*t*t)+.047*coarse-.032*fissure+strataform
 for j in range(nl):
  t=j/(nl-1);offx=.09*rx*sin(t*3+phases[4])*t;offy=.1*ry*sin(t*2+phases[5])*t
  for i in range(nr):
   a=2*pi*i/nr;r=radial(a,t);x=cx+rx*r*cos(a)+offx;y=cy+ry*r*sin(a)+offy;z=cz-depth*t
   n=noise.noise_vector(Vector((x*1.3,y*1.3,z*2.0)))
   amp=.10*sin(pi*min(1,t*8))+.065
   if j==0:amp=.025
   verts.append((x+n[0]*amp,y+n[1]*amp,z+n[2]*amp))
 for j in range(nl-1):
  for i in range(nr):a=j*nr+i;b=j*nr+(i+1)%nr;faces.append((a,a+nr,b+nr,b));mi.append(0)
 # Concentric plateau rings eliminate huge visible fan facets and color wedges.
 previous=list(range(nr))
 for ring in range(1,14):
  f=1-ring/14;ids=[]
  for i in range(nr):
   a=2*pi*i/nr;r=contour(a)*f;x=cx+rx*r*cos(a);y=cy+ry*r*sin(a);z=cz+.11*noise.noise_vector(Vector((x*.7,y*.7,seed)))[2]*f
   ids.append(len(verts));verts.append((x,y,z))
  for i in range(nr):k=(i+1)%nr;faces.append((previous[i],previous[k],ids[k],ids[i]));mi.append(2)
  previous=ids
 top=len(verts);verts.append((cx,cy,cz))
 for i in range(nr):faces.append((top,previous[i],previous[(i+1)%nr]));mi.append(2)
 # Dense underside bowl, ending in a craggy central hanging root instead of giant triangles.
 previous=[(nl-1)*nr+i for i in range(nr)]
 for ring in range(1,12):
  f=1-ring/12;ids=[]
  for i in range(nr):
   a=2*pi*i/nr;r=(.46*f)*contour(a);x=cx+rx*r*cos(a)-.1*rx;y=cy+ry*r*sin(a)+.03*ry;z=cz-depth*(1+.19*(1-f))+.14*noise.noise_vector(Vector((x,y,seed)))[0];ids.append(len(verts));verts.append((x,y,z))
  for i in range(nr):k=(i+1)%nr;faces.append((previous[i],ids[i],ids[k],previous[k]));mi.append(0)
  previous=ids
 bot=len(verts);verts.append((cx-.1*rx,cy+.03*ry,cz-depth*1.22))
 for i in range(nr):faces.append((bot,previous[(i+1)%nr],previous[i]));mi.append(0)
 ob=_mesh(name+' | finely eroded layered plateau',verts,faces,[rock,strata,moss],mi,smooth=True)
 # Narrow weathered fracture columns; 18 rings avoid low-poly cut faces.
 vv=[];ff=[]
 for q in range(48):
  a=2*pi*q/48+rng.uniform(-.035,.035);c=contour(a);start=Vector((cx+rx*c*.97*cos(a),cy+ry*c*.97*sin(a),cz-.18));h=depth*rng.uniform(.45,.98);rad=rng.uniform(.12,.36)*min(rx,ry)/8;pts=[];rr=[]
  for j in range(18):
   t=j/17;tt=h*t/depth;ra=radial(a,tt);offx=.09*rx*sin(tt*3+phases[4])*tt;offy=.1*ry*sin(tt*2+phases[5])*tt;pts.append(Vector((cx+rx*ra*cos(a)+offx+cos(a)*.05,cy+ry*ra*sin(a)+offy+sin(a)*.05,cz-h*t)));rr.append(rad*(1-.55*t)*(1+.19*sin(j*2.4+q)))
  _tube_append(vv,ff,pts,rr,9)
 _mesh(name+' | narrow erosion buttresses',vv,ff,[rock],smooth=True)
 # Dense tiny fractured mossy rim stones, not large flat material fans.
 vv=[];ff=[];mm=[]
 for q in range(160):
  a=rng.uniform(0,2*pi);r=rng.uniform(.45,.99);x=cx+rx*r*cos(a);y=cy+ry*r*sin(a);z=cz+rng.uniform(.015,.12);sz=rng.uniform(.06,.24);base=len(vv)
  for j in range(7):ang=2*pi*j/7;vv.append((x+cos(ang)*sz*(1+rng.uniform(-.2,.2)),y+sin(ang)*sz,z+rng.uniform(-.02,.04)))
  vv.append((x,y,z+sz*.5))
  for j in range(7):ff.append((base+j,base+(j+1)%7,base+7));mm.append(1 if q%4 else 0)
 _mesh(name+' | weathered moss scree',vv,ff,[rock,moss],mm,smooth=True)
 if waterfalls:
  vv=[];ff=[];uv=[];sv=[];sf=[]
  groups=[(-.82,.13),(-.48,.16),(-.08,.17),(.29,.14),(.65,.14),(.85,.08)]
  mist=_mist_material()
  for gi,(u,span) in enumerate(groups):
   uu=u+span*.5;ga=-math.acos(max(-.99,min(.99,uu)));gc=contour(ga);gx=cx+rx*gc*cos(ga);gy=cy+ry*gc*sin(ga);gh=depth*rng.uniform(.7,1.05)
   # Each group is mostly thin falling filaments, plus one subtle corrugated sheet.
   for q in range(2):
    xx=u+span*(q+.5)/2;ang=-math.acos(max(-.99,min(.99,xx)));c=contour(ang);x=cx+rx*c*cos(ang);y=cy+ry*c*sin(ang);h=gh*rng.uniform(.88,1.08);width=rx*span*.42;phase=rng.uniform(0,6.28);base=len(vv);nw=7;nh=48
    for j in range(nh):
     t=j/(nh-1);dx=.035*sin(13*t+phase)+.018*sin(43*t);yy=y-.22*t-.8*t*t;ww=width*(.8+.15*sin(t*12+phase))*(1-.25*t)
     for k in range(nw):
      w=k/(nw-1);xx2=x+dx+(w-.5)*ww;yy2=yy+.045*sin(w*18+t*27+phase);vv.append((xx2,yy2,cz-.04-h*t));uv.append((w,1-t))
    for j in range(nh-1):
     for k in range(nw-1):a=base+j*nw+k;ff.append((a,a+1,a+1+nw,a+nw))
   for q in range(36):
    xx=u+span*rng.random();ang=-math.acos(max(-.99,min(.99,xx)));c=contour(ang);x=cx+rx*c*cos(ang);y=cy+ry*c*sin(ang)-.05;h=gh*rng.uniform(.8,1.2);phase=rng.uniform(0,6.28);rad=rng.uniform(.012,.032)*rx/12
    # Staggered start/end avoids a uniform curtain hem.
    t0=0 if q%3 else rng.uniform(.1,.4);t1=rng.uniform(.72,1);pts=[];rr=[]
    for j in range(32):
     t=t0+(t1-t0)*j/31;pts.append((x+.035*sin(t*15+phase)+.012*sin(t*47),y-.22*t-.8*t*t+.02*cos(t*18+phase),cz-h*t));rr.append(rad*(.55+.45*sin(pi*j/31))*(1-.6*t))
    _tube_append(sv,sf,pts,rr,5)
   bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2,radius=1,location=(gx,gy-.8,cz-gh));mo=bpy.context.object;mo.name=name+' | waterfall foot spray %02d'%gi;mo.scale=(max(1,rx*span),1.35,.85);mo.data.materials.append(mist)
  wo=_mesh(name+' | translucent corrugated fall veils',vv,ff,[water],smooth=True);layer=wo.data.uv_layers.new(name='Flow UV')
  for poly in wo.data.polygons:
   for li in poly.loop_indices:layer.data[li].uv=uv[wo.data.loops[li].vertex_index]
  _mesh(name+' | fine tapered falling filaments',sv,sf,[foam],smooth=True)
 return ob

def _mist_material():
 m=bpy.data.materials.get('Waterfall | fine suspended foot mist')
 if m:return m
 m=bpy.data.materials.new('Waterfall | fine suspended foot mist');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;o=n.new('ShaderNodeOutputMaterial');v=n.new('ShaderNodeVolumePrincipled');v.inputs['Color'].default_value=(.92,.97,1,1);v.inputs['Anisotropy'].default_value=.2;tc=n.new('ShaderNodeTexCoord');dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,.5);fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.1;fade.inputs['From Max'].default_value=.53;fade.inputs['To Min'].default_value=.09;fade.inputs['To Max'].default_value=0;fade.clamp=True;tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=5;tex.inputs['Detail'].default_value=3;mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
 for a,b in [(tc.outputs['Generated'],dist.inputs[0]),(dist.outputs['Value'],fade.inputs[0]),(tc.outputs['Generated'],tex.inputs[0]),(fade.outputs[0],mul.inputs[0]),(tex.outputs[0],mul.inputs[1]),(mul.outputs[0],v.inputs['Density']),(v.outputs[0],o.inputs['Volume'])]:l.new(a,b)
 return m

def _cloud_material(name='Cloud | eroded fractal scattering v3',density=.65):
 m=bpy.data.materials.get(name)
 if m:return m
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;out=n.new('ShaderNodeOutputMaterial');vol=n.new('ShaderNodeVolumePrincipled');vol.inputs['Color'].default_value=(.995,.997,1,1);vol.inputs['Anisotropy'].default_value=.25
 tc=n.new('ShaderNodeTexCoord');no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=1.65;no.inputs['Detail'].default_value=5;no.inputs['Roughness'].default_value=.78;no.inputs['Distortion'].default_value=.28
 detail=n.new('ShaderNodeTexNoise');detail.inputs['Scale'].default_value=5.8;detail.inputs['Detail'].default_value=3;detail.inputs['Roughness'].default_value=.8
 r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.48;r.color_ramp.elements[0].color=(0,0,0,1);r.color_ramp.elements[1].position=.64;r.color_ramp.elements[1].color=(5,5,5,1)
 rd=n.new('ShaderNodeMapRange');rd.inputs['From Min'].default_value=.25;rd.inputs['From Max'].default_value=.7;rd.inputs['To Min'].default_value=0;rd.inputs['To Max'].default_value=1.2;rd.clamp=True
 dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,.5);fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.28;fade.inputs['From Max'].default_value=.6;fade.inputs['To Min'].default_value=1;fade.inputs['To Max'].default_value=0;fade.clamp=True
 mult=n.new('ShaderNodeMath');mult.operation='MULTIPLY';mult2=n.new('ShaderNodeMath');mult2.operation='MULTIPLY'
 for aa,bb in [(tc.outputs['Object'],no.inputs[0]),(tc.outputs['Object'],detail.inputs[0]),(no.outputs['Fac'],r.inputs[0]),(detail.outputs['Fac'],rd.inputs[0]),(tc.outputs['Generated'],dist.inputs[0]),(dist.outputs['Value'],fade.inputs[0]),(r.outputs[0],mult.inputs[0]),(rd.outputs[0],mult.inputs[1]),(mult.outputs[0],mult2.inputs[0]),(fade.outputs[0],mult2.inputs[1]),(mult2.outputs[0],vol.inputs['Density']),(vol.outputs[0],out.inputs['Volume'])]:l.new(aa,bb)
 return m

def _cloud_group(name,center,scale,rng,material,lobes=10):
 # Metaball union creates actual connected lumpy bounds, then shader scatters inside.
 mb=bpy.data.metaballs.new(name+' bounds');mb.resolution=.38;mb.render_resolution=.38;mb.threshold=.7;ob=bpy.data.objects.new(name,mb);bpy.context.collection.objects.link(ob);ob.location=center
 for i in range(lobes*3):
  el=mb.elements.new();el.type='BALL';el.co=(rng.uniform(-3.5,3.5),rng.uniform(-2.7,2.7),rng.uniform(-.7,1.5));el.radius=rng.uniform(1.0,1.7);el.stiffness=2
 bpy.ops.object.select_all(action='DESELECT');bpy.context.view_layer.objects.active=ob;ob.select_set(True);bpy.ops.object.convert(target='MESH');ob=bpy.context.object;ob.name=name;ob.scale=scale;ob.data.materials.append(material)
 for ve in ob.data.vertices:
  p=ve.co.copy();f=.55*noise.noise_vector(p*1.8)[0]+.16*noise.noise_vector(p*5.3)[1];ve.co+=ve.normal*f
 for p in ob.data.polygons:p.use_smooth=True
 ob.select_set(False);return ob

def build_cloudsea(seed=5):
 rng=random.Random(seed);ma=_cloud_material();obs=[]
 # Lateral pockets leave a readable central bridge/island corridor. All crowns stay below z~4.
 groups=[(-34,10,-4,(2.5,2,1.15)),(30,13,-5,(2.8,2.1,1.2)),(-22,28,-5,(2.8,2.5,1.25)),(-6,24,-6,(2.8,2.2,1.15)),(20,25,-6,(2.8,2.4,1.1)),(38,35,-4,(3,2.5,1.45)),(-38,42,-4,(3.2,2.5,1.4)),(-14,45,-5,(3.4,2.7,1.35)),(10,49,-5,(3.5,2.7,1.3)),(32,60,-4,(3.5,3,1.5)),(-34,65,-5,(3.5,3,1.5)),(-6,72,-5,(4,3.5,1.5)),(18,84,-5,(4,3.5,1.5)),(-26,96,-5,(4.5,3.5,1.5)),(0,115,-5,(5,4,1.7)),(38,105,-4,(4.5,4,1.7))]
 groups.extend([(-23,8,-7,(2.5,2,1.15)),(-6,12,-8,(2.7,2.2,1.15)),(13,12,-8,(2.7,2.2,1.15)),(-29,22,-5,(2.8,2.3,1.2)),(-13,30,-5,(2.7,2.3,1.2)),(6,34,-5,(2.7,2.4,1.2)),(25,39,-5,(2.7,2.3,1.2)),(-44,30,-5,(3,2.5,1.2)),(45,26,-5,(3,2.5,1.2))])
 for i,(x,y,z,sc) in enumerate(groups):obs.append(_cloud_group('Cloud sea | billow %02d'%i,(x,y,z+(0 if y<20 else 7)),sc,rng,ma,12))
 # Tall cumulus at distant sides, behind architecture and clear of moon-gate interior
 for i,(x,y,z,sc) in enumerate([(-52,95,8,(4,3,3.5)),(53,105,12,(4,3,4.5)),(-57,135,16,(5,4,5)),(64,142,18,(5,4,5))]):obs.append(_cloud_group('Cloud horizon | cumulus %02d'%i,(x,y,z),sc,rng,ma,14))
 # Prominent scalloped cloud canyon banks, visible above cliff bases.
 for i,(x,y,z,sc) in enumerate([(-18,17,5,(3.2,2.5,1.7)),(-3,24,4,(3.5,2.6,1.8)),(28,24,5,(3.0,2.5,1.65)),(2,48,7,(4.0,3.0,2.0)),(-20,60,11,(4.0,3.2,2.4)),(25,65,10,(4.2,3.2,2.5)),(-8,85,9,(5.0,3.6,2.3)),(22,94,12,(4.5,3.6,2.6)),(-30,83,19,(4.5,3.3,3.3)),(39,105,21,(4.3,3.5,4.0))]):
  obs.append(_cloud_group('Cloud canyon | luminous bank %02d'%i,(x,y,z),sc,rng,ma,14))
 return obs
