"""云阙 V2: actual geometry, staged cinematic reconstruction."""
import bpy, math, random, os, sys, json
from mathutils import Vector, Matrix
from math import sin,cos,pi
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
random.seed(38)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for d in list(bpy.data.materials):bpy.data.materials.remove(d)
def material(name,color,metal=0,rough=.5,emission=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 if emission:p.inputs['Emission Color'].default_value=(*color,1);p.inputs['Emission Strength'].default_value=emission
 return m
bronze=material('Court • aged gilded bronze',(.43,.24,.07),.8,.28)
black=material('Court • black lacquer',(.022,.034,.035),.35,.28)
stone=material('Court • blue grey carved stone',(.12,.16,.19),.12,.48)
marble=material('Court • wet blue marble',(.065,.12,.17),.45,.12)
ivory=material('Court • scholar ivory silk',(.67,.65,.58),0,.52)
paper=material('Court • amber silk lanterns',(.92,.42,.08),0,.5,3)
hair=material('Court • hair',(.012,.014,.018),0,.5)
# rich marble veining and irregular polished surface
n=marble.node_tree.nodes;p=n.get('Principled BSDF');noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=3;noise.inputs['Detail'].default_value=5;noise.inputs['Roughness'].default_value=.8;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.33;r.color_ramp.elements[0].color=(.025,.05,.085,1);r.color_ramp.elements[1].position=.65;r.color_ramp.elements[1].color=(.18,.27,.34,1);marble.node_tree.links.new(noise.outputs['Fac'],r.inputs[0]);marble.node_tree.links.new(r.outputs[0],p.inputs['Base Color']);b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.16;b.inputs['Distance'].default_value=.025;marble.node_tree.links.new(noise.outputs['Fac'],b.inputs['Height']);marble.node_tree.links.new(b.outputs[0],p.inputs['Normal'])
for m in [bronze,stone,black]:
 n=m.node_tree.nodes;no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=22;no.inputs['Detail'].default_value=3;bu=n.new('ShaderNodeBump');bu.inputs['Strength'].default_value=.23;bu.inputs['Distance'].default_value=.035;m.node_tree.links.new(no.outputs['Fac'],bu.inputs[0]);m.node_tree.links.new(bu.outputs[0],n.get('Principled BSDF').inputs['Normal'])
class MeshBatch:
 def __init__(self,name):self.name=name;self.items={}
 def add(self,vs,fs,ma):
  v,f=self.items.setdefault(ma.name,([],[]));o=len(v);v.extend(vs);f.extend([tuple(o+i for i in face) for face in fs])
 def box(self,c,s,ma):
  x,y,z=c;a,b,d=[i/2 for i in s];vs=[(x+u*a,y+v*b,z+w*d) for u,v,w in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]];self.add(vs,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],ma)
 def tube(self,pts,rad,ma,n=7):
  vs=[];fs=[]
  for i,p in enumerate(pts):
   p=Vector(p);d=Vector(pts[min(i+1,len(pts)-1)])-Vector(pts[max(i-1,0)]);d.normalize();a=d.cross(Vector((0,0,1)))
   if a.length<.01:a=d.cross(Vector((0,1,0)))
   a.normalize();b=d.cross(a).normalized();rr=rad[i] if isinstance(rad,list) else rad
   for j in range(n):vs.append(tuple(p+rr*(a*cos(2*pi*j/n)+b*sin(2*pi*j/n))))
  for i in range(len(pts)-1):
   for j in range(n):a=i*n+j;bb=i*n+(j+1)%n;fs.append((a,bb,bb+n,a+n))
  self.add(vs,fs,ma)
 def finish(self):
  for name,(v,f) in self.items.items():
   me=bpy.data.meshes.new(self.name+' '+name);me.from_pydata(v,[],f);me.materials.append(bpy.data.materials[name]);ob=bpy.data.objects.new(self.name+' '+name,me);bpy.context.collection.objects.link(ob)
  self.items={}
B=MeshBatch('Moon gate / terraces / bridge')
def circle(center,r,ma=bronze,thick=.04,plane='xy',steps=80):
 x,y,z=center
 pts=[(x+r*cos(2*pi*i/steps),y+r*sin(2*pi*i/steps),z) if plane=='xy' else (x+r*cos(2*pi*i/steps),y,z+r*sin(2*pi*i/steps)) for i in range(steps+1)];B.tube(pts,thick,ma)
def flourish(center,width=1,height=.6,plane='xz',ma=bronze):
 x,y,z=center
 for side in [-1,1]:
  pts=[]
  for i in range(25):
   a=i/24*2.5*pi;rr=(1-i/30)*width*.26;xx=side*(width*.2+rr*cos(a));zz=rr*sin(a)*height/width*2
   pts.append((x+xx,y,z+zz) if plane=='xz' else (x+xx,y+zz,z))
  B.tube(pts,.025,ma,5)
# irregular terrace wedge elevated above cloud canyon
poly=[(-55,-48,7.3),(48,-48,7.3),(35,-47,7.3),(-30,5,7.3),(-55,5,7.3)]
vs=poly+[(x,y,z+.65) for x,y,z in poly];fs=[(5,6,7,8,9),(4,3,2,1,0)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)];B.add(vs,fs,stone)
# marble surface with clipped hex quad floor, seam lines as embedded bronze
B.add([(x,y,8) for x,y,z in poly],[(0,1,2,3,4)],marble)
for x in range(-48,43,3):B.tube([(x,-47,8.012),(x,-26,8.012)],.012,bronze,4)
for y in range(-45,-23,3):B.tube([(-49,y,8.014),(40,y,8.014)],.012,bronze,4)
# ornamental ground medallion at foreground left
for rr in [5.8,6,6.25,7.1,7.25,8.9,9.1,10.0]:circle((-16,-24,8.025),rr,bronze,.032)
for i in range(32):
 a=2*pi*i/32;x=-16+7.7*cos(a);y=-24+7.7*sin(a);circle((x,y,8.03),.43,bronze,.022,steps=22)
for i in range(16):
 a=2*pi*i/16;pts=[]
 for k in range(30):
  t=k/29*2*pi;rr=2.4+1.3*cos(t);pts.append((-16+rr*cos(a)+1.1*sin(t)*cos(a+pi/2),-24+rr*sin(a)+1.1*sin(t)*sin(a+pi/2),8.035))
 B.tube(pts,.028,bronze)
def railing(path,zoff=0,height=1.2,detail=True):
 for dz in [.15,.4,height]:B.tube([(x,y,z+zoff+dz) for x,y,z in path],.07 if dz==height else .045,bronze)
 for i,p in enumerate(path):
  x,y,z=p;z+=zoff
  B.box((x,y,z+height*.5),(.19,.19,height+.05),stone);B.box((x,y,z+height+.08),(.29,.29,.18),bronze)
  if i%2==0:B.box((x,y,z+height+.26),(.18,.18,.2),bronze)
  if detail and i<len(path)-1:
   q=path[i+1];cx=(x+q[0])/2;cy=(y+q[1])/2;cz=(z+q[2]+zoff)/2+height*.56
   # decorative rail panels parallel front, dark insets with scroll metalwork
   dx=q[0]-x;dy=q[1]-y;ln=math.hypot(dx,dy)
   if abs(dx)>abs(dy):B.box((cx,cy,cz),(ln*.72,.09,.44),black);flourish((cx,cy-.07,cz),ln*.65,.36)
# terrace boundary diagonal from left behind figure to near right
p0=Vector((-30,5,8));p1=Vector((35,-47,8));railpath=[tuple(p0.lerp(p1,i/45)) for i in range(46)];railing(railpath,height=1.35,detail=False)
# detailed bridge across cloud canyon
pts=[];vs=[];fs=[]
for i in range(81):
 t=i/80;x=-34+42*t;y=15+9*t;z=9+2.6*sin(pi*t);pts.append((x,y,z))
 for dy,dz in [(-1.8,0),(1.8,0),(-1.8,-.45),(1.8,-.45)]:vs.append((x,y+dy,z+dz))
for i in range(80):
 a=i*4;fs.extend([(a,a+4,a+5,a+1),(a+2,a+3,a+7,a+6),(a,a+2,a+6,a+4),(a+1,a+5,a+7,a+3)])
B.add(vs,fs,stone)
for side in [-1,1]:
 rail=[(x,y+side*1.8,z) for x,y,z in pts[::2]];railing(rail,height=1.1)
 # actual deep arch rib, golden inset ornamental underbridge
 rib=[(x,y+side*1.65,z-1.05-4.0*(1-sin(pi*i/80))) for i,(x,y,z) in enumerate(pts)];B.tube(rib,.29,stone);B.tube([(x,y-.05,z+.15) for x,y,z in rib],.06,bronze)
 for i in range(0,81,5):
  x,y,z=pts[i];under=rib[i][2];B.tube([(x,y+side*1.68,under),(x,y+side*1.68,z-.35)],.06,bronze)
  if i%10==0:flourish((x,y+side*1.83,(z+under)/2),1.4,1.0)
# secondary distant arched bridge, less ornate
for ybase,x0,x1,zbase in [(58,-42,-15,14)]:
 for dy in [-1,1]:
  p=[(x0+(x1-x0)*i/40,ybase+dy,zbase+3*sin(pi*i/40)) for i in range(41)];B.tube(p,.25,stone);railing(p[::2],height=.7,detail=False)
# dimensional architectural moon ring: paired thick radial stone arch with gilded segments
cx,cy,cz=10,47,22.5;r=23
for yy in [cy-1.2,cy+1.2]:
 vs=[];fs=[]
 for i in range(257):
  a=2*pi*i/256
  for rr in [r-.55,r+.55]:
   for y in [yy-.18,yy+.18]:vs.append((cx+rr*cos(a),y,cz+rr*sin(a)))
 for i in range(256):
  k=i*4;fs.extend([(k,k+4,k+5,k+1),(k+2,k+3,k+7,k+6),(k,k+2,k+6,k+4),(k+1,k+5,k+7,k+3)])
 B.add(vs,fs,stone)
 for rr in [r-.64,r-.4,r+.4,r+.64]:circle((cx,yy-.23,cz),rr,bronze,.065,'xz',240)
for i in range(160):
 a=2*pi*i/160
 for yy in [cy-1.45,cy+1.0]:
  B.tube([(cx+(r-.4)*cos(a),yy,cz+(r-.4)*sin(a)),(cx+(r+.4)*cos(a),yy,cz+(r+.4)*sin(a))],.05,bronze)
 if i%2==0:B.tube([(cx+r*cos(a),cy-1.1,cz+r*sin(a)),(cx+r*cos(a),cy+1.1,cz+r*sin(a))],.09,black)
# Connected multilevel gallery ceiling with inset coffers and carved transverse beams
for row,y in enumerate([36,49,62,75,88]):
 z=43+row*.32
 B.box((-34,y,z),(40,.9,1.4),black)
 B.box((45,y,z),(22,.9,1.4),black)
 B.box((-34,y-.48,z-.45),(40,.12,.09),bronze)
 B.box((45,y-.48,z-.45),(22,.12,.09),bronze)
 for x in range(-53,56,12):
  # central sky opening follows the moon portal rather than a checkerboard
  if not (abs(x-10)<18 and y<63):
   B.box((x,y+6,z+.6),(12,12.4,.5),black)
   for dx in [-5.4,5.4]:B.box((x+dx,y+6,z+.28),(.12,10.8,.1),bronze)
   for dy in [.6,11.4]:B.box((x,y+dy,z+.28),(10.8,.12,.1),bronze)
   for j in range(4):
    B.box((x,y,z-.3-j*.35),(3.5-j*.5,.7,.22),black)
    B.box((x,y,z-.44-j*.35),(.7,3.5-j*.5,.18),bronze if j==3 else black)
  # upper open gallery rails and silhouette screens
  if row>1:
   B.box((x,y,z+3.5),(.25,.25,5),black)
   B.box((x,y,z+5.7),(12,.3,.3),bronze)
for x in [-53,-41,-29,-17,31,43,55]:
 B.box((x,62,43.1),(1,66,1.4),black)
 B.box((x-.52,62,42.8),(.1,66,.12),bronze)
 for y in [36,62,88]:
  if y==36 and abs(x)<38:continue
  if y==62 and x==-17:continue
  B.box((x,y,28),(.7,.7,30),black)
  for zz in [14,39,41]:B.box((x,y,zz),(1.25,1.25,.23),bronze)
B.finish()
# Modular scene assets built by focused geometry workers
from architecture import build_pavilion
from landscape_v4 import build_island,build_cloudsea
from hero_tree_v4 import build_tree
build_island('Hero island',(14,30,10),(14,10),14,11,True)
build_tree(root=(14,30,10),scale=1)
hero_parts=[o for o in bpy.data.objects if o.name.startswith('HERO')]
for k,(loc,sc) in enumerate([((-33,-16,8),.23),((35,-14,8),.22),((-25,46,23),.10),((25,33,10),.10),((19,4,-1),.12),((-31,28,13),.13)]):
 for original in hero_parts:
  ob=bpy.data.objects.new('Garden blossom tree %02d '%k+original.name,original.data);bpy.context.collection.objects.link(ob);ob.matrix_world=Matrix.Translation(Vector(loc)) @ Matrix.Scale(sc,4) @ Matrix.Translation(Vector((-14,-30,-10)))

placements=[('Near left palace',(-34,0,8),22,13,1,13.5),('Near right pavilion',(34,6,4.1),20,12,1,6),('Upper left hanging palace',(-35,48,23),13,10,2,4.2),('Mid left sanctuary',(-30,40,11),12,9,1,4.5),('Far left temple',(-21,82,12),13,10,3,4.2),('Right island temple',(34,43,10),13,9,2,4.2),('Far right sanctuary',(47,80,15),17,12,3,4.3),('Distant center shrine',(-3,112,6),11,9,3,4.2),('Far mountain shrine',(-50,110,21),13,10,2,4.2)]
for i,(name,pos,w,d,st,sh) in enumerate(placements):
 if i>=2:build_island(name+' cliff',pos,(w*.65,d*.75),random.uniform(8,15),40+i,True)
 build_pavilion(name,pos,w,d,st,sh,100+i)
# small pavilions on hero shoulder and cascading islands
for i,(x,y,z,sz) in enumerate([(3,23,10,4),(20,25,10,5),(19,4,-1,6),(31,20,2,7),(-36,66,9,7)]):
 if i>=2:build_island('Terraced hanging garden'+str(i),(x,y,z),(sz*.9,sz*.75),7,200+i,True)
 build_pavilion('Miniature pavilion '+str(i),(x,y,z),sz,sz*.8,1,sz*.35,210+i)
from overhead_galleries import build_overhead
build_overhead()
build_cloudsea(seed=77)
# Finer erosion in cloud density and forward scattering for sunset silver lining
cloudmat=bpy.data.materials.get('Cloud | turbulent scattering')
if cloudmat:
 for nn in cloudmat.node_tree.nodes:
  if nn.type=='VOLUME_PRINCIPLED':nn.inputs['Anisotropy'].default_value=.58
  if nn.type=='TEX_NOISE' and nn.inputs['Scale'].default_value<1:nn.inputs['Scale'].default_value=2.2;nn.inputs['Detail'].default_value=5;nn.inputs['Roughness'].default_value=.8
# fine scale landscaped shrubs: use small individual blossom branch meshes in foreground later
# realistic robed figure: folded radial cloth and trailing cape
skin=material('Court • warm skin',(.45,.26,.15),0,.6)
def uvball(name,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=12,radius=1,location=loc);ob=bpy.context.object;ob.name=name;ob.scale=scale;ob.data.materials.append(ma)
 for p in ob.data.polygons:p.use_smooth=True

def scholar(x,y,z,h=2.1,hero=False):
 b=MeshBatch('Scholar '+str(x));vs=[];fs=[];N=40;H=24
 for i in range(H):
  t=i/(H-1);zz=z+h*.79*t;rr=h*(.19*(1-t)+.075*t)
  for j in range(N):
   a=2*pi*j/N;fold=1+.07*cos(a*11+t*3)+.035*cos(a*19-t*5);vs.append((x+rr*fold*cos(a),y+rr*fold*sin(a),zz))
 for i in range(H-1):
  for j in range(N):a=i*N+j;bb=i*N+(j+1)%N;fs.append((a,bb,bb+N,a+N))
 b.add(vs,fs,ivory);b.tube([(x-h*.075,y,z+h*.73),(x-h*.23,y-.05,z+h*.65),(x-h*.27,y-.1,z+h*.56)],[h*.09,h*.085,h*.06],ivory,12);b.tube([(x+h*.075,y,z+h*.73),(x+h*.21,y+.05,z+h*.65)],[h*.09,h*.075],ivory,12)
 if hero:
  vs=[];fs=[]
  for i in range(35):
   t=i/34;xx=x-4.6*t;yy=y-1.8*t;zz=z+h*.74*(1-t)**1.7
   for j in range(11):
    u=j/10-.5;vs.append((xx+u*.2,yy+u*(.55+1.2*t),zz+.12*sin(u*8*pi+t*10)))
  for i in range(34):
   for j in range(10):a=i*11+j;fs.append((a,a+1,a+12,a+11))
  b.add(vs,fs,ivory)
 b.finish();uvball('Face',(x,y,z+h*.87),(h*.075,h*.065,h*.105),skin);uvball('Hair crown',(x,y+.02,z+h*.92),(h*.08,h*.07,h*.075),hair);uvball('Top knot',(x,y,z+h*1.015),(h*.045,h*.045,h*.06),hair)
scholar(-13.5,-10,8,3.1,True)
for x,y,z,h in [(-25,17,9,1.9),(-22,17.5,10,1.8),(-10,20,11,1.8),(-8,21,11.4,1.9),(-5,22,11.5,1.8),(17,29,10,1.7)]:scholar(x,y,z,h)
# foreground free-standing lanterns
B=MeshBatch('Court lanterns')
def lantern(x,y,z,size=1):
 B.box((x,y,z+size*.7),(size*.9,size*.9,size*1.4),paper)
 for dx in [-.5,.5]:
  for dy in [-.5,.5]:B.box((x+dx*size,y+dy*size,z+size*.7),(.07,.07,size*1.5),bronze)
 for dz in [0,1.4]:B.box((x,y,z+dz*size),(1.15*size,1.15*size,.12),black)
 for i in range(4):B.box((x,y,z+size*(1.45+i*.1)),(size*(1.35-i*.23),size*(1.35-i*.23),.1),bronze)
 for side in [-1,1]:
  for j in [-.25,0,.25]:B.box((x+j*size,y+side*.51*size,z+.7*size),(.035,.03,1.3*size),bronze)
for x,y,z,sz in [(-18,-20,8,1.5),(-25,0,8,1),(-4,-11,8,1),(18,-24,8,1),(-30,4,10,.7),(28,17,8,.7)]:lantern(x,y,z,sz)
B.finish()
# Dusk / golden rim daylight environment
world=bpy.data.worlds.new('Blue dusk over golden cloudsea');world.use_nodes=True;bpy.context.scene.world=world;n=world.node_tree.nodes;n.clear();o=n.new('ShaderNodeOutputWorld');b=n.new('ShaderNodeBackground');b.inputs['Strength'].default_value=1.0;tc=n.new('ShaderNodeTexCoord');sep=n.new('ShaderNodeSeparateXYZ');m=n.new('ShaderNodeMath');m.operation='MULTIPLY_ADD';m.inputs[1].default_value=-.5;m.inputs[2].default_value=.5;r=n.new('ShaderNodeValToRGB');cr=r.color_ramp;cr.elements.remove(cr.elements[1]);cr.elements[0].position=0;cr.elements[0].color=(.07,.11,.2,1)
for pos,col in [(.48,(.48,.3,.19,1)),(.51,(.8,.52,.27,1)),(.56,(.24,.36,.57,1)),(.67,(.09,.17,.3,1)),(1,(.035,.075,.16,1))]:cr.elements.new(pos).color=col
for a,bb in [(tc.outputs['Normal'],sep.inputs[0]),(sep.outputs[2],m.inputs[0]),(m.outputs[0],r.inputs[0]),(r.outputs[0],b.inputs[0]),(b.outputs[0],o.inputs[0])]:world.node_tree.links.new(a,bb)
# Distant horizontal cloud bands at the sunset horizon
nt=world.node_tree;nodes=nt.nodes;stretch=nodes.new('ShaderNodeVectorMath');stretch.operation='MULTIPLY';stretch.inputs[1].default_value=(4,4,50);cl=nodes.new('ShaderNodeTexNoise');cl.inputs['Scale'].default_value=1.4;cl.inputs['Detail'].default_value=4;cl.inputs['Roughness'].default_value=.7;cramp=nodes.new('ShaderNodeValToRGB');cramp.color_ramp.elements[0].position=.48;cramp.color_ramp.elements[1].position=.67;mask=nodes.new('ShaderNodeValToRGB');mask.color_ramp.elements[0].position=.47;mask.color_ramp.elements[0].color=(0,0,0,1);mask.color_ramp.elements[1].position=.51;mask.color_ramp.elements[1].color=(1,1,1,1);mask.color_ramp.elements.new(.59).color=(0,0,0,1);mul=nodes.new('ShaderNodeMath');mul.operation='MULTIPLY';mix=nodes.new('ShaderNodeMixRGB');mix.blend_type='MIX';mix.inputs[2].default_value=(1.15,.58,.23,1)
for aa,bb in [(tc.outputs['Normal'],stretch.inputs[0]),(stretch.outputs[0],cl.inputs[0]),(cl.outputs['Fac'],cramp.inputs[0]),(m.outputs[0],mask.inputs[0]),(mask.outputs[0],mul.inputs[0]),(cramp.outputs[0],mul.inputs[1]),(mul.outputs[0],mix.inputs[0]),(r.outputs[0],mix.inputs[1]),(mix.outputs[0],b.inputs[0])]:nt.links.new(aa,bb)
sunmat=material('Sun • luminous gold',(1,.49,.09),0,.3,8)
uvball('Sun at image .63 .40',(50,300,22),(3.4,3.4,3.4),sunmat)
def light(name,typ,loc,power,color,size,target):
 d=bpy.data.lights.new(name,typ);d.energy=power;d.color=color
 if typ=='AREA':d.shape='DISK';d.size=size
 ob=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler();return ob
su=light('Sunset directional light','SUN',(50,300,22),4.5,(1,.64,.33),0,(0,0,0));su.data.angle=.055
light('Soft blue sky dome','AREA',(-8,0,48),15000,(.4,.6,1),40,(5,25,15))
light('Warm cloud bounce','AREA',(20,4,7),6000,(1,.51,.2),18,(8,26,20))
light('Gentle frontal environment','AREA',(-10,-30,22),1800,(.55,.7,1),30,(10,20,16))
light('Golden reflected light on bark','AREA',(30,-5,28),7000,(1,.72,.43),15,(12,30,23))
light('Golden reflected light on wet stone','AREA',(0,15,30),1000,(1,.65,.32),20,(-8,-15,8))
from lighting_v5 import apply_lighting
apply_lighting()
# camera framed by measured target landmarks
bpy.ops.object.camera_add(location=(0,-55,18));cam=bpy.context.object;cam.name='CAMERA • target composition';cam.rotation_euler=(Vector((0,25,14))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=32;cam.data.clip_end=1000;cam.data.dof.use_dof=False;bpy.context.scene.camera=cam
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=96;scene.cycles.use_denoising=False;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.035;scene.cycles.max_bounces=8;scene.cycles.volume_bounces=4;scene.cycles.volume_step_rate=2
scene.render.resolution_x=1920;scene.render.resolution_y=1080;scene.render.resolution_percentage=50;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.2
scene.use_nodes=True;n=scene.node_tree.nodes;n.clear();rr=n.new('CompositorNodeRLayers');gl=n.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='HIGH';gl.threshold=2;gl.size=7;out=n.new('CompositorNodeComposite');scene.node_tree.links.new(rr.outputs['Image'],gl.inputs[0]);scene.node_tree.links.new(gl.outputs[0],out.inputs[0])
scene.render.filepath=os.path.join(ROOT,'preview_05.png');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2.blend'));
if os.environ.get('MEGASCENE_BUILD_ONLY') != '1': bpy.ops.render.render(write_still=True)
