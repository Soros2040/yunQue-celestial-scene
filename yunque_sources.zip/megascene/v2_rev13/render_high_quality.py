"""Render verified model at genuine fullHD/768 samples; no image-generation/postpaint."""
import bpy,os,sys,json,time,datetime
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT);s=bpy.context.scene
from remove_far_bridge import remove_unsupported_far_bridge
remove_unsupported_far_bridge()
s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=768;s.cycles.use_denoising=False;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.006
s.cycles.max_bounces=10;s.cycles.diffuse_bounces=4;s.cycles.glossy_bounces=4;s.cycles.transmission_bounces=8;s.cycles.transparent_max_bounces=8;s.cycles.volume_bounces=4;s.cycles.volume_step_rate=1.0;s.cycles.sample_clamp_indirect=3.0;s.cycles.blur_glossy=.5
s.render.resolution_x=1920;s.render.resolution_y=1080;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='16';s.render.image_settings.compression=15;s.render.filepath=os.path.join(ROOT,'云阙_V2_高清渲染.png')
s['Render quality']='1920x1080, Cycles CPU, up to768 adaptive samples, threshold0.006, true volume rendering, no denoiser.'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_可编辑.blend'),compress=True)
info={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resolution':[1920,1080],'samples':768,'adaptive_threshold':.006,'volume_step_rate':1.0,'denoise':False,'image_file':s.render.filepath,'status':'running'}
def write():
 with open(os.path.join(ROOT,'high_render_metrics.json'),'w') as f:json.dump(info,f,indent=2)
write();start=time.time();bpy.ops.render.render(write_still=True);info['render_seconds']=round(time.time()-start,2);info['status']='complete';info['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write()
print('HIGH_RENDER_COMPLETE',json.dumps(info),flush=True)
