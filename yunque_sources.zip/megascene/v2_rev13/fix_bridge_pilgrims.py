"""Candidate correction for pilgrims left at old height after bridge07 transform.
Does not execute on import; apply only to a new reviewed revision, never active tile base.
"""
import bpy,math
from mathutils import Vector,Matrix

def ray_ground(x,y,approx_z,objects):
 origin=Vector((x,y,approx_z+6));hits=[]
 for ob in objects:
  inv=ob.matrix_world.inverted();direction=(inv.to_3x3()@Vector((0,0,-1))).normalized()
  ok,co,normal,face=ob.ray_cast(inv@origin,direction)
  if ok:
   world=ob.matrix_world@co
   if world.z<=origin.z:hits.append((world.z,ob.name,tuple(normal)))
 if not hits:raise RuntimeError('No geometric surface under '+str((x,y,approx_z)))
 return max(hits,key=lambda q:q[0])

def floor_objects():
 return [o for o in bpy.data.objects if o.type=='MESH' and o.name.startswith('Moon gate / terraces / bridge') and any(m and m.name in ['Court • blue grey carved stone','Court • wet blue marble'] for m in o.data.materials)]

def fix_bridge_pilgrims(scale=.8):
 s=bpy.context.scene
 if s.get('Bridge pilgrim placement11 fixed'):raise RuntimeError('Bridge pilgrim correction already applied')
 originals=[(-25,17,9,1.9),(-22,17.5,10,1.8),(-10,20,11,1.8),(-8,21,11.4,1.9),(-5,22,11.5,1.8)]
 report=[]
 for x,y,z,h in originals:
  t=(x+34)/42;new=Vector((-34+(x+34)*.89,15+9*t,9+2.6*math.sin(math.pi*t)-2.15));old=Vector((x,y,z))
  ground=ray_ground(new.x,new.y,new.z,floor_objects());new.z=ground[0]
  parts=[o for o in bpy.data.objects if o.name.startswith('Scholar '+str(x)+' ')]
  parts.extend(o for o in bpy.data.objects if o.name.startswith(('Face','Hair crown','Top knot')) and abs(o.location.x-x)<.01 and abs(o.location.y-y)<.05 and z+h*.7<o.location.z<z+h*1.2)
  if len(parts)!=4:raise RuntimeError('Unexpected pilgrim components at '+str(x)+': '+str([o.name for o in parts]))
  transform=Matrix.Translation(new)@Matrix.Scale(scale,4)@Matrix.Translation(-old)
  for o in parts:o.matrix_world=transform@o.matrix_world
  feet=min((o.matrix_world@v.co).z for o in parts if o.name.startswith('Scholar ') for v in o.data.vertices)
  if abs(feet-new.z)>.001:raise RuntimeError('Pilgrim not planted on bridge')
  report.append({'old_root':tuple(old),'new_root':tuple(new),'height':h*scale,'objects':len(parts),'foot_z':feet,'deck_z':ground[0],'foot_gap':feet-ground[0],'deck_object':ground[1]})
 s['Bridge pilgrim placement11 fixed']=True
 print('BRIDGE_PILGRIMS_FIXED',report,flush=True)
 return report
