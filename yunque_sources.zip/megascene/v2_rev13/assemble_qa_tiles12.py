"""Exact pixel assembly of genuine linear Cycles tiles, then one full-frame compositor.
Run with the unchanged render-base blend: blender -b 云阙_V2_可编辑.blend --python assemble_tiles.py
No interpolation, generative filling, retouching, or denoising is performed.
"""
import bpy,os,json,time,numpy as np
ROOT=os.path.dirname(os.path.abspath(__file__));OUT=os.path.join(ROOT,'tiles_qa12');state=json.load(open(os.path.join(OUT,'progress.json')))
W,H=state['width'],state['height'];NX,NY=state['columns'],state['rows'];TW,TH=state['tile_width'],state['tile_height']
canvas=np.zeros((H,W,4),dtype=np.float32);coverage=np.zeros((H,W),dtype=np.uint8);t=time.time()
for row in range(NY):
 for col in range(NX):
  stem='tile_r%02d_c%02d'%(row,col);d=json.load(open(os.path.join(OUT,stem+'.done.json')))
  if d['scene_sha256']!=state['scene_sha256']:raise RuntimeError('Inconsistent scene hash')
  im=bpy.data.images.load(os.path.join(OUT,d['file']),check_existing=False)
  if tuple(im.size)!=(TW,TH):raise RuntimeError('Incorrect tile dimensions')
  a=np.empty(TW*TH*4,dtype=np.float32);im.pixels.foreach_get(a);bpy.data.images.remove(im)
  x,y=d['x'],d['y'];canvas[y:y+TH,x:x+TW]=a.reshape((TH,TW,4));coverage[y:y+TH,x:x+TW]+=1
if not np.all(coverage==1):raise RuntimeError('Missing or overlapping pixels')
full=bpy.data.images.new('HQ linear exact tile assembly',width=W,height=H,alpha=True,float_buffer=True);full.pixels.foreach_set(canvas.ravel());full.update()
s=bpy.context.scene;s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.use_border=False;s.render.use_crop_to_border=False
s.render.image_settings.file_format='OPEN_EXR';s.render.image_settings.color_mode='RGBA';s.render.image_settings.color_depth='32';s.render.image_settings.exr_codec='ZIP'
linear=os.path.join(ROOT,'云阙_V2_第12阶段_1440线性.exr');full.save_render(linear,scene=s)
# The image input replaces Render Layers; all512-sample rendered pixels are preserved.
s.use_nodes=True;nt=s.node_tree;nt.nodes.clear();inp=nt.nodes.new('CompositorNodeImage');inp.image=full;gl=nt.nodes.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='HIGH';gl.threshold=2;gl.size=7;out=nt.nodes.new('CompositorNodeComposite');nt.links.new(inp.outputs['Image'],gl.inputs[0]);nt.links.new(gl.outputs[0],out.inputs[0]);s.render.use_compositing=True;s.render.use_sequencer=False
s.cycles.samples=1;s.cycles.use_denoising=False;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='16';s.render.filepath=os.path.join(ROOT,'云阙_V2_第12阶段_1440检查渲染.png')
bpy.ops.render.render(write_still=True)
metrics={'status':'complete','method':'exact linear pixel assembly of actual Cycles crops; full-frame glare once','resolution':[W,H],'tiles':NX*NY,'samples_per_pixel':state['samples_per_pixel'],'denoise':False,'mesh_objects':sum(o.type=='MESH' for o in bpy.data.objects),'unique_mesh_vertices':sum(len(d.vertices) for d in {o.data for o in bpy.data.objects if o.type=='MESH'}),'all_pixels_covered_once':True,'source_scene_sha256':state['scene_sha256'],'assembly_seconds':round(time.time()-t,2),'linear_exr':linear,'png':s.render.filepath}
with open(os.path.join(ROOT,'qa_tiled_render_complete.json'),'w') as f:json.dump(metrics,f,indent=2)
state['status']='assembled';state['final_png']=s.render.filepath
with open(os.path.join(OUT,'progress.json'),'w') as f:json.dump(state,f,indent=2)
print('TILED_RENDER_COMPLETE',json.dumps(metrics),flush=True)
