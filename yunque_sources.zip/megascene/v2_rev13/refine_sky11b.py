"""HDR sky stratus in front of halo, so halo cannot wash out all cloud contrast."""
import bpy

def refine_sky():
 s=bpy.context.scene;n=s.world.node_tree.nodes;l=s.world.node_tree.links
 if n.get('World stratus coverage11b'):return
 halo=next(q for q in n if q.bl_idname=='ShaderNodeMixRGB' and q.blend_type=='ADD')
 cloud=halo.inputs[1].links[0].from_node
 if cloud.bl_idname!='ShaderNodeMixRGB':raise RuntimeError('Unexpected world graph')
 gradient=cloud.inputs[1].links[0].from_socket;factor=cloud.inputs[0].links[0].from_socket
 l.new(gradient,halo.inputs[1]);l.new(halo.outputs[0],cloud.inputs[1]);bg=next(q for q in n if q.type=='BACKGROUND');l.new(cloud.outputs[0],bg.inputs[0]);cloud.name='World stratus coverage11b'
 coverage=n.new('ShaderNodeMapRange');coverage.inputs['From Min'].default_value=0;coverage.inputs['From Max'].default_value=.68;coverage.inputs['To Min'].default_value=0;coverage.inputs['To Max'].default_value=1;coverage.clamp=True;l.new(factor,coverage.inputs[0]);l.new(coverage.outputs[0],cloud.inputs[0])
 colors=n.get('Broken blue stratus with golden upper lining')
 if colors:colors.inputs[1].default_value=(.13,.18,.26,1);colors.inputs[2].default_value=(2.0,.75,.15,1)
 for q in n:
  if q.type=='VALTORGB' and len(q.color_ramp.elements)>4:
   for e in q.color_ramp.elements:
    if abs(e.position-.48)<.002:e.color=(.40,.28,.16,1)
