"""Cloud-ocean continuity and near-court organic framing; apply once to08light."""
import bpy,os,sys
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
s=bpy.context.scene
bpy.data.lights['Golden sunset bounce'].energy=40000;bpy.data.lights['Golden sunset bounce'].size=8
from cloud_ocean_floor08 import build_cloud_ocean_floor
build_cloud_ocean_floor()
from cliff_rubble08 import build_cliff_rubble
build_cliff_rubble()
from foreground_garden08 import build_foreground_garden
build_foreground_garden()
s.cycles.samples=96;s.cycles.adaptive_threshold=.025;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_08.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_08.blend'))
if os.environ.get('MEGASCENE_BUILD_ONLY') != '1':bpy.ops.render.render(write_still=True)
