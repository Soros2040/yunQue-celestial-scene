def apply_lighting():
 import bpy,os,random,sys,math
 from mathutils import Vector
 ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
 from landscape_v3 import _cloud_group
 s=bpy.context.scene
 # Preserve an orange negative-space corridor around the sun; haze only flanks and low valley.
 m=bpy.data.materials.new('Atmosphere • masked depth');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;o=n.new('ShaderNodeOutputMaterial');v=n.new('ShaderNodeVolumePrincipled');v.inputs['Color'].default_value=(.55,.67,.81,1);v.inputs['Anisotropy'].default_value=.25
 co=n.new('ShaderNodeTexCoord');sep=n.new('ShaderNodeSeparateXYZ');sub=n.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=.583;ab=n.new('ShaderNodeMath');ab.operation='ABSOLUTE';sides=n.new('ShaderNodeMapRange');sides.inputs['From Min'].default_value=.067;sides.inputs['From Max'].default_value=.14;sides.inputs['To Min'].default_value=0;sides.inputs['To Max'].default_value=1;low=n.new('ShaderNodeMapRange');low.inputs['From Min'].default_value=.22;low.inputs['From Max'].default_value=.34;low.inputs['To Min'].default_value=1;low.inputs['To Max'].default_value=0;mx=n.new('ShaderNodeMath');mx.operation='MAXIMUM';mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';mul.inputs[1].default_value=.002
 for a,b in [(co.outputs['Generated'],sep.inputs[0]),(sep.outputs[0],sub.inputs[0]),(sub.outputs[0],ab.inputs[0]),(ab.outputs[0],sides.inputs[0]),(sep.outputs[2],low.inputs[0]),(sides.outputs[0],mx.inputs[0]),(low.outputs[0],mx.inputs[1]),(mx.outputs[0],mul.inputs[0]),(mul.outputs[0],v.inputs['Density']),(v.outputs[0],o.inputs['Volume'])]:l.new(a,b)
 bpy.ops.mesh.primitive_cube_add(size=1,location=(0,115,37));ob=bpy.context.object;ob.name='Atmospheric depth with clear sunset corridor';ob.scale=(230,150,95);ob.data.materials.append(m)
 cloud=bpy.data.materials['Cloud | eroded fractal scattering v3']
 for ob in bpy.data.objects:
  if ob.name.startswith('Cloud canyon | luminous bank 07'):ob.location.z-=3
  if ob.name.startswith('Cloud canyon | luminous bank 05'):ob.location.z-=1.5
  if ob.name.startswith('Cloud canyon | luminous bank 09'):ob.location.x+=8
 rng=random.Random(891);_cloud_group('Cloud • towering distant west',(-18,85,17),(3.5,3,6),rng,cloud,18);_cloud_group('Cloud • towering distant east',(49,90,23),(3.5,3.2,7),rng,cloud,18)
 # Warm broad grazing light from the sun opening, retain cool low frontal fill.
 d=bpy.data.lights.new('Golden sunset bounce','AREA');d.energy=23000;d.shape='DISK';d.size=10;d.color=(1,.42,.12);ob=bpy.data.objects.new('Golden sunset bounce',d);bpy.context.collection.objects.link(ob);ob.location=(18,85,22);ob.rotation_euler=(Vector((5,15,12))-ob.location).to_track_quat('-Z','Y').to_euler()
 for m in bpy.data.materials:
  if any(k in m.name.lower() for k in ['gold','gilt','bronze']):
   p=m.node_tree.nodes.get('Principled BSDF') if m.use_nodes else None
   if p:p.inputs['Metallic'].default_value=.94;p.inputs['Roughness'].default_value=max(.34,p.inputs['Roughness'].default_value)
 # directional broken warm reflected band, not an undirected gray area patch
 ld=bpy.data.lights['Golden reflected light on wet stone'];ld.energy=1800;ld.color=(1,.39,.09);ld.shape='RECTANGLE';ld.size=22;ld.size_y=.7
 m=bpy.data.materials['Court • wet blue marble'];n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');tc=n.new('ShaderNodeTexCoord');no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=27;no.inputs['Detail'].default_value=3;no.inputs['Roughness'].default_value=.7;r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.35;r.color_ramp.elements[0].color=(.05,.05,.05,1);r.color_ramp.elements[1].position=.68;r.color_ramp.elements[1].color=(.2,.2,.2,1);l.new(tc.outputs['Object'],no.inputs[0]);l.new(no.outputs[0],r.inputs[0]);l.new(r.outputs[0],p.inputs['Roughness']);bu=n.new('ShaderNodeBump');bu.inputs['Strength'].default_value=.2;bu.inputs['Distance'].default_value=.012;l.new(no.outputs[0],bu.inputs[0]);l.new(bu.outputs[0],p.inputs['Normal'])
 # HDR golden sunset opening, cool upper sky, broad halo around physical sun direction
 wn=s.world.node_tree.nodes;wl=s.world.node_tree.links
 for nn in wn:
  if nn.type=='VALTORGB' and len(nn.color_ramp.elements)>4:
   for ee in nn.color_ramp.elements:
    if abs(ee.position-.51)<.002:ee.color=(2.0,.55,.10,1)
    if abs(ee.position-.48)<.002:ee.color=(.7,.18,.045,1)
 bg=next(nn for nn in wn if nn.type=='BACKGROUND');prev=bg.inputs[0].links[0].from_socket;coord=next(nn for nn in wn if nn.type=='TEX_COORD');dot=wn.new('ShaderNodeVectorMath');dot.operation='DOT_PRODUCT';dot.inputs[1].default_value=(-.164,-.984,-.072);halo=wn.new('ShaderNodeMapRange');halo.inputs['From Min'].default_value=.945;halo.inputs['From Max'].default_value=1;halo.inputs['To Min'].default_value=0;halo.inputs['To Max'].default_value=1;halo.clamp=True;powr=wn.new('ShaderNodeMath');powr.operation='POWER';powr.inputs[1].default_value=3;mix=wn.new('ShaderNodeMixRGB');mix.blend_type='ADD';mix.inputs[2].default_value=(1.6,.5,.07,1)
 for aa,bb in [(coord.outputs['Normal'],dot.inputs[0]),(dot.outputs['Value'],halo.inputs[0]),(halo.outputs[0],powr.inputs[0]),(powr.outputs[0],mix.inputs[0]),(prev,mix.inputs[1]),(mix.outputs[0],bg.inputs[0])]:wl.new(aa,bb)
 bpy.data.lights['Golden reflected light on bark'].energy=2500
 bpy.data.lights['Warm cloud bounce'].energy=2000
