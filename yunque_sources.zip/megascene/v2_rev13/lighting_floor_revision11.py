"""Coherent cinematic atmosphere and genuinely inlaid wet-stone court revision."""
import bpy

def apply_lighting_floor_revision():
 s=bpy.context.scene
 # Remove long uniform volumetric line; replace with broken procedural HDR stratus.
 for o in list(bpy.data.objects):
  if o.name.startswith('Sunset horizon filament'):bpy.data.objects.remove(o,do_unlink=True)
 wn=s.world.node_tree.nodes;wl=s.world.node_tree.links
 bg=next(n for n in wn if n.type=='BACKGROUND');bg.inputs['Strength'].default_value=1.15
 for n in wn:
  if n.type=='VALTORGB' and len(n.color_ramp.elements)>4:
   for e in n.color_ramp.elements:
    if abs(e.position-.48)<.002:e.color=(.20,.27,.40,1)
    if abs(e.position-.56)<.002:e.color=(.32,.48,.78,1)
    if abs(e.position-.67)<.002:e.color=(.15,.25,.43,1)
    if abs(e.position-1)<.002:e.color=(.07,.13,.24,1)
  if n.bl_idname=='ShaderNodeVectorMath' and n.operation=='MULTIPLY' and n.inputs[1].default_value[2]>40:n.inputs[1].default_value=(9,9,110)
 # Existing stretched-noise cloud mask; complementary shifted noise defines warm upper lining.
 cloudmix=next(n for n in wn if n.bl_idname=='ShaderNodeMixRGB' and n.blend_type=='MIX')
 source=next(n for n in wn if n.type=='TEX_NOISE');source.inputs['Distortion'].default_value=.15
 vec=source.inputs['Vector'].links[0].from_socket;shift=wn.new('ShaderNodeVectorMath');shift.operation='ADD';shift.inputs[1].default_value=(0,0,.35);wl.new(vec,shift.inputs[0])
 n2=wn.new('ShaderNodeTexNoise');n2.inputs['Scale'].default_value=source.inputs['Scale'].default_value;n2.inputs['Detail'].default_value=4;n2.inputs['Roughness'].default_value=.7;n2.inputs['Distortion'].default_value=.15;wl.new(shift.outputs[0],n2.inputs['Vector'])
 dif=wn.new('ShaderNodeMath');dif.operation='SUBTRACT';wl.new(source.outputs['Fac'],dif.inputs[0]);wl.new(n2.outputs['Fac'],dif.inputs[1])
 edge=wn.new('ShaderNodeMapRange');edge.inputs['From Min'].default_value=-.015;edge.inputs['From Max'].default_value=.065;edge.inputs['To Min'].default_value=0;edge.inputs['To Max'].default_value=1;edge.clamp=True;wl.new(dif.outputs[0],edge.inputs[0])
 col=wn.new('ShaderNodeMixRGB');col.name='Broken blue stratus with golden upper lining';col.inputs[1].default_value=(.15,.21,.30,1);col.inputs[2].default_value=(1.4,.58,.11,1);wl.new(edge.outputs[0],col.inputs[0]);wl.new(col.outputs[0],cloudmix.inputs[2])
 # Tighten cloud coverage to streaks rather than an opaque horizon replacement.
 for n in wn:
  if n.type=='VALTORGB' and len(n.color_ramp.elements)==2 and abs(n.color_ramp.elements[0].position-.48)<.01:
   n.color_ramp.elements[0].position=.52;n.color_ramp.elements[1].position=.65
 # Atmospheric perspective applies behind the hero, with the existing clear-sun mask preserved.
 ma=bpy.data.materials.get('Atmosphere • masked depth')
 if ma:
  for n in ma.node_tree.nodes:
   if n.bl_idname=='ShaderNodeMath' and n.operation=='MULTIPLY' and abs(n.inputs[1].default_value-.002)<.0001:n.inputs[1].default_value=.0034
 for name,energy,size in [('Sunset directional light',3.5,None),('Soft blue sky dome',20000,None),('Bark warm grazing rim 07',6000,18)]:
  d=bpy.data.lights.get(name)
  if d:d.energy=energy
  if d and size:d.size=size
 # Wet stone: smooth clearcoat, broad subtle wetness variation, no granular normal glitter.
 m=bpy.data.materials['Court • wet blue marble'];n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Metallic'].default_value=.08;p.inputs['Coat Weight'].default_value=.72;p.inputs['Coat Roughness'].default_value=.095
 if p.inputs['Roughness'].is_linked:
  ramp=p.inputs['Roughness'].links[0].from_node
  if ramp.type=='VALTORGB':
   ramp.color_ramp.elements[0].color=(.105,.105,.105,1);ramp.color_ramp.elements[1].color=(.17,.17,.17,1)
   if ramp.inputs[0].is_linked:
    no=ramp.inputs[0].links[0].from_node
    if no.type=='TEX_NOISE':no.inputs['Scale'].default_value=5;no.inputs['Detail'].default_value=2;no.inputs['Roughness'].default_value=.6
 if p.inputs['Normal'].is_linked:
  b=p.inputs['Normal'].links[0].from_node
  if b.bl_idname=='ShaderNodeBump':b.inputs['Distance'].default_value=.0015;b.inputs['Strength'].default_value=.12
 count=0
 for o in bpy.data.objects:
  if o.type=='MESH' and o.name.startswith('Moon gate / terraces / bridge') and any(m and m.name=='Court • aged gilded bronze' for m in o.data.materials):
   for v in o.data.vertices:
    if v.co.y<6 and 7.92<v.co.z<8.1:v.co.z=8.0005+(v.co.z-8)*.025;count+=1
   o.data.update()
 print('REV11_FLOOR_INLAY_VERTICES',count,flush=True)
