"""Open the sunset corridor, reshape hero tree and detail the near rail."""
import bpy,os,sys
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
s=bpy.context.scene
# Lower distant cloud crowns only; the lower canyon cloud ocean stays continuous.
for name,dz in [('Cloud canyon | luminous bank 07',-4),('Cloud canyon | luminous bank 05',-2),('Cloud canyon | luminous bank 06',-2.5)]:
 o=next((q for q in bpy.data.objects if q.name.startswith(name)),None)
 if o:o.location.z+=dz
# Replace the hero only; preserve garden tree instances and their original linked meshes.
for o in list(bpy.data.objects):
 if o.name.startswith('HERO •'):
  data=o.data;typ=o.type;bpy.data.objects.remove(o,do_unlink=True)
  if data and data.users==0:
   if typ=='MESH':bpy.data.meshes.remove(data)
   elif typ=='CURVE':bpy.data.curves.remove(data)
from hero_tree_v7 import build_tree
build_tree(root=(14,30,10),scale=1)
from foreground_rail09 import build_foreground_rail
build_foreground_rail()
s.cycles.samples=96;s.cycles.adaptive_threshold=.025;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_09.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_09.blend'))
if os.environ.get('MEGASCENE_BUILD_ONLY') != '1':bpy.ops.render.render(write_still=True)
