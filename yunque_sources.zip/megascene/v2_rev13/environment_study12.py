"""Lighting and distant real-volume sunset study. Camera and model remain fixed."""
import bpy,os,sys,random,math
from mathutils import Vector,noise
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
def apply_environment12():
 s=bpy.context.scene
 # Directional late sun, not a broad global exposure increase.
 sun=bpy.data.lights['Sunset directional light'];sun.energy=4.5;sun.color=(1,.55,.22);sun.angle=.035
 bg=next(n for n in s.world.node_tree.nodes if n.type=='BACKGROUND');bg.inputs['Strength'].default_value=.8
 bpy.data.lights['Soft blue sky dome'].energy=12500
 for m in bpy.data.materials:
  if not m.use_nodes:continue
  if any(k in m.name.lower() for k in ['cloud','crown']):
   for q in m.node_tree.nodes:
    if q.type=='PRINCIPLED_VOLUME':q.inputs['Anisotropy'].default_value=.5
 # Multi-scale distant clouds in actual geometry, below and above disk ray z~21.
 mat=bpy.data.materials.new('REV12 | distant golden stratus volume');mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links
 out=n.new('ShaderNodeOutputMaterial');vol=n.new('ShaderNodeVolumePrincipled');vol.inputs['Color'].default_value=(.88,.68,.44,1);vol.inputs['Anisotropy'].default_value=.4
 tc=n.new('ShaderNodeTexCoord');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=6;tex.inputs['Detail'].default_value=4;tex.inputs['Roughness'].default_value=.72
 ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.27;ramp.color_ramp.elements[0].color=(0,0,0,1);ramp.color_ramp.elements[1].position=.68;ramp.color_ramp.elements[1].color=(.17,.17,.17,1)
 dist=n.new('ShaderNodeVectorMath');dist.operation='DISTANCE';dist.inputs[1].default_value=(.5,.5,.5)
 fade=n.new('ShaderNodeMapRange');fade.inputs['From Min'].default_value=.25;fade.inputs['From Max'].default_value=.57;fade.inputs['To Min'].default_value=1;fade.inputs['To Max'].default_value=0;fade.clamp=True
 mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY'
 for a,b in [(tc.outputs['Generated'],tex.inputs[0]),(tex.outputs['Fac'],ramp.inputs[0]),(tc.outputs['Generated'],dist.inputs[0]),(dist.outputs['Value'],fade.inputs[0]),(ramp.outputs[0],mul.inputs[0]),(fade.outputs[0],mul.inputs[1]),(mul.outputs[0],vol.inputs['Density']),(vol.outputs[0],out.inputs['Volume'])]:l.new(a,b)
 rng=random.Random(12045)
 for band,(y,z) in enumerate([(230,9),(220,14),(225,27),(240,34)]):
  for j in range(8):
   x=-90+j*29+rng.uniform(-12,12)
   bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3,radius=1,location=(x,y+rng.uniform(-7,7),z+rng.uniform(-2.0,2.0)));o=bpy.context.object;o.name='REV12 | broken distant stratus %d.%02d'%(band,j)
   for v in o.data.vertices:
    p=v.co.copy();v.co*=1+.13*noise.noise_vector(p*5+Vector((j,band,0)))[0]
   o.scale=(rng.uniform(4,10),rng.uniform(3,7),rng.uniform(.55,1.4));o.data.materials.append(mat)
 return {'distant_cloud_bounds':44,'sun_energy':sun.energy}
if __name__=='__main__':
 print(apply_environment12(),flush=True);s=bpy.context.scene;s.cycles.samples=64;s.cycles.use_denoising=False;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.04;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_environment12.png');s.render.image_settings.file_format='PNG';bpy.ops.render.render(write_still=True)
