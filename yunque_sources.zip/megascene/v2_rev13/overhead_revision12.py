"""Open the legacy solid overhead plates, preserving all other geometry.
Apply to the immutable rev11 scene in memory; no scene loading/saving/rendering.
"""
import bpy,bmesh,math
from mathutils import Vector
from architecture import Batch,_materials

ROOT='Rev12 / open suspended galleries'

def _remove_boxes(obj,predicate):
    """Edit only isolated eight-vertex cuboids, never part of portal tube meshes."""
    bm=bmesh.new();bm.from_mesh(obj.data)
    visited=set();kill=[];count=0
    for v in bm.verts:
        if v in visited:continue
        stack=[v];visited.add(v);island=[]
        while stack:
            q=stack.pop();island.append(q)
            for e in q.link_edges:
                n=e.other_vert(q)
                if n not in visited:visited.add(n);stack.append(n)
        if len(island)!=8:continue
        pts=[obj.matrix_world@v.co for v in island]
        lo=Vector(tuple(min(p[i] for p in pts) for i in range(3)))
        hi=Vector(tuple(max(p[i] for p in pts) for i in range(3)))
        if predicate((lo+hi)/2,hi-lo):kill.extend(island);count+=1
    if kill:
        bmesh.ops.delete(bm,geom=kill,context='VERTS');bm.to_mesh(obj.data);obj.data.update()
    bm.free();return count

def _surgical_opening():
    changes={}
    for ob in list(bpy.data.objects):
        if ob.type!='MESH':continue
        pred=None
        if ob.name.startswith('Moon gate / terraces / bridge'):
            def pred(c,s):
                # Entire center overhead coffer plates, with their orphan trim and posts.
                center=-13<c.x<34 and c.y>64 and 42<c.z<51
                if not center:return False
                slab=s.x>10 and s.y>10 and s.z<.7
                orphan_rib=(s.x>9 and s.y<.5 and s.z<.4) or (s.y>9 and s.x<.5 and s.z<.4)
                simple_post=s.x<.4 and s.y<.4 and s.z>4
                small_bracket=s.x<4 and s.y<4 and s.z<.3 and c.z<44.5
                return slab or orphan_rib or simple_post or small_bracket
        elif ob.name.startswith(('Upper left celestial gallery /','Upper right celestial gallery /')):
            # Foundation plinths and two full floor decks: keep railing posts, roof and colonnade.
            pred=lambda c,s: s.x>18 and s.y>10 and s.z<.6 and c.z<45
        elif ob.name.startswith('Sky palace / carved suspended gallery network / dark'):
            # Remove opaque infill of soffit coffers but preserve octagonal carving/rib framework.
            pred=lambda c,s: 5.4<s.x<5.6 and 6.9<s.y<7.1 and s.z<.3
        if pred:
            n=_remove_boxes(ob,pred)
            if n:changes[ob.name]=n
    return changes

def _new_structure():
    mats=_materials();b=Batch(mats)
    def beam(a,d,w=.18,ma='wood'):
        b.tube([a,d],w,ma,4)
    def frieze(x0,x1,y,z):
        # Paired unequal beam depths, with genuinely open fretwork between.
        b.box(((x0+x1)/2,y,z),(x1-x0,.48,.32),'wood')
        b.box(((x0+x1)/2,y,z-.86),(x1-x0,.32,.21),'wood')
        b.box(((x0+x1)/2,y-.25,z+.15),(x1-x0,.035,.035),'gold')
        n=max(2,round((x1-x0)/1.3));step=(x1-x0)/n
        for i in range(n):
            x=x0+(i+.5)*step
            b.box((x,y,z-.43),(.085,.15,.7),'wood')
            # staggered open Chinese key fret, not solid panel.
            for sg in [-1,1]:
                p=[(x,y,z-.66),(x+sg*step*.38,y,z-.66),(x+sg*step*.38,y,z-.26),(x+sg*step*.12,y,z-.26)]
                b.tube(p,.043,'red',4)
        for i in range(0,n+1,3):
            x=x0+i*step
            for j in range(3):
                b.box((x,y,z-1.03-j*.19),(1.5-j*.35,.3,.14),'wood')
            for sg in [-1,1]:
                beam((x+sg*.85,y,z-.95),(x,y,z-1.68),.08,'red')
    for cx,cy,z,w,d,sh in [(-42,64,38,20,12,5.5),(49,68,37,22,13,5.8)]:
        # Two open circulation galleries, supported by narrow transverse joists.
        for level in range(2):
            zz=z+level*sh
            # Keep a walking ledge instead of a solid full-depth plate.
            for sg in [-1,1]:
                b.box((cx,cy+sg*d*.46,zz-.12),(w+2,1.3,.22),'wood')
                frieze(cx-w*.56,cx+w*.56,cy+sg*(d*.5+.6),zz-.22)
            for sg in [-1,1]:
                x=cx+sg*w*.52
                b.box((x,cy,zz-.1),(.9,d+1,.22),'wood')
                for dz,th in [(-.3,.22),(-1.02,.16)]:b.box((x,cy,zz+dz),(.3,d+1,th),'wood')
            for j in range(7):
                x=cx-w*.5+j*w/6
                b.box((x,cy,zz-.4),(.24,d+1,.32),'wood')
                for sg in [-1,1]:
                    yy=cy+sg*d*.44
                    # Load-bearing curved braces below each ledge.
                    b.tube([(x,yy-sg*1.2,zz-.48),(x,yy-sg*.6,zz-1.05),(x,yy,zz-1.6)],.1,'red',6)
                    b.box((x,yy,zz-1.15),(.26,.3,1.05),'wood')
        # Thin upper lattice bays echo the inhabited galleries in target.
        for x in [cx-w*.5+j*w/5 for j in range(6)]:
            b.box((x,cy-d*.5-.1,z+1.9),(.11,.13,3.5),'wood')
    return b.finish(ROOT,(0,0,0))

def apply_overhead_revision():
    if bpy.data.objects.get(ROOT):return {'already_applied':True}
    changes=_surgical_opening();root=_new_structure()
    verts=sum(len(o.data.vertices) for o in root.children if o.type=='MESH')
    print('REV12_OVERHEAD',changes,'added_vertices',verts,flush=True)
    return {'removed_box_components':changes,'added_vertices':verts}

# Explicit alias for integration scripts.
apply_overhead_revision12=apply_overhead_revision
