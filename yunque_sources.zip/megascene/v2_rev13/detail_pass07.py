"""Incremental physically modeled detail pass, run against the progress06 blend."""
import bpy,os,sys
from mathutils import Vector
ROOT=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,ROOT)
s=bpy.context.scene
# Repair shader height links: Strength is not the Bump Height socket.
for name in ['Court • aged gilded bronze','Court • blue grey carved stone','Court • black lacquer','Court • wet blue marble']:
 m=bpy.data.materials.get(name)
 if not m or not m.use_nodes:continue
 for n in m.node_tree.nodes:
  if n.bl_idname=='ShaderNodeBump' and n.inputs['Strength'].is_linked:
   sock=n.inputs['Strength'].links[0].from_socket
   m.node_tree.links.remove(n.inputs['Strength'].links[0]);n.inputs['Strength'].default_value=.14
   m.node_tree.links.new(sock,n.inputs['Height'])
# Polished slate has a shallow clearcoat, not blue-metal pigment.
m=bpy.data.materials['Court • wet blue marble'];p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Metallic'].default_value=.12;p.inputs['Coat Weight'].default_value=.65;p.inputs['Coat Roughness'].default_value=.075
for n in m.node_tree.nodes:
 if n.type=='VALTORGB' and n.outputs[0].is_linked and n.outputs[0].links[0].to_socket==p.inputs['Base Color']:
  n.color_ramp.elements[0].color=(.085,.12,.16,1);n.color_ramp.elements[1].color=(.27,.34,.4,1)
# Golden indirect grazing accent across upper bark ridges, with soft falloff.
d=bpy.data.lights.new('Bark warm grazing rim 07','AREA');d.energy=14000;d.shape='DISK';d.size=12;d.color=(1,.63,.28);o=bpy.data.objects.new(d.name,d);bpy.context.collection.objects.link(o);o.location=(47,42,43);o.rotation_euler=(Vector((16,30,23))-o.location).to_track_quat('-Z','Y').to_euler()
# Make the distant shrine truly distant; its current large unsupported silhouette competes with the hero.
for name in ['Distant center shrine']:
 ob=bpy.data.objects.get(name)
 if ob:ob.scale=(.45,.45,.45)
# Reduce the tall right background stack, maintaining an asymmetrical layered edge.
for name in ['Far right sanctuary']:
 ob=bpy.data.objects.get(name)
 if ob:ob.scale.z=.7;ob.location.x+=3
# Lower and shorten the midground bridge without moving any ring/foreground geometry.
for ob in bpy.data.objects:
 if ob.type=='MESH' and ob.name.startswith('Moon gate / terraces / bridge'):
  for v in ob.data.vertices:
   x,y,z=v.co
   if -35<x<9 and 12<y<27 and 2<z<14:
    v.co.z-=2.15;v.co.x=-34+(x+34)*.89
# Broaden the gate inward while preserving its outer silhouette and centered opening.
import math
for ob in bpy.data.objects:
 if ob.type=='MESH' and ob.name.startswith('Moon gate / terraces / bridge'):
  for v in ob.data.vertices:
   x,y,z=v.co;dx=x-10;dz=z-22.5;rr=math.hypot(dx,dz)
   if 45.2<y<48.7 and 22.25<rr<23.8:
    newr=23.7-(23.7-rr)*1.65
    v.co.x=10+dx*newr/rr;v.co.z=22.5+dz*newr/rr
# Distant thin 3D cloud bars: real lit volume, not background image overlay.
import random
from landscape_v3 import _cloud_group
rng=random.Random(709)
cloud=bpy.data.materials['Cloud | eroded fractal scattering v3']
for i,(pos,sc) in enumerate([((-6,215,29),(7,2,.22)),((63,230,32),(8,2,.25)),((35,260,11),(10,2,.3)),((-28,205,18),(6,2,.22))]):
 _cloud_group('Sunset horizon filament %02d'%i,pos,sc,rng,cloud,9)
# Root shelf / lantern / tree modules integrated only when available and reviewed.
for name in ['HERO • sculpted braided bark, roots, limbs and twigs','HERO • thousands of individual ivory five-petal blossoms','HERO • restrained gold bark fissures','HERO • hanging ritual gold lantern pendants']:
 ob=bpy.data.objects.get(name)
 if ob:bpy.data.objects.remove(ob,do_unlink=True)
from hero_tree_v5 import build_tree
build_tree(root=(14,30,10),scale=1)
from supplemental_islands import build_supplemental_islands
build_supplemental_islands()
for ob in list(bpy.data.objects):
 if ob.name.startswith(('Lantern fine black fret','Lantern cross fret')):bpy.data.objects.remove(ob,do_unlink=True)
from foreground_ornament import build_foreground_ornament
build_foreground_ornament()

s.cycles.samples=96;s.cycles.adaptive_threshold=.03;s.render.resolution_percentage=50;s.render.filepath=os.path.join(ROOT,'preview_07.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'云阙_V2_07.blend'))

if os.environ.get('MEGASCENE_BUILD_ONLY') != '1': bpy.ops.render.render(write_still=True)
