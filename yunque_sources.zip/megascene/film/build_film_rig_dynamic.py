import bpy,json,math,os,hashlib
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;s=bpy.context.scene;plan=json.loads((R/'storyboard_final.json').read_text());source=bpy.data.filepath;sha=hashlib.sha256(Path(source).read_bytes()).hexdigest();original=s.camera;col=bpy.data.collections.new('FILM | six dynamic camera shots');s.collection.children.link(col);cams=[]
for shot in plan['shots']:
 data=original.data.copy();cam=bpy.data.objects.new('FILM '+shot['id']+' | '+shot['name'],data);col.objects.link(cam);cam.data.dof.use_dof=False;start=int(shot['start']*12);end=int(shot['end']*12);n=end-start
 for frame in range(start,end):
  u=(frame-start)*1.5/95 if shot['id']=='01' else (frame-start)/(n-1);u=.5-.5*math.cos(math.pi*u);loc=Vector(shot['camera_from']).lerp(Vector(shot['camera_to']),u);target=Vector(shot['target_from']).lerp(Vector(shot['target_to']),u);cam.location=loc;cam.rotation_euler=(target-loc).to_track_quat('-Z','Y').to_euler();cam.data.lens=shot['lens'];cam.keyframe_insert('location',frame=frame+1);cam.keyframe_insert('rotation_euler',frame=frame+1)
 if cam.animation_data and cam.animation_data.action:
  for fc in cam.animation_data.action.fcurves:
   for p in fc.keyframe_points:p.interpolation='LINEAR'
 marker=s.timeline_markers.new(shot['id']+' '+shot['name'],frame=start+1);marker.camera=cam;cams.append(cam)
s.camera=cams[0];s.frame_start=1;s.frame_end=360;s.render.fps=12;s.frame_set(1);s.render.resolution_x=960;s.render.resolution_y=540;s.render.resolution_percentage=100;s.render.use_border=False;s.render.use_crop_to_border=False;s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.cycles.use_adaptive_sampling=False;s.cycles.sample_clamp_direct=4;s.cycles.sample_clamp_indirect=1.5;s.cycles.blur_glossy=1;s.cycles.max_bounces=6;s.cycles.volume_bounces=2;s.cycles.volume_step_rate=2;s.render.filepath='//film_frames/frame_';s['Film duration seconds']=30;s['Film native fps']=12;s['Film source sha256']=sha;s['Film finishing']='Independent Monte Carlo seeds; linear depth temporal reprojection; original AgX/glare; per-shot24fps optical-flow interpolation; original score.'
out=R/'云阙_30秒六镜头_可编辑动画.blend';bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True);json.dump({'file':out.name,'source_sha256':sha,'native_fps':12,'frames':360,'duration_seconds':30,'camera_markers':[{'name':m.name,'frame':m.frame,'camera':m.camera.name if m.camera else None} for m in s.timeline_markers],'bytes':out.stat().st_size},open(R/'film_rig_dynamic_manifest.json','w'),ensure_ascii=False,indent=2)
