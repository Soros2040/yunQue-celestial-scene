#!/usr/bin/env python3
"""Original procedural score, no external samples. Python/numpy/scipy only.
python compose_score.py --duration 30 --output celestial_score.wav
All musical timings scale with duration; audio remains at 48 kHz.
"""
import argparse, json
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt
p=argparse.ArgumentParser();p.add_argument('--duration',type=float,default=30);p.add_argument('--output',default='celestial_score.wav');a=p.parse_args()
SR=48000; D=a.duration; rng=np.random.default_rng(731904); mix=np.zeros((round(D*SR),2),np.float64)
def hz(m):return 440*2**((m-69)/12)
def add(sig,start,gain=1,pan=0):
    i=round(start*SR); n=min(len(sig),len(mix)-i)
    if n<=0:return
    ang=(pan+1)*np.pi/4
    mix[i:i+n,0]+=sig[:n]*gain*np.cos(ang);mix[i:i+n,1]+=sig[:n]*gain*np.sin(ang)
def tone(m,dur,kind):
    t=np.arange(round(dur*SR))/SR;f=hz(m)
    if kind=='pluck':
        # Dispersive decaying partials evoke a plucked silk string, not a sampled instrument.
        s=sum(((-1)**(k+1))*np.sin(2*np.pi*f*k*(1+.000035*k*k)*t+rng.uniform(-.1,.1))*np.exp(-t*(.55+.13*k))/k**1.45 for k in range(1,13))
        attack=1-np.exp(-t/.005);s*=attack
        s+=.022*rng.normal(size=len(t))*np.exp(-t/0.018)
    elif kind=='flute':
        phase=2*np.pi*f*t+.035*np.sin(2*np.pi*4.7*t)*(1-np.exp(-t))
        breath=sosfilt(butter(2,[1400,6500],fs=SR,btype='bandpass',output='sos'),rng.normal(size=len(t)))
        s=(np.sin(phase)+.16*np.sin(2*phase)+.045*np.sin(3*phase)+.028*breath)
        s*=np.minimum(t/.22,1)*np.minimum((dur-t)/.42,1)
    elif kind=='bell':
        s=sum(np.sin(2*np.pi*f*r*t)*np.exp(-t/(2.8/(j+1)**.55))/(j+1)**1.5 for j,r in enumerate([1,2.01,2.77,4.08,5.43]))
        s*=1-np.exp(-t/.003)
    else:
        s=sum(np.sin(2*np.pi*f*r*t+.07*np.sin(2*np.pi*.11*t+j))*g for j,(r,g) in enumerate([(1,.7),(1.002,.22),(2,.12),(3,.045)]))
        s*=np.sin(np.pi*np.minimum(t/1.8,1)/2)**2*np.sin(np.pi*np.minimum((dur-t)/2.8,1)/2)**2
    s*=np.minimum((dur-t)/.035,1)
    return s
scale=D/30
# D minor pentatonic: D F G A C. Independent melody composed for this film.
# Each entry: nominal onset, midi note, length, gain, stereo position.
plucks=[(.8,50,4,.28,-.28),(2.0,57,3,.22,.18),(3.15,60,3,.21,-.12),(4.55,62,3,.24,.22),(6.0,57,3,.19,-.2),
(8.15,53,3.5,.26,-.28),(9.45,57,3,.20,.18),(10.65,60,3,.23,-.12),(12.1,67,3,.21,.23),(13.6,65,3,.18,-.08),
(15.2,62,3,.26,-.28),(16.35,65,3,.22,.18),(17.55,69,3,.23,-.08),(19.1,67,3,.20,.24),(20.65,60,3,.20,-.2),
(22.1,57,3,.24,-.25),(23.25,60,3,.19,.18),(24.6,65,3,.20,-.1),(25.7,62,4,.26,.15),(26.45,50,3.5,.30,-.2),(27.15,57,2.8,.16,.2)]
for st,m,du,g,pan in plucks:add(tone(m,du*scale,'pluck'),st*scale,g,pan)
for st,m,du,g,pan in [(4.3,74,2.1,.105,.12),(6.35,72,1.3,.09,.12),(9.1,69,2.4,.10,.08),(11.8,72,2.5,.11,.08),(15.65,74,2.35,.115,.1),(18.25,77,2.65,.11,.1),(21.25,74,2.1,.10,.08),(24.0,69,1.6,.09,.12),(25.9,74,2.3,.095,.1)]:add(tone(m,du*scale,'flute'),st*scale,g,pan)
for st,notes,du,g in [(0,[38,45,62],9,.043),(7.7,[41,48,57],8,.042),(14.7,[43,50,62],8,.048),(21.7,[38,45,62],8.3,.052)]:
    for j,m in enumerate(notes):add(tone(m,du*scale,'pad'),st*scale,g,(j-1)*.48)
for st,m,g,pan in [(.3,86,.055,.5),(8,81,.045,-.5),(15,86,.055,.5),(22,81,.04,-.5),(26.1,86,.035,.4)]:add(tone(m,3.8*scale,'bell'),st*scale,g,pan)
# A restrained synthetic air texture, independent seeded noise and bandpass.
N=len(mix);t=np.arange(N)/SR
wind=sosfilt(butter(2,[250,2200],fs=SR,btype='bandpass',output='sos'),rng.normal(size=N))*.004
wind*=np.sin(np.pi*t/D)**2
mix[:,0]+=wind;mix[:,1]+=np.roll(wind,733)
# Cross-channel early reflections and diffuse feedback-free late taps.
dry=mix.copy()
for delay,g,swap in [(.091,.10,1),(.167,.08,0),(.283,.065,1),(.43,.055,0),(.617,.043,1),(.809,.035,0),(1.071,.027,1),(1.373,.018,0),(1.739,.012,1)]:
    k=round(delay*SR); mix[k:]+=dry[:-k,::-1] * g if swap else dry[:-k]*g
# Guaranteed edge fades and restrained master gain; preserve dynamics, no hard limiter.
fadein=np.minimum(t/.55,1);fadeout=np.minimum((D-t)/1.65,1)
mix*=np.sin(np.pi*fadein/2)[:,None]**2*np.sin(np.pi*fadeout/2)[:,None]**2
mix*=10**(-5.0/20)/np.max(np.abs(mix))
out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
wavfile.write(out,SR,mix.astype(np.float32))
qc={'file':str(out),'duration_seconds':len(mix)/SR,'sample_rate':SR,'channels':2,'sample_peak_dbfs':float(20*np.log10(np.max(np.abs(mix)))),'rms_dbfs':float(20*np.log10(np.sqrt(np.mean(mix**2)))),'clipped_samples':int(np.sum(abs(mix)>=1)),'first_sample':mix[0].tolist(),'last_sample':mix[-1].tolist(),'original_composition':True,'external_samples':False,'seed':731904}
out.with_suffix('.qc.json').write_text(json.dumps(qc,indent=2));print(json.dumps(qc,indent=2))
