import bpy,json,math
from pathlib import Path
from mathutils import Vector
r=Path(__file__).resolve().parent;s=bpy.context.scene;dg=bpy.context.evaluated_depsgraph_get();dirs=[Vector(v) for v in [(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]]
def loc(plan,f):
 q=plan['shots'][3];u=(f-180)/83;u=.5-.5*math.cos(math.pi*u);return Vector(q['camera_from']).lerp(Vector(q['camera_to']),u)
def cast(p):
 out=[]
 for d in dirs:
  ok,hit,n,idx,o,m=s.ray_cast(dg,p,d,distance=100)
  if ok:out.append(dict(object=o.name,distance=(hit-p).length,exit_normal=n.dot(d),direction=list(d)))
 return out
old=json.loads((r/'storyboard_dynamic.json').read_text());new=json.loads((r/'storyboard_roof_safe.json').read_text());results={'old222':cast(loc(old,222)),'new_close_hits':[],'new_min_distance':100}
for f in range(180,264):
 hits=cast(loc(new,f));md=min([v['distance'] for v in hits],default=100);results['new_min_distance']=min(results['new_min_distance'],md)
 if md<.5:results['new_close_hits'].append(dict(frame=f,hits=hits))
(r/'camera_clearance.json').write_text(json.dumps(results,indent=2));print(json.dumps(results)[:4000])
