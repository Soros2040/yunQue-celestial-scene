# 云阙 · 月门入梦：动态六镜头版

根据用户后续要求，旧版慢速四镜头已停用；新版强调更大角度、更快运动以及人物、灯具和建筑特写。几何模型不再修改。

## 30 秒分镜
| 时间 | 内容 |
|---|---|
| 0–5 秒 | 广角开场：复用旧版已完成帧 0–89，将 7.5 秒真实相机运动加速为 5 秒 |
| 5–10 秒 | 白衣人物背侧绕行，突出衣袖、长发和栏杆视差 |
| 10–15 秒 | 花纹金灯近景，横向绕行观察灯面与屋檐关系 |
| 15–22 秒 | 大跨度掠过宫殿飞檐、瓦面和柱廊 |
| 22–27 秒 | 古木近景较大角度绕行，展示树干与枝条的三维体积 |
| 27–30 秒 | 快速拉远返回云海全景 |

原生渲染为 960×540、12 fps、16 samples/frame。新渲染帧 60–359 共 300 帧；开场使用旧版独立、已完成的 90 帧，不混入新渲染检查点。后期同镜头内进行精确深度重投影线性累积，再应用 AgX、辉光和传统光流插帧至 24 fps。光流不跨剪辑点，最终 24 fps 不等于原生 24 fps 渲染。原创 30 秒配乐保持不变。

`云阙_30秒六镜头_可编辑动画.blend` 是新的可编辑镜头工程。开场关键帧按旧镜头 t=1.5×新时间采样，其余五镜头使用 `storyboard_dynamic.json`。原始冻结模型不变。四镜头工程和旧分镜仅为历史记录，不是最终影片方案。

## 复现流程
```bash
FILM_START=60 FILM_END=360 blender -b megascene/v2_rev13/云阙_V2_可编辑.blend -t 8 --python megascene/film/render_film_dynamic.py
python megascene/film/finish_ready_dynamic.py
```

开场源帧若未归档，可用 `render_film_slow_v2.py` 和原 `storyboard.json` 重新渲染旧版帧 0–92，再运行旧版深度/色彩后期；保留 0–89 的完整时间邻域。新旧文件夹及配置哈希彼此独立。新分镜锁定后不要修改 JSON 字节或冻结模型，续跑会校验检查点。

新目录：`frames_dynamic/`、`linear_dynamic/`、`linear_filtered_dynamic/`、`frames_finished_dynamic/`、`encoded_dynamic/`。中间帧无需上传 Git，可按源文件重建。最终交付包含短片、六镜头动画工程、分镜及制作脚本、原创音乐；同时保留模型与全部参考图。

运行依赖：Blender 4.3.2、FFmpeg、Python、NumPy、SciPy 和 Pillow。后期脚本默认从 PATH 调用 `blender`，可通过环境变量 `BLENDER_BIN` 指定可执行文件；中文标题默认 Noto Serif CJK 字体（Linux 路径可在编码脚本顶部调整）。

## 最终摄影机避障修复（必须执行）
最终全片检查发现原第 4 镜头中点穿过一棵前景树。保留其余五镜头，只将第 4 镜头向外后退并重新渲染 84 帧；五个位置实渲和全部 84 个相机位置的六向射线检查均通过。最终动画工程读取 `storyboard_final.json`，第 4 镜头以 `storyboard_roof_safe.json` / `frames_finished_roof_safe/` 为准。原 `storyboard_dynamic.json` 是前五个非修复镜头的制作记录，不代表最终第 4 镜头。

完成上面的 300 帧渲染和后期后，在最终编码前执行：
```bash
FILM_START=180 FILM_END=264 blender -b megascene/v2_rev13/云阙_V2_可编辑.blend -t 8 --python megascene/film/render_roof_safe.py
python megascene/film/finish_roof_safe.py
python megascene/film/encode_film_dynamic.py
```
编码脚本仅从修复文件夹读取第 4 镜头，其余镜头保持不变。请勿分发 `rejected_camera_collision/` 中已拒绝的初次合成视频。
