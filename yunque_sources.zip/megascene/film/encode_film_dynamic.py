"""Per-shot optical-flow finishing, genuine native3D frames; original score mux."""
from pathlib import Path
import subprocess,json,os
R=Path(__file__).resolve().parent;shots=json.loads((R/'storyboard_dynamic.json').read_text())['shots'];out=R/'encoded_dynamic';out.mkdir(exist_ok=True);font='/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc'
def run(cmd,log):
 with open(log,'w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=width,height,avg_frame_rate,nb_frames,codec_name','-of','json',str(path)]))
post=json.loads((R/'post_state_dynamic.json').read_text()) if (R/'post_state_dynamic.json').exists() else {'finished_count':0}
for shot in shots:
 start=int(shot['start']*12);count=int((shot['end']-shot['start'])*12);duration=shot['end']-shot['start'];path=out/('shot_'+shot['id']+'.mp4');mark=path.with_suffix('.json')
 if path.exists() and mark.exists():continue
 if shot['id']!='01' and post['finished_count']<start+count:continue
 source_start=0 if shot['id']=='01' else start
 source_duration=7.5 if shot['id']=='01' else duration
 source_pattern=R/('frames_finished/frame_%04d.png' if shot['id']=='01' else ('frames_finished_roof_safe/frame_%04d.png' if shot['id']=='04' else 'frames_finished_dynamic/frame_%04d.png'))
 vf='tpad=stop_mode=clone:stop_duration=0.5,minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1,setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration=0.5,trim=duration=%s,setpts=PTS-STARTPTS'%duration
 if shot['id']=='01':
  vf='settb=AVTB,setpts=PTS*2/3,'+vf
  vf+=",fade=t=in:st=0:d=0.8,drawtext=fontfile=%s:text='云阙 · 月门入梦':fontsize=30:fontcolor=0xECE4CA:shadowcolor=black@0.65:shadowx=2:shadowy=2:x=w*0.06:y=h*0.08:enable='between(t,0.8,4.4)':alpha='if(lt(t,1.6),(t-0.8)/0.8,if(gt(t,3.6),(4.4-t)/0.8,1))'"%font
 if shot['id']=='06':vf+=',fade=t=out:st=%s:d=1.5'%(duration-1.5)
 vf+=',tpad=stop_mode=clone:stop_duration=1,settb=1/24,setpts=N'
 cmd=['ffmpeg','-hide_banner','-y','-filter_threads','2','-framerate','12','-start_number',str(source_start),'-t',str(source_duration),'-i',str(source_pattern),'-vf',vf,'-an','-r','24','-fps_mode','cfr','-frames:v',str(duration*24),'-c:v','libx264','-threads','2','-preset','medium','-crf','20','-maxrate','4500k','-bufsize','9000k','-pix_fmt','yuv420p','-video_track_timescale','24000','-movflags','+faststart',str(path)]
 run(cmd,out/('shot_'+shot['id']+'.log'));info=probe(path);video=next(s for s in info['streams'] if s['codec_name']=='h264')
 if 0 < duration*24-int(video['nb_frames']) <= 4:
  fixed=path.with_name(path.stem+'_padded.mp4')
  run(['ffmpeg','-hide_banner','-y','-i',str(path),'-vf','tpad=stop_mode=clone:stop_duration=1','-t',str(duration),'-r','24','-c:v','libx264','-threads','2','-crf','20','-maxrate','4500k','-bufsize','9000k','-pix_fmt','yuv420p','-video_track_timescale','24000','-movflags','+faststart',str(fixed)],out/('shot_'+shot['id']+'_pad.log'));os.replace(fixed,path);info=probe(path);video=next(s for s in info['streams'] if s['codec_name']=='h264')
 assert int(video['nb_frames'])==duration*24;assert abs(float(info['format']['duration'])-duration)<.001;mark.write_text(json.dumps(info,indent=2));print('SHOT_ENCODED',shot['id'],flush=True)
if not all((out/('shot_'+q['id']+'.json')).exists() for q in shots):raise SystemExit
listing=out/'concat.txt';listing.write_text(''.join("file 'shot_%s.mp4'\n"%q['id'] for q in shots));final=R/'云阙_月门入梦_30秒短片.mp4'
run(['ffmpeg','-hide_banner','-y','-f','concat','-safe','0','-i',str(listing),'-i',str(R/'music/celestial_score_30s_48k_stereo.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','30','-movflags','+faststart',str(final)],R/'encode_dynamic_final.log');info=probe(final);video=next(s for s in info['streams'] if s['codec_name']=='h264');assert int(video['nb_frames'])==720;assert abs(float(info['format']['duration'])-30)<.05
if final.stat().st_size>18_000_000:
 master=R/'云阙_月门入梦_30秒_高码率母版.mp4';os.replace(final,master)
 run(['ffmpeg','-hide_banner','-y','-i',str(master),'-c:v','libx264','-threads','2','-preset','slow','-crf','22','-maxrate','4000k','-bufsize','8000k','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(final)],R/'encode_chat_delivery.log');info=probe(final)
assert final.stat().st_size<=18_000_000
(R/'final_video_dynamic_probe.json').write_text(json.dumps(info,ensure_ascii=False,indent=2));print('FINAL_VIDEO',str(final),final.stat().st_size,flush=True)
