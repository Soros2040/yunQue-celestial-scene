"""Finalize only frames with complete temporal neighborhoods; safe during render."""
from pathlib import Path
import json,subprocess,os
R=Path(__file__).resolve().parent;p=json.loads((R/'frames_v2/progress.json').read_text());statepath=R/'post_state.json';state=json.loads(statepath.read_text()) if statepath.exists() else {'next_frame':0}
ready=359 if p['status']=='complete' and p['frames_complete']==360 else p['frames_complete']-4
start=state['next_frame']
if ready<start:print('NO_READY_FRAMES',start,ready);raise SystemExit
with open(R/'depth_production.log','a') as f:subprocess.run(['python',str(R/'depth_temporal_denoise.py'),'--start',str(start),'--end',str(ready)],stdout=f,stderr=subprocess.STDOUT,check=True)
env=os.environ.copy();env.update(FINISH_START=str(start),FINISH_END=str(ready+1))
with open(R/'color_production.log','a') as f:subprocess.run([os.environ.get('BLENDER_BIN','blender'),'-b',str(R.parent/'v2_rev13/云阙_V2_可编辑.blend'),'-t','2','--python',str(R/'color_finish.py')],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
state.update(next_frame=ready+1,finished_count=ready+1,last_batch=[start,ready]);temp=statepath.with_suffix('.tmp');temp.write_text(json.dumps(state,indent=2));os.replace(temp,statepath);print('POST_COMPLETE',start,ready,flush=True)
