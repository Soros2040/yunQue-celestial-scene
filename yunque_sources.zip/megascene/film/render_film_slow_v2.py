"""Resumable genuine camera animation. Keeps final modeling source untouched."""
import bpy,os,json,time,hashlib,math,numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent;s=bpy.context.scene;plan=json.loads((R/'storyboard.json').read_text());mode=os.environ.get('FILM_MODE','production');FPS=12;W,H,SAMPLES=(480,270,8) if mode=='endpoints' else (960,540,16)
profile_sha=hashlib.sha256((R/'storyboard.json').read_bytes()+b'cycles-film16-direct4-indirect1.5-glossy1-volume2-fps12-seed7919-linearZ-v2').hexdigest();source=bpy.data.filepath;sha=hashlib.sha256(Path(source).read_bytes()).hexdigest();out=R/('endpoints' if mode=='endpoints' else 'frames_v2');out.mkdir(exist_ok=True)
s.render.engine='CYCLES';s.cycles.samples=SAMPLES;s.cycles.use_adaptive_sampling=False;s.cycles.use_denoising=False;s.cycles.max_bounces=6;s.cycles.volume_bounces=2;s.cycles.volume_step_rate=2;s.cycles.sample_clamp_direct=4 if mode!='endpoints' else 0;s.cycles.sample_clamp_indirect=1.5 if mode!='endpoints' else 3;s.cycles.blur_glossy=1.0 if mode!='endpoints' else .5;s.cycles.seed=73109;s.cycles.use_animated_seed=False
s.render.resolution_x=W;s.render.resolution_y=H;s.render.resolution_percentage=100;s.render.use_border=False;s.render.use_crop_to_border=False;s.render.use_persistent_data=True;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8';s.render.fps=FPS;s.camera.data.dof.use_dof=False
linear=R/'linear_v2';linear.mkdir(exist_ok=True);exr=R/'exr_work';exr.mkdir(exist_ok=True)
if mode!='endpoints':
 s.view_layers[0].use_pass_z=True;s.use_nodes=True;nt=s.node_tree;rl=next((n for n in nt.nodes if n.type=='R_LAYERS'),None)
 if rl is None:rl=nt.nodes.new('CompositorNodeRLayers')
 fileout=nt.nodes.new('CompositorNodeOutputFile');fileout.base_path=str(exr);fileout.format.file_format='OPEN_EXR';fileout.format.color_mode='RGB';fileout.format.color_depth='32';fileout.format.exr_codec='ZIP';fileout.file_slots[0].path='combined_';fileout.file_slots.new('depth_');nt.links.new(rl.outputs['Image'],fileout.inputs[0]);nt.links.new(rl.outputs['Depth'],fileout.inputs[1])
def save_array(path,arr):
 tmp=str(path)+'.tmp'
 with open(tmp,'wb') as f:np.save(f,arr);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def capture(frame):
 result={}
 for key in ['combined','depth']:
  path=exr/('%s_%04d.exr'%(key,frame+1));im=bpy.data.images.load(str(path),check_existing=False);a=np.empty(W*H*4,np.float32);im.pixels.foreach_get(a);bpy.data.images.remove(im);a=np.flipud(a.reshape(H,W,4));a=a[:,:,:3].copy() if key=='combined' else a[:,:,0].copy();dest=linear/('%s_%04d.npy'%(key,frame));save_array(dest,a);path.unlink();result[key]=str(dest)
 return result
start=int(os.environ.get('FILM_START','0'));end=int(os.environ.get('FILM_END','360'));indices=[0,95,96,179,180,263,264,359] if mode=='endpoints' else list(range(start,end))
state={'status':'running','native_fps':FPS,'width':W,'height':H,'samples':SAMPLES,'source_sha256':sha,'source':source,'frames_complete':0,'frame_range':[start,end],'frames':[],'mode':mode,'profile_sha256':profile_sha}
def atomic(path,data):
 temp=str(path)+'.tmp';Path(temp).write_text(json.dumps(data,ensure_ascii=False,indent=2));os.replace(temp,path)
def camera_at(frame):
 t=frame/FPS;shot=next(q for q in plan['shots'] if q['start']<=t<q['end']);n=int((shot['end']-shot['start'])*FPS);u=(frame-int(shot['start']*FPS))/(n-1);u=.5-.5*math.cos(math.pi*u)
 c=Vector(shot['camera_from']).lerp(Vector(shot['camera_to']),u);target=Vector(shot['target_from']).lerp(Vector(shot['target_to']),u);s.camera.location=c;s.camera.rotation_euler=(target-c).to_track_quat('-Z','Y').to_euler();s.camera.data.lens=shot['lens'];return shot['id']
for frame in indices:
 path=out/('frame_%04d.png'%frame);mark=out/('frame_%04d.json'%frame)
 if path.exists() and mark.exists():
  old=json.loads(mark.read_text())
  if old['source_sha256']!=sha or old['samples']!=SAMPLES or old['width']!=W or (mode!='endpoints' and old.get('profile_sha256')!=profile_sha):raise RuntimeError('Incompatible checkpoint')
  state['frames_complete']+=1;state['frames'].append(old);continue
 s.frame_set(frame+1);shot=camera_at(frame);bpy.context.view_layer.update();s.cycles.seed=73109+frame*7919;s.render.filepath=str(path);state['active_frame']=frame;atomic(out/'progress.json',state);t=time.time();bpy.ops.render.render(write_still=True)
 aov=capture(frame) if mode!='endpoints' else {};record={'frame':frame,'shot':shot,'seconds':round(time.time()-t,3),'file':path.name,'width':W,'height':H,'samples':SAMPLES,'source_sha256':sha,'profile_sha256':profile_sha,'seed':s.cycles.seed,'aov':aov,'camera_world':[list(row) for row in s.camera.matrix_world],'projection':[list(row) for row in s.camera.calc_matrix_camera(bpy.context.evaluated_depsgraph_get(),x=W,y=H,scale_x=1,scale_y=1)]};atomic(mark,record);state['frames_complete']+=1;state['frames'].append(record);atomic(out/'progress.json',state);print('FILM_FRAME_DONE',json.dumps(record),flush=True)
state['status']='complete';state.pop('active_frame',None);atomic(out/'progress.json',state)
