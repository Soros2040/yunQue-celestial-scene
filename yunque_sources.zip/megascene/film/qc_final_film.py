from pathlib import Path
import subprocess,json,hashlib,numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent;v=r/'云阙_月门入梦_30秒短片.mp4';q=r/'final_qc';q.mkdir(exist_ok=True)
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(v)]));vs=next(s for s in p['streams'] if s['codec_type']=='video');au=next(s for s in p['streams'] if s['codec_type']=='audio');assert int(vs['nb_frames'])==720 and vs['avg_frame_rate']=='24/1';assert (vs['width'],vs['height'])==(960,540);assert abs(float(p['format']['duration'])-30)<.01;assert v.stat().st_size<=18000000
proc=subprocess.run(['ffmpeg','-v','error','-i',str(v),'-vf','scale=80:45','-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True);a=np.frombuffer(proc.stdout,np.uint8).reshape(-1,45,80,3);assert len(a)==720;means=a.mean(axis=(1,2,3));bad=[int(i) for i in np.where(means<2)[0] if 20<=i<684];assert not bad,bad
for t in [2,7.5,12.5,18.5,24.5,28,29.9]:subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(v),'-frames:v','1',str(q/f't_{t}.png')],check=True)
im=Image.new('RGB',(1440,580),(20,20,20));d=ImageDraw.Draw(im)
for i,t in enumerate([2,7.5,12.5,18.5,24.5,28]):
 x=i%3*480;y=i//3*290;im.paste(Image.open(q/f't_{t}.png').resize((480,270)),(x,y));d.text((x+10,y+272),f'{t}s',fill='white')
im.save(q/'contact_sheet.jpg')
report={'status':'passed','duration_seconds':float(p['format']['duration']),'native_resolution':[960,540],'display_fps':24,'display_frames':720,'audio_codec':au['codec_name'],'audio_sample_rate':au['sample_rate'],'audio_channels':au['channels'],'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'all_720_frames_decoded':True,'unexpected_black_frames':bad,'black_scan_intentional_fade_exclusions':'first20 and last36 frames','frame_mean_luminance':means.tolist(),'corrected_roof_midpoint_seconds':18.5,'source_model_sha256':'72d3aaf38cdb9bdfe8ee8afef70ff0345fa1b8e1aa71cb29c776704105fc0cf0'}
(q/'ffprobe.json').write_text(json.dumps(p,indent=2));(q/'final_qc_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(q/'decode.log').write_text(proc.stderr.decode()+'\nAll 720 frames decoded successfully.\n');print(json.dumps({k:v for k,v in report.items() if k!='frame_mean_luminance'},ensure_ascii=False))
