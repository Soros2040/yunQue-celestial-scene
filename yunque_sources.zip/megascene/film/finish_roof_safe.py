from pathlib import Path
import os,subprocess,json
r=Path(__file__).resolve().parent;p=json.loads((r/'frames_roof_safe/progress.json').read_text());assert p['status']=='complete' and p['frames_complete']==84
subprocess.run(['python',str(r/'depth_temporal_roof_safe.py'),'--start','180','--end','263'],check=True)
env=os.environ.copy();env.update(FINISH_START='180',FINISH_END='264')
subprocess.run([os.environ.get('BLENDER_BIN','blender'),'-b',str(r.parent/'v2_rev13/云阙_V2_可编辑.blend'),'-t','2','--python',str(r/'color_finish_roof_safe.py')],env=env,check=True)
