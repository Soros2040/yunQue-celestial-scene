"""Static-scene depth reprojection of real linear Cycles samples. No AI/inpainting."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
import json,time,argparse
from pathlib import Path
import numpy as np
from scipy.ndimage import map_coordinates
R=Path(__file__).resolve().parent

def filter_frame(frame,radius=3):
 meta=json.loads((R/'frames_dynamic'/f'frame_{frame:04d}.json').read_text());d=np.load(meta['aov']['depth']);rgb=np.load(meta['aov']['combined']);h,w=d.shape
 yy,xx=np.mgrid[:h,:w].astype(np.float32);ndc=np.stack((2*(xx+.5)/w-1,1-2*(yy+.5)/h,-np.ones_like(xx),np.ones_like(xx)),axis=-1)
 invp=np.linalg.inv(np.array(meta['projection'],np.float32));ray=ndc@invp.T;ray=ray[...,:3]/ray[...,3,None];ray=ray/(-ray[...,2,None])
 sky=(d>1e5)|~np.isfinite(d);depth=np.where(sky,1e6,np.maximum(d,.0001));local=ray*depth[...,None];cw=np.array(meta['camera_world'],np.float32);world=local@cw[:3,:3].T+cw[:3,3]
 accum=rgb.astype(np.float32).copy();weights=np.ones((h,w),np.float32);neighbors=[]
 for j in range(max(0,frame-radius),min(359,frame+radius)+1):
  if j==frame:continue
  path=R/'frames_dynamic'/f'frame_{j:04d}.json'
  if not path.exists():continue
  m=json.loads(path.read_text())
  if m['shot']!=meta['shot'] or m['profile_sha256']!=meta['profile_sha256']:continue
  view=np.linalg.inv(np.array(m['camera_world'],np.float32));q=world@view[:3,:3].T+view[:3,3];z=-q[...,2];p=np.array(m['projection'],np.float32);clip=q@p[:,:3].T+p[:,3];u=(clip[...,0]/clip[...,3]*.5+.5)*w-.5;v=(.5-clip[...,1]/clip[...,3]*.5)*h-.5
  finite=np.isfinite(u)&np.isfinite(v)&np.isfinite(z);u=np.nan_to_num(u,nan=-10,posinf=-10,neginf=-10);v=np.nan_to_num(v,nan=-10,posinf=-10,neginf=-10);coords=[v,u];otherd=np.load(m['aov']['depth']);sampled=map_coordinates(otherd,coords,order=1,mode='nearest',prefilter=False);valid=finite&(u>=0)&(u<=w-1)&(v>=0)&(v<=h-1)&(z>0)
  same=(np.abs(sampled-z)<np.maximum(.12,.006*z))|(sky&(sampled>1e5));valid&=same
  other=np.load(m['aov']['combined']);warped=np.stack([map_coordinates(other[...,c],coords,order=1,mode='nearest',prefilter=False) for c in range(3)],axis=-1)
  warped=np.nan_to_num(warped,nan=0,posinf=0,neginf=0);weight=valid.astype(np.float32);accum+=warped*weight[...,None];weights+=weight;neighbors.append({'frame':j,'valid_fraction':float(valid.mean())})
 return accum/weights[...,None],{'frame':frame,'neighbors':neighbors,'mean_contributions':float(weights.mean()),'method':'linear depth-guided temporal accumulation; camera-axis Z, no generative editing'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,default=11);a=p.parse_args();out=R/'linear_filtered_dynamic';out.mkdir(exist_ok=True)
 for f in range(a.start,a.end+1):
  t=time.time();rgb,report=filter_frame(f);np.save(out/f'frame_{f:04d}.npy',rgb);report['seconds']=time.time()-t;(out/f'frame_{f:04d}.json').write_text(json.dumps(report,indent=2));print('DEPTH_DENOISE',f,report['seconds'],report['mean_contributions'],flush=True)
if __name__=='__main__':main()
